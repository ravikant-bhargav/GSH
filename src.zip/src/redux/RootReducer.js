
import { onBoardingReducer } from "./../screens/onboarding/OnBoardingReducer";
import { authReducer } from "./../screens/signup/AuthReducer";
export const rootReducer = {
    applanguage: onBoardingReducer,
    auth: authReducer,
};