import { createAction, createReducer } from '@reduxjs/toolkit'

export const increment = createAction('counter/increment')
export const decrement = createAction('counter/decrement')
export const incrementByAmount = createAction('counter/incrementByAmount')



const initialState = { value: 1 }

export const sampleReducer = createReducer(initialState, (builder) => {
    console.log('initialState', initialState,)
    builder.addCase(increment, (state, action) => {
        console.log('===>', state, action);
        state.value += action.payload;
    })
    builder.addCase(decrement, (state, action) => {
        state.value--
    })
    builder.addCase(incrementByAmount, (state, action) => {
        state.value += action.payload
    })
    .addDefaultCase((state, action) => {
        console.log('initialState=>', state,action)
        initialState
    })
})