import React, { useEffect } from 'react';
import {
    SafeAreaView,
    StatusBar,
    StyleSheet
} from 'react-native';
import { TransitionPresets, createStackNavigator } from '@react-navigation/stack';


import { useSelector, useDispatch } from 'react-redux';
import SplashScreen from './../screens/splash';

const Stack = createStackNavigator();

 export const AuthLoadingStack = () => {
   
    return (

        <React.Fragment>
            <StatusBar
                translucent
                animated={true}
                backgroundColor="rgba(0, 0, 0, 0.14)"
                barStyle={"dark-content"}
            />
            <Stack.Navigator>
                <Stack.Screen name="SplashScreen" component={SplashScreen} options={{ headerShown: false }} />
            </Stack.Navigator >
        </React.Fragment>

    )
}

export const styles = StyleSheet.create({
    container: {
        flex: 1,
    },

});

