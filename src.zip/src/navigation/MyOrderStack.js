import React from 'react';
import {
    SafeAreaView,
    StatusBar,
    StyleSheet
} from 'react-native';
import { TransitionPresets, createStackNavigator } from '@react-navigation/stack';



import DashboardHeader from '../components/shared/DashboardHeader';
import Dashboard from '../screens/dashboard';
import OrderList from '../screens/orderlist/OrderList';
import NoOrder from '../screens/orderlist/NoOrder';
import UnderMaintenenance from '../screens/norecords/UnderMaintenenance';
import NoInternet from '../screens/norecords/NoInternet';
import Category from '../screens/category';
import CategoryProduct from '../screens/category/CategoryProduct';
import CategoryByProduct from '../screens/category/CategoryByProduct';
import SubCategoryProduct from '../screens/category/SubCatagoryProduct'

import ProductDetails from '../screens/product/ProductDetails';
import AddToCart from '../screens/product/AddToCard';
import PaymentMethod from '../screens/product/PaymentMethod';
import OrderConfirmed from '../screens/product/OrderConfirmed';
import Bills from '../screens/bills';
import MyProfile from '../screens/myaccount/MyProfile';
import MyOrders from '../screens/myorders';
import OrderDetailspage from '../screens/myorders/OrderDetailspage';
import MySubscription from '../screens/mysubscription';
import MyAddress from '../screens/myaddress';
import AddnewAddress from '../screens/myaddress/AddnewAddress';


import SubscriptionDetails from '../screens/mysubscription/SubscriptionDetails';
import WeeklyPlanner from '../screens/planner/WeeklyPlanner';
import CreatePlanner from '../screens/planner/CreatePlanner';
import MyCalendar from '../screens/mycalendar/MyCalendar';
import OrderDetails from "../screens/mycalendar/OrderDetails";

const Stack = createStackNavigator();

export const MyOrderStack = () => {
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: "transparent" }]}>
            <StatusBar
                //  translucent
                animated={true}
                backgroundColor="rgb(246, 246, 246)"
                barStyle={"dark-content"}
            />
            <Stack.Navigator
                initialRouteName={"SubscriptionDetails"}
                screenOptions={{
                    header: ({ navigation }) => (
                        <DashboardHeader
                            navScreen={navigation}
                            headerTitle={"Hi,Rahul"}
                            headerTitle1={"Daily Schedule"}
                        />),
                    ...TransitionPresets.SlideFromRightIOS,

                }}>
               
                <Stack.Screen name="MyOrders" component={MyOrders} options={{ headerShown: false }} />
                <Stack.Screen name="MySubscription" component={MySubscription} options={{ headerShown: false }} />
                <Stack.Screen name="SubscriptionDetails" component={SubscriptionDetails} options={{ headerShown: false }} />
                <Stack.Screen name="MyAddress" component={MyAddress} options={{ headerShown: false }} />
                <Stack.Screen name="AddnewAddress" component={AddnewAddress} options={{ headerShown: false }} />
                <Stack.Screen name="OrderDetailspage" component={OrderDetailspage} options={{ headerShown: false }} />
                
                <Stack.Screen name="WeeklyPlanner" component={WeeklyPlanner} options={{ headerShown: false }} />
                <Stack.Screen name="CreatePlanner" component={CreatePlanner} options={{ headerShown: false }} />
                <Stack.Screen name="MyCalendar" component={MyCalendar} options={{ headerShown: false }} />

                <Stack.Screen name="OrderDetails" component={OrderDetails} options={{ headerShown: false }} />
                <Stack.Screen name="CategoryByProduct" component={CategoryByProduct} options={{ headerShown: false }} />
                <Stack.Screen name="SubCategoryProduct" component={SubCategoryProduct} options={{ headerShown: false }} />


            </Stack.Navigator >
        </SafeAreaView>
    )
}

export const styles = StyleSheet.create({
    container: {
        flex: 1,
    },

});