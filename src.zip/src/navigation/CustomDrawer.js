/* eslint-disable react-native/sort-styles */
/* eslint-disable import/order */
import React, { useEffect, useRef, useState } from "react";
import {
  Image,
  StyleSheet,
  Block,
  Button,
  Text,
  View,
  TouchableOpacity,
  Dimensions,
  Alert,
} from "react-native";
import {
  createStackNavigator,
  CardStyleInterpolators,
} from "@react-navigation/stack";
import {
  DrawerItem,
  createDrawerNavigator,
  DrawerContentScrollView,
  useDrawerProgress,
  useDrawerStatus,
  getDrawerStatusFromState,
  useIsDrawerOpen,
} from "@react-navigation/drawer";

// screens

import DrawerScreen1 from "../screens/drawerscreen/DrawerScreen1";
import appColors from "../utils/appColors";
import Dashboard from "../screens/dashboard";
import { DashboardStack } from "./DashboardStack";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  Easing,
  Extrapolate,
} from "react-native-reanimated";
import images from "../utils/sharedImages";
import HorizontalLine from "../components/HorizontalLine";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstants from "../utils/appConstant";
import { useDispatch } from "react-redux";
import { resetAuthUser } from "../screens/signup/AuthReducer";
import { ChangeLanguage } from "./src/screens/changelanguage/ChangeLanguage";
import { getprofileApi } from "../screens/myaccount/ProfileApiService";

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();
const windowHeight = Dimensions.get("window").height;

const Screens = ({ navigation, style }) => {
  // const progressqwe = useDrawerProgress();
  const drawerStatus = useDrawerStatus();
  const progress = drawerStatus === "open" ? 1 : 0;

  const sharedVal = useSharedValue(progress);

  const scale = Animated.interpolateNode(sharedVal.value, {
    inputRange: [0, 1],
    outputRange: [1, 1], /// 1,0.9
    // extrapolateRight: Extrapolate.CLAMP,
  });
  const borderRadius = Animated.interpolateNode(sharedVal.value, {
    inputRange: [0, 1],
    outputRange: [0, 26],
    // extrapolateRight: Extrapolate.CLAMP,
  });
  const animatedStyle = {
    borderRadius,
    transform: [{ scale }],
  };

  return (
    <Animated.View
      style={{
        flex: 1,
        ...animatedStyle,
      }}
    >
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen
          name="DashboardStack"
          component={DashboardStack}
          options={{}}
        />
      </Stack.Navigator>
    </Animated.View>
  );
};

const CustomDrawerContent = ({ navigation }) => {
  const [Name, setusername] = useState();
  const [Phone, setphone] = useState();
  const [image, setimage] = useState(null);
  //   const getUserDetails = async () => {
  //     let  userDetails=await AsyncStorage.getItem(appConstants.USER_DETAILS);
  //     setusername(userDetails.name);

  //   }
  const dispatch = useDispatch();

  const drawerStatus = useDrawerProgress();
  const progress = drawerStatus === "open" ? 1 : 0;
  const sharedVal = useSharedValue(sharedVal);

  const translateX = Animated.interpolateNode(sharedVal.value, {
    inputRange: [0, 1],
    outputRange: [-100, 0],
  });

  const logOut = async () => {
    Alert.alert("Are you sure?", " You want to logout ?", [
      {
        text: "Cancel",
        onPress: () => console.log("Cancel Pressed"),
        style: "cancel",
      },
      {
        text: "OK",
        onPress: async () => {
          await AsyncStorage.removeItem(appConstants.APP_TOKEN);
          await AsyncStorage.removeItem(appConstants.EMAIL);
          await AsyncStorage.removeItem(appConstants.PHONENUMBER);
          await AsyncStorage.removeItem(appConstants.PROFILEIMAGE);
          await AsyncStorage.removeItem(appConstants.NAME);
          await AsyncStorage.removeItem(appConstants.Billing_address_id);
          await AsyncStorage.removeItem(appConstants.Shipping_address_id);
          await AsyncStorage.removeItem(appConstants.Address_type);
          await AsyncStorage.removeItem(appConstants.City);
          await AsyncStorage.removeItem(appConstants.Landmark);
          await AsyncStorage.removeItem(appConstants.State);
          await AsyncStorage.removeItem(appConstants.Street_address);
          await AsyncStorage.removeItem(appConstants.Zip_code);
          dispatch(resetAuthUser());
          navigation.replace("OnBoardingStack");
        },
      },
    ]);
  };

  const getUserDetails = async () => {
    let Name = await AsyncStorage.getItem(appConstants.NAME);
    setusername(Name);
    let Phone = await AsyncStorage.getItem(appConstants.PHONENUMBER);
    setphone(Phone);
    // let image = await AsyncStorage.getItem(appConstants.PROFILEIMAGE);
    // console.log("LLBSJB", image);
    let token = await AsyncStorage.getItem(appConstants.APP_TOKEN);
    const reasData = await getprofileApi(token);
    if (reasData.data.data.profile_picture !== null) {
      setimage({ uri: reasData.data.data.profile_picture });
    }
  };
  useEffect(() => {
    getUserDetails();
  }, []);
  return (
    //  <Animated.View style={{ transform: [{ translateX }] }}>
    <DrawerContentScrollView
      scrollEnabled={true}
      contentContainerStyle={{ flex: 1 }}
    >
      <View style={{ height: "60%" }}>
        <TouchableOpacity
          style={{
            width: "100%",
            flexDirection: "row",
            padding: 5,
          }}
          onPress={() => {
            navigation.navigate("MyProfile");
          }}
        >
          {/* Profile Image  */}
          <View
            style={{
              width: "30%",
              height: 58,
              borderRadius: 10,
              shadowColor: "rgba(0, 0, 0, 0.25)",
              shadowOffset: {
                width: 0,
                height: 0,
              },
              shadowRadius: 4,
              shadowOpacity: 1,
            }}
          >
            {image !== null ? (
              <Image
                source={image}
                style={{ width: 58, height: 58, resizeMode: "cover" }}
              />
            ) : (
              <Image
                source={images.ProfileIcon}
                style={{ width: 58, height: 58, resizeMode: "cover" }}
              />
            )}
            {/* <Image
              source={images.ProfileAvatarIcon}
              style={{ width: 58, height: 58, resizeMode: "cover" }}
            /> */}
          </View>

          {/* Profile Details */}
          <View
            style={{
              flexDirection: "column",
              paddingLeft: 10,
              width: "70%",
            }}
          >
            <Text
              style={{
                fontFamily: "Montserrat-Bold",
                fontSize: 15,
                fontWeight: "500",
                fontStyle: "normal",
                lineHeight: 19.2,
                letterSpacing: 0,
                color: "#ffffff",
              }}
            >
              {Name}
            </Text>
            <Text
              style={{
                fontFamily: "Montserrat-Medium",
                fontSize: 10,
                fontWeight: "500",
                fontStyle: "normal",
                lineHeight: 12.3,
                letterSpacing: 0,
                color: "#ffffff",
              }}
            >
              {Phone}
            </Text>
            <View style={{ flexDirection: "row" }}>
              <Image
                source={images.GoldIcon}
                style={{
                  width: 20,
                  height: 20,
                  shadowColor: "#010149",
                  shadowOffset: {
                    width: 0,
                    height: 0,
                  },
                  shadowRadius: 4,
                  shadowOpacity: 1,
                  resizeMode: "cover",
                }}
              />
              <View style={{ flexDirection: "column" }}>
                <Text
                  style={{
                    fontFamily: "Montserrat-SemiBold",
                    fontSize: 11,
                    fontWeight: "600",
                    fontStyle: "normal",
                    lineHeight: 13.7,
                    letterSpacing: 0,
                    textAlign: "left",
                    color: "#ffffff",
                  }}
                >
                  103 Coins
                </Text>
                <Text
                  style={{
                    fontFamily: "Montserrat-SemiBold",
                    fontSize: 8,
                    fontWeight: "600",
                    fontStyle: "normal",
                    lineHeight: 8.2,
                    letterSpacing: 0,
                    textAlign: "left",
                    color: "#ffffff",
                  }}
                >
                  Reward Coins
                </Text>
              </View>
            </View>
          </View>
        </TouchableOpacity>
        <HorizontalLine
          customStyle={{
            height: 1,
            width: "100%",
            opacity: 0.56,
            backgroundColor: "#191b8f",
          }}
        />
        <View style={{ flex: 1 }}>
          <View
            style={{
              marginTop: 43,
              flexDirection: "column",
            }}
          >
            <TouchableOpacity
              style={{
                width: "100%",
                height: 44,
                borderRadius: 12,
                backgroundColor: "rgba(1,0,43,0.19)",
                marginBottom: 15,
                flexDirection: "row",
                alignItems: "center",
                paddingLeft: 15,
              }}
              onPress={() => {
                navigation.navigate("MyProfile");
              }}
            >
              <Image
                source={images.ProfileIcon}
                style={{
                  width: 24,
                  height: 24,
                  resizeMode: "cover",
                  tintColor: "#ffffff",
                }}
              />
              <Text
                style={{
                  fontFamily: "Montserrat-SemiBold",
                  fontSize: 12,
                  fontWeight: "600",
                  fontStyle: "normal",
                  lineHeight: 15.7,
                  letterSpacing: 0,
                  color: "#ffffff",
                  paddingLeft: 10,
                }}
              >
                My Profile
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                width: "100%",
                height: 44,
                borderRadius: 12,

                marginBottom: 15,
                flexDirection: "row",
                alignItems: "center",
                paddingLeft: 15,
              }}
              onPress={() => {
                navigation.navigate("MyCalendar");
              }}
            >
              <Image
                source={images.CalendarIcon}
                style={{
                  width: 24,
                  height: 24,
                  resizeMode: "cover",
                  tintColor: "#ffffff",
                }}
              />
              <Text
                style={{
                  fontFamily: "Montserrat-SemiBold",
                  fontSize: 12,
                  fontWeight: "600",
                  fontStyle: "normal",
                  lineHeight: 15.7,
                  letterSpacing: 0,
                  color: "#ffffff",
                  paddingLeft: 10,
                }}
              >
                Calendar
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                width: "100%",
                height: 44,
                borderRadius: 12,

                marginBottom: 15,
                flexDirection: "row",
                alignItems: "center",
                paddingLeft: 15,
              }}
              onPress={() => {
                navigation.navigate("WeeklyPlanner");
              }}
            >
              <Image
                source={images.WeeklyPlannerIcon}
                style={{
                  width: 24,
                  height: 24,
                  resizeMode: "cover",
                  tintColor: "#ffffff",
                }}
              />
              <Text
                style={{
                  fontFamily: "Montserrat-SemiBold",
                  fontSize: 12,
                  fontWeight: "600",
                  fontStyle: "normal",
                  lineHeight: 15.7,
                  letterSpacing: 0,
                  color: "#ffffff",
                  paddingLeft: 10,
                }}
              >
                Weekly Planner{" "}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                width: "100%",
                height: 44,
                borderRadius: 12,

                marginBottom: 15,
                flexDirection: "row",
                alignItems: "center",
                paddingLeft: 15,
              }}
              onPress={() => {
                navigation.navigate("Category");
              }}
            >
              <Image
                source={images.CategoryIcon}
                style={{
                  width: 24,
                  height: 24,
                  resizeMode: "cover",
                  tintColor: "#ffffff",
                }}
              />
              <Text
                style={{
                  fontFamily: "Montserrat-SemiBold",
                  fontSize: 12,
                  fontWeight: "600",
                  fontStyle: "normal",
                  lineHeight: 15.7,
                  letterSpacing: 0,
                  color: "#ffffff",
                  paddingLeft: 10,
                }}
              >
                Categories
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <View style={{ justifyContent: "flex-end", height: "40%" }}>
        <TouchableOpacity
          style={{
            width: "100%",
            borderRadius: 12,
            marginBottom: 10,
            flexDirection: "row",
            alignItems: "center",
          }}
          onPress={() => {
            navigation.navigate("ChangeLanguage");
          }}
        >
          <Image
            source={images.LanguageIcIcon}
            style={{
              width: 19,
              height: 19,
              resizeMode: "cover",
              tintColor: "#ffffff",
            }}
          />
          <Text
            style={{
              fontFamily: "Montserrat-Medium",
              fontSize: 11,
              fontWeight: "500",
              fontStyle: "normal",
              lineHeight: 14.4,
              letterSpacing: 0,
              textAlign: "left",
              color: "#ffffff",
              paddingLeft: 10,
            }}
          >
            Change Language
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            width: "100%",
            borderRadius: 12,
            marginBottom: 10,
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <Image
            source={images.SupportIcIcon}
            style={{
              width: 19,
              height: 19,
              resizeMode: "cover",
              tintColor: "#ffffff",
            }}
          />
          <Text
            style={{
              fontFamily: "Montserrat-Medium",
              fontSize: 11,
              fontWeight: "500",
              fontStyle: "normal",
              lineHeight: 14.4,
              letterSpacing: 0,
              textAlign: "left",
              color: "#ffffff",
              paddingLeft: 10,
            }}
          >
            Help & Support{" "}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            width: "100%",

            borderRadius: 12,
            flexDirection: "row",
            alignItems: "center",

            marginBottom: 10,
          }}
        >
          <Image
            source={images.SpeechIcIcon}
            style={{
              width: 19,
              height: 19,
              resizeMode: "cover",
              tintColor: "#ffffff",
            }}
          />
          <Text
            style={{
              fontFamily: "Montserrat-Medium",
              fontSize: 11,
              fontWeight: "500",
              fontStyle: "normal",
              lineHeight: 14.4,
              letterSpacing: 0,
              textAlign: "left",
              color: "#ffffff",
              paddingLeft: 10,
            }}
          >
            Connect with us
          </Text>
        </TouchableOpacity>
        <HorizontalLine
          customStyle={{
            height: 1,
            backgroundColor: "#ffffff",
          }}
        />
        <View style={{ marginBottom: 22, marginTop: 20 }}>
          <TouchableOpacity
            style={{
              width: "100%",
              borderRadius: 12,
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 10,
            }}
            onPress={() => {
              logOut();
            }}
          >
            <Image
              source={images.LogoutIcIcon}
              style={{
                width: 30,
                height: 30,
                resizeMode: "cover",
                tintColor: "#ffffff",
              }}
            />
            <Text
              style={{
                fontFamily: "Montserrat-Bold",
                fontSize: 14,
                fontWeight: "bold",
                fontStyle: "normal",
                lineHeight: 18.3,
                letterSpacing: 0,
                textAlign: "left",
                color: "#ffffff",
                paddingLeft: 10,
              }}
            >
              Logout
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </DrawerContentScrollView>
    //  </Animated.View>
  );
};

export default CustomDrawer = (props) => {
  return (
    <View style={{ flex: 1, backgroundColor: "transparent" }}>
      <Drawer.Navigator
        initialRouteName="Dashboard"
        screenOptions={{
          headerShown: false,
          sceneContainerStyle: {
            backgroundColor: appColors.PRIMARY_COLOR,
          },
          drawerType: "slide",
          drawerStyle: {
            backgroundColor: appColors.PRIMARY_COLOR,
            width: "55%",
            paddingRight: 12,
            paddingLeft: 12,
            paddingTop: 20,
            paddingBottom: 20,
          },
          drawerContentStyle: {
            backgroundColor: appColors.PRIMARY_COLOR,
          },
          drawerContentContainerStyle: {
            backgroundColor: appColors.PRIMARY_COLOR,
          },
          overlayColor: "transparent",
          gestureEnabled: true,
        }}
        useLegacyImplementation={true}
        //defaultStatus={'open'}
        drawerContent={(props) => {
          return <CustomDrawerContent navigation={props.navigation} />;
        }}
      >
        <Drawer.Screen name="Screens">
          {(props) => <Screens {...props} />}
        </Drawer.Screen>
      </Drawer.Navigator>
    </View>
  );
};

const styles = StyleSheet.create({
  stack: {
    flex: 1,
    shadowColor: "#FFF",
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.44,
    shadowRadius: 10.32,
    elevation: 5,
    overflow: "scroll",
    // borderWidth: 1,
  },
  drawerStyles: { flex: 1, width: "20%", backgroundColor: "blue" },
  drawerItem: { alignItems: "flex-start", marginVertical: 0 },
  drawerLabel: { color: "white", marginLeft: -16 },
  avatar: {
    borderRadius: 60,
    marginBottom: 16,
    borderColor: "white",
    borderWidth: StyleSheet.hairlineWidth,
  },
});
