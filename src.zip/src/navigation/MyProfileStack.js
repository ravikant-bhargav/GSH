import React from 'react';
import {
    SafeAreaView,
    StatusBar,
    StyleSheet
} from 'react-native';
import { TransitionPresets, createStackNavigator } from '@react-navigation/stack';


import { SignUpScreen } from './../screens/signup';
import OtpVerification from './../screens/signup/OtpVerification';
import MyProfile from '../screens/myaccount/MyProfile';
import MyOrders from '../screens/myorders';
import EditProfile from '../screens/myaccount/EditProfile'

const Stack = createStackNavigator();
const screenOptionStyle = {
    ...TransitionPresets.SlideFromRightIOS,
};

export const MyProfileStack = () => {
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: "#3d3cb3" }]}>
            <StatusBar
                animated={true}
                backgroundColor="#3d3cb3"
                barStyle={"dark-content"}
            />
            <Stack.Navigator
                initialRouteName="MyProfile"
                screenOptions={screenOptionStyle}
            >
                <Stack.Screen name="MyProfile" component={MyProfile} options={{ headerShown: false }} />
                
            </Stack.Navigator >
        </SafeAreaView>
    )
}

export const styles = StyleSheet.create({
    container: {
        flex: 1,
    },

});