import React from 'react';
import {
    SafeAreaView,
    StatusBar,
    StyleSheet
} from 'react-native';
import { TransitionPresets, createStackNavigator } from '@react-navigation/stack';



import DashboardHeader from './../components/shared/DashboardHeader';
import Dashboard from './../screens/dashboard';
import OrderList from '../screens/orderlist/OrderList';
import NoOrder from '../screens/orderlist/NoOrder';
import UnderMaintenenance from '../screens/norecords/UnderMaintenenance';
import NoInternet from '../screens/norecords/NoInternet';
import Category from '../screens/category';
import CategoryProduct from '../screens/category/CategoryProduct';
import CategoryByProduct from '../screens/category/CategoryByProduct';
import SubCatagoryProduct from '../screens/category/SubCatagoryProduct';
import ProductDetails from '../screens/product/ProductDetails';
import AddToCart from '../screens/product/AddToCard';
import PaymentMethod from '../screens/product/PaymentMethod';
import OrderConfirmed from '../screens/product/OrderConfirmed';
import Bills from '../screens/bills';
import MyProfile from '../screens/myaccount/MyProfile';
import MyOrders from '../screens/myorders';
import OrderDetailspage from '../screens/myorders/OrderDetailspage';
import MySubscription from '../screens/mysubscription';
import SubscriptionDetails from '../screens/mysubscription/SubscriptionDetails';
import MyAddress from '../screens/myaddress';
import WeeklyPlanner from '../screens/planner/WeeklyPlanner';
import CreatePlanner from '../screens/planner/CreatePlanner';
import MyCalendar from '../screens/mycalendar/MyCalendar';


import OrderDetails from "../screens/mycalendar/OrderDetails";

import EditOrderAddress   from '../screens/myorders/EditOrderAddress'

import {ChangeLanguage} from '../../src/screens/changelanguage/ChangeLanguage';
import CheckoutCardPage from '../screens/product/CheckoutCardPage';
import EditProfile from '../screens/myaccount/EditProfile';
import AddnewAddress from'../screens/myaddress/AddnewAddress';
import EditAddress from '../screens/myaddress/EditAddress';

import EditQuantityPage from '../screens/product/Editquantitypage';
import Wiselistpage from'../screens/wiselist/Wiselistpage';

import AsyncStorage from '@react-native-async-storage/async-storage';
import appConstant from '../utils/appConstant';
import EditAddressPage from "../screens/myaddress/EditAddress";

const Stack = createStackNavigator();

export const DashboardStack = () => {
  
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: "transparent" }]}>
            <StatusBar
                //  translucent
                animated={true}
                backgroundColor="rgb(246, 246, 246)"
                barStyle={"dark-content"}
            />
            <Stack.Navigator
                initialRouteName={"Dashboard"}
                screenOptions={{
                    header: ({ navigation }) => (
                        <DashboardHeader
                            navScreen={navigation}
                            headerTitle={"Hi"+"\n"+"Daily Schedule"}
                        />),
                    ...TransitionPresets.SlideFromRightIOS,

                }}>
                <Stack.Screen name="Dashboard" component={Dashboard} options={{ headerShown: false }}/>
                <Stack.Screen name="OrderList" component={OrderList} options={{ headerShown: false }} />
                <Stack.Screen name="Category" component={Category} options={{ headerShown: false }} />
                <Stack.Screen name="CategoryProduct" component={CategoryProduct} options={{ headerShown: false }} />
                <Stack.Screen name="CategoryByProduct" component={CategoryByProduct} options={{ headerShown: false }} />
                <Stack.Screen name="SubCatagoryProduct" component={SubCatagoryProduct} options={{ headerShown: false }} />
                <Stack.Screen name="ProductDetails" component={ProductDetails} options={{ headerShown: false }} />
                <Stack.Screen name="AddToCart" component={AddToCart} options={{ headerShown: false }} />
                <Stack.Screen name="CheckoutCardPage" component={CheckoutCardPage} options={{ headerShown: false }} />
                 <Stack.Screen name="EditQuantityPage" component={EditQuantityPage} options={{ headerShown: false }} /> 

                <Stack.Screen name="PaymentMethod" component={PaymentMethod} options={{ headerShown: false }} />
                <Stack.Screen name="OrderConfirmed" component={OrderConfirmed} options={{ headerShown: false }} />
                <Stack.Screen name="Bills" component={Bills} options={{ headerShown: false }} />
                
                <Stack.Screen name="MyOrders" component={MyOrders} options={{ headerShown: false }} />
                <Stack.Screen name="OrderDetailspage" component={OrderDetailspage} options={{ headerShown: false }} />
                <Stack.Screen name="EditOrderAddress" component={EditOrderAddress} options={{ headerShown: false }} />
                <Stack.Screen name="Wiselistpage" component={Wiselistpage} options={{ headerShown: false }} />
                
                
                
                
                <Stack.Screen name="NoOrder" component={NoOrder} options={{ headerShown: false }} />
                <Stack.Screen name="UnderMaintenenance" component={UnderMaintenenance} options={{ headerShown: false }} />
                <Stack.Screen name="NoInternet" component={NoInternet} options={{ headerShown: false }} />
                <Stack.Screen name="MyProfile" component={MyProfile} options={{ headerShown: false }} />
                <Stack.Screen name="EditProfile" component={EditProfile} options={{ headerShown: false }} />

                <Stack.Screen name="AddnewAddress" component={AddnewAddress} options={{ headerShown: false }} />
                <Stack.Screen name="EditAddress" component={EditAddressPage} options={{ headerShown: false }} />

                <Stack.Screen name="MySubscription" component={MySubscription} options={{ headerShown: false }} />
                <Stack.Screen name="SubscriptionDetails" component={SubscriptionDetails} options={{ headerShown: false }} />
                <Stack.Screen name="MyAddress" component={MyAddress} options={{ headerShown: false }} />
                <Stack.Screen name="WeeklyPlanner" component={WeeklyPlanner} options={{ headerShown: false }} />
                <Stack.Screen name="CreatePlanner" component={CreatePlanner} options={{ headerShown: false }} />
                <Stack.Screen name="MyCalendar" component={MyCalendar} options={{ headerShown: false }} />
                <Stack.Screen name="OrderDetails" component={OrderDetails} options={{ headerShown: false }} />


            </Stack.Navigator >
        </SafeAreaView>
    )
}

export const styles = StyleSheet.create({
    container: {
        flex: 1,
    },

});