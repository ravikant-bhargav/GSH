import React, { Component } from 'react'
import { View, TouchableOpacity, Animated, Easing, StyleSheet, Text, Image } from 'react-native'
import images from '../utils/sharedImages';

const routes = [
    {
        routeName: "Home",
        icon: images.homeIcon,
        isRouteActive: true,
        navigateTo: 'Dashboard'
    },
    {
        routeName: "Cart",
        icon: images.cartIcon,
        isRouteActive: false,
        navigateTo: 'AddToCart'
    },
    {
        routeName: "Products",
        icon: images.productIcon,
        isRouteActive: false,
        navigateTo: 'CategoryProduct'
    },
    {
        routeName: "Bills",
        icon: images.billsIcon,
        isRouteActive: false,
        navigateTo: 'Bills'
    },
]


class TabBarNavigation extends Component {
    constructor(props) {
        super(props);
        this.tabValue = new Animated.Value(1)
        this.textOpacity = new Animated.Value(1)
        this.rotateIcon = new Animated.Value(0)

    }

    componentDidUpdate(prevProps) {
        this.animateTabWidth()
    }

    animateTabWidth = () => {
        this.tabValue.setValue(0)
        this.textOpacity.setValue(0)
        this.rotateIcon.setValue(0)
        Animated.sequence([
            Animated.parallel([
                Animated.timing(this.tabValue, {
                    toValue: 1,
                    duration: 300,
                    useNativeDriver: true,
                    easing: Easing.linear
                }),
                Animated.timing(this.textOpacity, {
                    toValue: 1,
                    duration: 550,
                    useNativeDriver: true,
                    easing: Easing.linear
                })
            ]),
            Animated.timing(this.rotateIcon, {
                toValue: 1,
                duration: 400,
                useNativeDriver: true,
                easing: Easing.linear
            })
        ]).start()
    }

    render() {

        const { navigation, route } = this.props;

        const interpolateIcon = this.rotateIcon.interpolate({
            inputRange: [0, 0.5, 1],
            outputRange: ['0deg', '40deg', '0deg']
        });

        const isFocused = navigation.isFocused();




        return (
            <View style={[styles.bubbleContainer, { height: 70, }]}>
                {routes.map((routeList, routeIndex) => {
                    const isRouteActive = isFocused === true && route.name === routeList.navigateTo;
                    const tintColor = isRouteActive ? ('#fffff') : ('#fffff')
                    return (
                        <Animated.View style={isRouteActive && { transform: [{ scaleX: this.tabValue }] }} key={routeIndex}>
                            <TouchableOpacity
                                style={isRouteActive && [styles.single_tab, {}] || {}}
                                onPress={() => {
                                    routeList.navigateTo && navigation.navigate(routeList.navigateTo) || console.log('no route found')
                                }}

                            >
                                <Animated.View style={isRouteActive && { transform: [{ rotate: interpolateIcon }] }}>
                                    <Image source={routeList.icon} style={{
                                        width: 29,
                                        height: 29, resizeMode: 'cover'
                                    }}
                                        tintColor={tintColor}
                                    />
                                </Animated.View>
                                {isRouteActive && <Animated.Text style={[styles.tab_name, {}]}>
                                    {routeList.routeName}
                                </Animated.Text>}
                            </TouchableOpacity>
                        </Animated.View>
                    )
                })}

            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flexDirection: "row",
        elevation: 2,
        alignItems: "center",
    },
    bubbleContainer: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: "space-around",
        alignItems: "center",

        backgroundColor: "#3d3cb3",
        shadowColor: "rgba(90, 108, 234, 0.1)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 50,
        shadowOpacity: 1
    },
    scaler: { flex: 1, justifyContent: "center", alignItems: "center" },
    semiCircle: {
        height: 25,
        width: 40,
        borderTopRightRadius: 50,
        borderTopLeftRadius: 50,
        position: "absolute",
        zIndex: -1
    },
    single_tab: {

        alignItems: "center",
        justifyContent: "space-evenly",
        flexDirection: 'row',
        width: 105,
        height: 44,
        borderRadius: 12,
        backgroundColor: "rgba(101, 148, 187,0.3)",

    },
    tab_name: {
        alignItems: 'center',
        alignSelf: 'center',
        fontFamily: "Montserrat-SemiBold",
        fontSize: 12,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 15.7,
        letterSpacing: 0,
        color: "#ffffff"
    },
    animatedView: {
        height: 60,
        width: 60,
        position: "absolute",
        borderRadius: 50,
    }
})

export default TabBarNavigation