import React from 'react';
import {
    SafeAreaView,
    StatusBar,
    StyleSheet
} from 'react-native';
import { TransitionPresets, createStackNavigator } from '@react-navigation/stack';


import { LanguageScreen, IntroScreenOne, IntroScreenTwo } from './../screens/onboarding';
import OnBoardingHeader from './../components/shared/OnBoardingHeader';

const Stack = createStackNavigator();
const screenOptionStyle = {
    ...TransitionPresets.SlideFromRightIOS,
};

export const OnBoardingStack = () => {
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: "rgb(246, 246, 246)" }]}>
            <StatusBar
                animated={true}
                backgroundColor="rgb(246, 246, 246)"
                barStyle={"dark-content"}

            />
            <Stack.Navigator
                initialRouteName="LanguageScreen"
                screenOptions={screenOptionStyle}
            >
                <Stack.Screen name="LanguageScreen" component={LanguageScreen} options={{ headerShown: false }} />
                <Stack.Screen name="IntroScreenOne" component={IntroScreenOne} options={{ headerShown: false }} />
                <Stack.Screen name="IntroScreenTwo" component={IntroScreenTwo} options={{ headerShown: false }} />
            </Stack.Navigator >
        </SafeAreaView>
    )
}

export const styles = StyleSheet.create({
    container: {
        flex: 1,
    },

});