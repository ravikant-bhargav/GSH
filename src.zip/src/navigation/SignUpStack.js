import React from 'react';
import {
    SafeAreaView,
    StatusBar,
    StyleSheet
} from 'react-native';
import { TransitionPresets, createStackNavigator } from '@react-navigation/stack';


import { SignUpScreen } from './../screens/signup';
import OtpVerification from './../screens/signup/OtpVerification';

const Stack = createStackNavigator();
const screenOptionStyle = {
    ...TransitionPresets.SlideFromRightIOS,
};

export const SignUpStack = () => {
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: "#3d3cb3" }]}>
            <StatusBar
                animated={true}
                backgroundColor="#3d3cb3"
                barStyle={"dark-content"}
            />
            <Stack.Navigator
                initialRouteName="SignUpScreen"
                screenOptions={screenOptionStyle}
            >
                <Stack.Screen name="SignUpScreen" component={SignUpScreen} options={{ headerShown: false }} />
                <Stack.Screen name="OtpVerification" component={OtpVerification} options={{ headerShown: false, }} />

            </Stack.Navigator >
        </SafeAreaView>
    )
}

export const styles = StyleSheet.create({
    container: {
        flex: 1,
    },

});