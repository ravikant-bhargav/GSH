import { getApi,} from '../../utils/apiServices';
const bannerurl='common/systemSetting';


export const getsystemsetting = async (token) => {
    let putData = {
    };
    const config = {
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
            Authorization : `Bearer ${token}`}
    };

        let resdata = await getApi(bannerurl, config,)
            .then((response) => {
                return response;
    
            }).catch(function (error) {
                return error;
            });
       // console.log('Dashboard>>>',resdata)
        return resdata;
    
    }