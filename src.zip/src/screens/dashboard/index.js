import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  Button,
  Modal,
  Dimensions,
  Alert,
} from "react-native";

import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";
import { AppButton } from "../../components/button/AppButton";
import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import CalendarCardView from "../../components/calendar/CalendarCardView";
import OrderStatusLabels from "../../components/OrderStatusLabels";
import FeaturedProduct from "./FeaturedProduct";
import CategoryByProduct from "../category/CategoryByProduct";
import ShopByCategory from "./ShopByCategory";
import TabBarNavigation from "../../navigation/TabBarNavigation";
import DashboardHeader from "../../components/shared/DashboardHeader";
import { getsystemsetting } from "../dashboard/DashboardService";

import { ProductDetails } from "../product/ProductDetails";
import { useDrawerProgress, useDrawerStatus } from "@react-navigation/drawer";
import Animated, { Extrapolate } from "react-native-reanimated";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import Loader from "../../components/Loader";
import { getCatagoryApi } from ".././category/catagoryApiCall";
import { getProductallApi } from "./../product/ProductCallApi";
import { getprofileApi } from "./../myaccount/ProfileApiService";
import Zipcode from "../../components/Zipcode";
const { width } = Dimensions.get("window");
import { EditAddress, getAddresslist } from "../myaddress/AddressService";
// const colours = ['#457dd2', '#cbb2fe', '#fec89a', '#5fdad8', '#44b3de','#5d95ea','#58cffd'];

const Dashboard = (props) => {
  const [isLoading, setIsLoading] = React.useState(false);
  const [product, setproduct] = useState([]);
  const [catagory, setcatagory] = useState([]);
  const [Name, setName] = useState(null);
  const [City, setCity] = useState(null);
  const [Street_address, setStreet_address] = useState(null);
  const [Zip_code, setZip_code] = useState(null);
  const [systemSetting, setsystemSetting] = useState("");

  // This is to manage Modal State
  const [isModalVisible, setModalVisible] = useState(false);

  // This is to manage TextInput State
  const [inputValue, setInputValue] = useState("");
  const [zipVal, setzipValue] = useState("");

  const getUserDetailsmethodApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    // setIsLoading(true);
    const reasData = await getprofileApi(token);
    if (reasData && reasData.status === 200) {
      let user_details = reasData.data.data;
      if (user_details.name == null || user_details.name == "") {
        await AsyncStorage.setItem(appConstant.NAME, "");
      } else {
        await AsyncStorage.setItem(appConstant.NAME, user_details.name || "");
      }

      if (user_details.email == null || user_details.email == "") {
        await AsyncStorage.setItem(appConstant.EMAIL, "");
      } else {
        await AsyncStorage.setItem(appConstant.EMAIL, user_details.email || "");
      }
      let phone = user_details.phone_number;

      let res = phone.replace("+91", "");

      await AsyncStorage.setItem(
        appConstant.NAME,
        user_details.name ? user_details.name : "Guest"
      );
      await AsyncStorage.setItem(
        appConstant.EMAIL,
        user_details.email ? user_details.email : ""
      );
      await AsyncStorage.setItem(appConstant.PHONENUMBER, res);
      if (
        reasData.data.data.user_addresses.length == 0 ||
        reasData.data.data.user_addresses.length == ""
      ) {
        // await AsyncStorage.setItem(appConstant.Zip_code,'');
        CheckLocalDb();
      } else {
        console.log("else body");

        getsddresslistApi();
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      //  setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  const getProductmethodApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    // setIsLoading(true);
    const reasData = await getProductallApi(token);
    if (reasData && reasData.status === 200) {
      //  setIsLoading(false);
      // let msg = reasData?.data?.status?.message || "";
      // Alert.alert("", msg);
      setproduct(reasData.data.data);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      //  setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  const getCatagorymethodApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    console.log("token", token);
    // setIsLoading(true);
    const reasData = await getCatagoryApi(token);
    if (reasData && reasData.status === 200) {
      //  setIsLoading(false);
      // let msg = reasData?.data?.status?.message || "";
      // Alert.alert("", msg);
      setcatagory(reasData.data.data);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      //  setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  const getCommoneApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);

    // setIsLoading(true);
    const reasData = await getsystemsetting(token);
    if (reasData && reasData.status === 200) {
      //  setIsLoading(false);
      // let msg = reasData?.data?.status?.message || "";
      // Alert.alert("", msg);

      var val = reasData.data.data;
      setsystemSetting(val[0].banner_image);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      //  setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  useEffect(() => {
    getCommoneApi();
    getProductmethodApi();
    getCatagorymethodApi();
    getUserDetailsmethodApi();
    /// CheckLocalDb();
    getLocalDB();
  }, []);

  console.log("Dashboard>>>", systemSetting);
  const drawerStatus = useDrawerStatus();
  let progress = drawerStatus === "open" ? 1 : 0;

  const navigateToScreen = (screenName) => {
    props.navigation.navigate(screenName);
  };
  const toggleModalVisibility = () => {
    setModalVisible(!isModalVisible);
  };
  const CheckLocalDb = async () => {
    try {
      const value = await AsyncStorage.getItem(appConstant.Zip_code);
      if (value !== null) {
        // We have data!!
        setModalVisible(false);
      } else {
        setModalVisible(true);
      }
    } catch (error) {
      // Error retrieving data
    }
  };

  const checkzipcode = async () => {
    if (!zipVal) {
      Alert.alert("Zip code  is required");

      return;
    } else {
      console.log("zipVal==>", zipVal);
      setModalVisible(false);
      await AsyncStorage.setItem(appConstant.Zip_code, "" + zipVal.toString());
    }
  };

  const scale = Animated.interpolateNode(progress, {
    inputRange: [0, 1],
    outputRange: [1, 0.9],
    extrapolateRight: Extrapolate.CLAMP,
  });
  const borderRadius = Animated.interpolateNode(progress, {
    inputRange: [0, 1],
    outputRange: [1, 26],
    extrapolateRight: Extrapolate.CLAMP,
  });
  const animatedStyle = {
    borderRadius,
    transform: [{ scale }],
  };

  const toggleDrawer = () => {
    props.navigation.toggleDrawer();
  };

  const getLocalDB = async () => {
    let Name = await AsyncStorage.getItem(appConstant.NAME);
    if (Name !== null) {
      // do something
      setName(Name);
    } else {
      // do something else
      setName("Users");
    }
    let City = await AsyncStorage.getItem(appConstant.City);
    console.log(">>>>>>>>>>>>.CITY>>>>>", City);
    if (City !== null) {
      // do something
      setCity(City);
    }
    //  else {
    //   // do something else
    //   setCity("Select Your Address");
    // }
    let Street_address = await AsyncStorage.getItem(appConstant.Street_address);
    if (Street_address !== null) {
      // do something
      setStreet_address(Street_address);
    } else {
      // do something else
      setStreet_address("");
    }
    let Zip_code = await AsyncStorage.getItem(appConstant.Zip_code);
    if (Zip_code !== null) {
      // do something
      setZip_code(Zip_code);
    } else {
      // do something else
      setZip_code("");
    }
  };

  const getaddrressValue = (value) => {
    console.log("Get Value>>>", value);

    let straddress_type = value.address_type;
    let strcity = value.city;
    let strlandmark = value.landmark;
    let strstate = value.state;
    let strstreet_address = value.street_address;
    let strzip_code = value.zip_code;
    var setdefault = true;
    let ID = value.id;
    //  setLocalDB(strshipping_address_id,strbilling_address_id,
    //     straddress_type,strcity,strlandmark,strstate,strstreet_address,strzip_code);
    editAddressApi(
      ID,
      straddress_type,
      strstreet_address,
      strcity,
      strlandmark,
      strstate,
      strzip_code,
      setdefault
    );
  };

  const editAddressApi = async (
    ID,
    straddress_type,
    strstreet_address,
    strcity,
    strlandmark,
    strstate,
    strzip_code,
    setdefault
  ) => {
    setIsLoading(true);
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let phone = await AsyncStorage.getItem(appConstant.PHONENUMBER);
    const reasData = await EditAddress(
      token,
      ID,
      phone,
      straddress_type,
      strstreet_address,
      strcity,
      strlandmark,
      strstate,
      strzip_code,
      setdefault
    );
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      getsddresslistApi();
      // setLocalDB(strshipping_address_id,strbilling_address_id,
      //     straddress_type,strcity,strlandmark,strstate,strstreet_address,strzip_code);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  const getsddresslistApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getAddresslist(token, 1);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);

      for (i = 0; i < reasData.data.data.length; i++) {
        if (reasData.data.data[i].is_default == true) {
          await AsyncStorage.setItem(
            appConstant.Shipping_address_id,
            "" + reasData.data.data[i].id.toString()
          );
          await AsyncStorage.setItem(
            appConstant.Billing_address_id,
            "" + reasData.data.data[i].id.toString()
          );
          await AsyncStorage.setItem(
            appConstant.Address_type,
            reasData.data.data[i].address_type
          );

          await AsyncStorage.setItem(
            appConstant.City,
            reasData.data.data[i].city
          );
          await AsyncStorage.setItem(
            appConstant.Landmark,
            reasData.data.data[i].landmark
          );
          await AsyncStorage.setItem(
            appConstant.State,
            reasData.data.data[i].state
          );
          await AsyncStorage.setItem(
            appConstant.Street_address,
            reasData.data.data[i].street
          );
          await AsyncStorage.setItem(
            appConstant.Zip_code,
            "" + reasData.data.data[i].zipcode.toString()
          );
        }
      }
      getLocalDB();
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  return (
    <Animated.View style={{ flex: 1 }}>
      <Modal
        animationType="slide"
        transparent
        visible={isModalVisible}
        presentationStyle="overFullScreen"
        onDismiss={toggleModalVisibility}
      >
        <View style={styles.viewWrapper}>
          <View style={styles.modalView}>
            <View style={{ marginVertical: 10 }}>
              <Text style={styles.formTextHeading}>Enter Area Pincode</Text>
              <Text style={styles.formSubHeading}>
                Helps you to find nearby delivery partner
              </Text>
              <Zipcode getzipVal={(e) => setzipValue(e)} />
            </View>
            <Button
              title="Save"
              onPress={() => {
                console.log("zipVal.length>>", zipVal.length);
                if (zipVal.length == 6) {
                  checkzipcode();
                } else {
                  //
                  Alert.alert("Zip code  is required");
                }
              }}
            />
            {/* <Button title="Close" onPress={toggleModalVisibility} /> */}
          </View>
        </View>
      </Modal>
      <DashboardHeader
        headerTitle={"Hi," + Name}
        headerTitle1={
          City === null ? "Add Your Address" : City + "-" + Street_address
        }
        pencilEditIcon={true}
        onEditclick={() => {
          props.navigation.navigate("MyAddress", {
            onGoBack: (e) => getaddrressValue(e),
          });
        }}
        navScreen={props.navigation}
        onPress={() => navigateToScreen()}
        onPressToggle={() => toggleDrawer()}
        drawerStatus={progress}
      />
      <MiddleContentWrapper>
        {/* <SafeAreaView style={styles.screen}>
          <StatusBar style="auto" />
        </SafeAreaView> */}
        <View style={{ padding: 10 }}>
          <CalendarCardView
            onPress={() => {
              navigateToScreen("OrderList");
            }}
          />
          <OrderStatusLabels />
          <View style={styles.bannerContainer}>
            {/* <Image source={images.milkBanner} style={{ width: '100%', resizeMode: 'cover' }} /> */}

            {/* <Image
              source={{
                uri: "https://gsh-dev.s3.ap-south-1.amazonaws.com/brands/GSH-31e1b8a9-ec6a-4d87-9732-81861c2f8a3c.jpg",
              }}
              style={{ width: "100%", resizeMode: "cover" }}
            /> */}
          </View>
        </View>
        <View
          style={{
            height: 100,
            width: "100%",
            backgroundColor: "#EAEAEA",
            justifyContent: "center",
            alignContent: "center",
            alignItems: "center",
          }}
        >
          <Image
            source={{
              uri: systemSetting,
            }}
            style={{ height: 100, width: "95%", resizeMode: "stretch" }}
          />
        </View>

        <View style={[styles.showAllContainer, { padding: 10 }]}>
          <View style={styles.firstLineContainer}>
            <Text style={styles.boldTextStyle}>Featured Products</Text>
            <TouchableOpacity
              onPress={() => {
                navigateToScreen("CategoryProduct", product);
              }}
            >
              <Text style={styles.shopAllTextStyle}>Show all</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.secondLineContainer}>
            <Text style={styles.subHeadingText}>
              Top products for easy shoping
            </Text>
          </View>
        </View>
        <FeaturedProduct product={product} navscreen={props} />

        {/* product={product} navscreen={props} */}

        <View style={{ padding: 10 }}>
          <View style={[styles.showAllContainer, {}]}>
            <View style={styles.firstLineContainer}>
              <Text style={styles.boldTextStyle}>Shop By Category</Text>
              <TouchableOpacity
                onPress={() => {
                  navigateToScreen("Category", catagory);
                }}
              >
                <Text style={styles.shopAllTextStyle}>Show all</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.secondLineContainer}>
              <Text style={styles.subHeadingText}>
                Top products for easy shoping
              </Text>
            </View>
          </View>
          <ShopByCategory catagory={catagory} navscreen={props} />
        </View>

        <View style={{ height: 50 }} />
      </MiddleContentWrapper>
      {/* catagory={catagory} navscreen={props} */}
      <TabBarNavigation
        navigation={props.navigation}
        isRouteActive={true}
        routeIndex={0}
        {...props}
      />
    </Animated.View>
  );
};

export const styles = StyleSheet.create({
  bannerContainer: {
    marginTop: 10,
  },
  showAllContainer: {
    padding: 5,
  },
  firstLineContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  boldTextStyle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    color: "#09051c",
  },
  shopAllTextStyle: {
    //height:15,
    fontFamily: "Montserrat-Bold",
    fontSize: 12,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 15.7,
    letterSpacing: 0,
    color: "#457dd2",
  },
  subHeadingText: {
    fontFamily: "Montserrat-Medium",
    fontSize: 8,
    fontWeight: "500",
    fontStyle: "normal",
    lineHeight: 10.5,
    letterSpacing: 0,
    textAlign: "left",
    color: "#09051c",
  },
  screen: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
  },
  viewWrapper: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
    borderStyle: "solid",
  },
  modalView: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 7,
    padding: 10,
  },

  formButtonLinear: {
    height: 57,
    borderRadius: 10,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  linerButtonText: {
    width: "30%",
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#ffffff",
  },
  formTextHeading: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 16,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 26.2,
    letterSpacing: 0,
    //textAlign: "center",
    color: "#2c2c2d",
  },
  formSubHeading: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#2c2c2d",
    marginTop: 6,
    marginBottom: 9,
  },
});

export default Dashboard;
