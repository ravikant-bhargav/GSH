import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
} from "react-native";
import images from "../../utils/sharedImages";
import ProductDetails from "../product/ProductDetails";

const FeaturedProduct = (props) => {
  /// console.log('props>>>',props)

  return (
    <React.Fragment>
      <View style={[styles.showAllContainer, { marginLeft: 10 }]}>
        <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
          <View style={styles.categoryContainer}>
            {props.product &&
              props.product.length > 0 &&
              props.product.map((item, index) => {
                return (
                  <TouchableOpacity
                    key={index}
                    onPress={() => {
                      console.log("itemID==>>", item.id);
                      let itemId = item.id;
                      props.navscreen.navigation.navigate("ProductDetails", {
                        itemId,
                        fromScreen: "FeaturedProduct",
                      });
                    }}
                  >
                    <View style={[styles.categoryList]}>
                      <Image
                        source={{ uri: item.product_images[0].url }}
                        style={{
                          borderTopLeftRadius: 8,
                          borderTopRightRadius: 8,
                          width: "100%",
                          height: "70%",
                        }}
                        resizeMode={"cover"}
                      />
                      <View style={{ height: "3%" }} />
                      <View style={styles.productDetail}>
                        <View style={styles.productfirstLineContainer}>
                          <Text style={styles.productNameStyle}>
                            {item.name}
                          </Text>
                          {/* <Text
                            numberOfLines={1}
                            ellipsizeMode="tail"
                            style={styles.productQtyStyle}
                          >
                            {item.description}
                          </Text> */}
                        </View>

                        <View style={styles.productAddButton}>
                          <Text style={styles.productAddText}>Add</Text>
                          <Image
                            source={images.AddButton}
                            style={{
                              width: 12,
                              height: 12,
                              resizeMode: "cover",
                            }}
                          />
                        </View>
                      </View>
                    </View>
                  </TouchableOpacity>
                );
              })}
          </View>
        </ScrollView>
      </View>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  featuredProductContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingLeft: 10,
    marginTop: 10,
  },
  categoryContainer: {
    flex: 1,
    flexWrap: "wrap",
    flexDirection: "row",
    marginTop: 15,
  },
  categoryList: {
    flexBasis: "20%",
    width: 140.7,
    height: 140.7,
    marginLeft: 5,
    marginRight: 5,
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
    justifyContent: "center",
    alignItems: "center",
    margin: 8,
    backgroundColor: "#ffffff",
    borderRadius: 8,
  },
  featuredProductDetail: {
    width: "148%",
    height: "148%",
    borderRadius: 8,
    backgroundColor: "#fdfdfd",
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    marginRight: 7,
  },
  productDetail: {
    height: "27%",
    padding: 5,
    flexDirection: "row",
  },
  productNameStyle: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 10,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 11.1,
    letterSpacing: 0,
    color: "#000",
  },
  productQtyStyle: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 8,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 8.6,
    letterSpacing: 0,
    textAlign: "left",
    color: "#000000",
  },
  productAddButton: {
    width: 48,
    height: 22,
    borderRadius: 5,
    backgroundColor: "rgba(20, 182, 97, 0.65)",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },
  productAddText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 9,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 11.1,
    letterSpacing: 0,
    textAlign: "left",
    color: "#ffffff",
    marginRight: 3,
  },
  productfirstLineContainer: {
    flex: 1,
  },
});

export default FeaturedProduct;
