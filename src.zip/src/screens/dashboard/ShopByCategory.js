import { Background } from "@react-navigation/elements";
import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  FlatList,
} from "react-native";
const colours = [
  "#dcdcdcdc",
  "#dcdcdcdc",
  "#dcdcdcdc",
  "#dcdcdcdc",
  "#dcdcdcdc",
  "#dcdcdcdc",
  "#dcdcdcdc",
  "#dcdcdcdc",
];
const ShopByCategory = (props) => {
  return (
    <React.Fragment>
      <View style={[styles.showAllContainer, {}]}>
        <View style={styles.categoryContainer}>
          {props.catagory &&
            props.catagory.length > 0 &&
            props.catagory.slice(0, 8).map((item, index) => {
              return (
                <TouchableOpacity
                  key={index}
                  onPress={() => {
                    let itemId = item.id;
                    console.log("catagory ID>>", itemId);
                    props.navscreen.navigation.navigate(
                      "CategoryByProduct",
                      itemId
                    );
                  }}
                  style={[
                    styles.categoryList,
                    {
                      // backgroundColor: colours[index]
                      backgroundColor: "#ffffff",
                    },
                  ]}
                >
                  <Image
                    resizeMode={"cover"}
                    source={{ uri: item.image }}
                    style={{
                      borderTopLeftRadius: 6,
                      borderTopRightRadius: 6,
                      width: "100%",
                      height: "75%",
                      resizeMode: "cover",
                    }}
                  />
                  <Text style={styles.categoryText}>{item.name}</Text>
                </TouchableOpacity>
              );
            })}
        </View>
      </View>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  categoryList: {
    flexBasis: "22%",
    width: "22%",
    height: 81.9,
    backgroundColor: "#FFFFFF",
    borderColor: "#000000",
    borderRadius: 6,
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
    alignItems: "center",

    margin: 5.2,
  },
  categoryText: {
    fontFamily: "Montserrat-Black",
    fontSize: 9,
    fontWeight: "900",
    fontStyle: "normal",
    lineHeight: 11.1,
    marginTop: 3,
    letterSpacing: 0,
    textAlign: "center",
    color: "#3D3CB2",
  },
  categoryContainer: {
    flex: 1,
    flexWrap: "wrap",
    flexDirection: "row",
    marginTop: 15,
  },
});

export default ShopByCategory;
