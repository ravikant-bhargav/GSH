import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
    FlatList,
    Dimensions,
    Modal,
    Pressable,
    Alert
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Loader from '../../components/Loader';
import AsyncStorage from '@react-native-async-storage/async-storage';
import appConstant from '../../utils/appConstant';
// import {postaddnewAddress} from '../myaddress/AddressService'
const EditOrderAddress = (props) => {

  const [Lable, onChangeLable] = useState('');
   const [city, onChangecity] = useState('');
  const [landmark, onChangelandmark] = useState('');
  const [state, onChangestate] = useState('');
  const [zip_code, onChangezip_code] = useState('');
  const [isLoading, setIsLoading] = React.useState(false);
 let order_id=props.route.params.orderValue.order_id;
 console.log('Order ID>>',order_id);


  console.log('EditOrder>>',props.route.params.orderValue);



  return (
    <React.Fragment>
            <Text style={[styles.amountHeading, { marginTop: 2 ,}]}>Select Details</Text>
            <View style={styles.formContainer}>
                <View>
              
                    <View style={{ marginTop: 10 }}>
                        <TextInput
                            style={styles.formTextInput}
                            keyboardType="default"
                            onChangeText={onChangeLable}
                            value={Lable}
                            placeholder='Add Lable'
                            placeholderTextColor={"#A8A8A8"}
                        />
                    </View>
                </View>   
                <View>
                    <View style={{ marginTop: 10 }}>
                        <TextInput
                            style={styles.formTextInput}
                            keyboardType="default"
                            onChangeText={onChangelandmark}
                            value={landmark}
                            placeholder='landmark'
                            placeholderTextColor={"#A8A8A8"}
                        />
                    </View>
                </View>
                <View>
                    <View style={{ marginTop: 10 }}>
                        <TextInput
                            style={styles.formTextInput}
                            keyboardType="default"
                            onChangeText={onChangecity}
                            value={city}
                            placeholder='City'
                            placeholderTextColor={"#A8A8A8"}
                        />
                    </View>
                </View>
                <View>
                    <View style={{ marginTop: 10 }}>
                        <TextInput
                            style={styles.formTextInput}
                            keyboardType="default"
                            onChangeText={onChangestate}
                            value={state}
                            placeholder='State'
                            placeholderTextColor={"#A8A8A8"}
                        />
                    </View>
                </View>
                <View>
                    <View style={{ marginTop: 10 }}>
                        <TextInput
                            style={styles.formTextInput}
                            keyboardType="number-pad"
                            onChangeText={onChangezip_code}
                            value={zip_code}
                            placeholder='Zip code'
                            placeholderTextColor={"#A8A8A8"}
                        />
                    </View>
                </View>
                <TouchableOpacity style={{ marginTop: 15 }} 
               onPress={() => { 
               
                  }} >
                    <LinearGradient
                        colors={['#3d3cb3', 'rgba(61, 60, 179, 0.73)']}
                        style={styles.formButtonLinear}
                       >
                          <TouchableOpacity  
                   onPress={() => { 
                       if(Lable==''||city==''||landmark==''||state==''||zip_code==''){
                        Alert.alert('Please Check address details')
                       }else{

                        
                       }

                         

                 
                      }} >
                        <Text style={styles.linerButtonText}>Save</Text>
                        </TouchableOpacity>
                    </LinearGradient>
                </TouchableOpacity>
            </View>
    </React.Fragment>


);
    }
    const styles = StyleSheet.create({  
      header:{
        backgroundColor: '#3d3cb3',
        height:170,
      },
      avatar: {
        width: 130,
        height: 130,
        borderRadius: 63,
        borderWidth: 4,
        borderColor: "white",
        marginBottom:10,
        alignSelf:'center',
        position: 'absolute',
        marginTop:50
      },
    
    formContainer: {
        marginLeft:18,
        marginRight:15,
    
    
    },
    formTextHeading: {
        fontFamily: "Montserrat-ExtraBold",
        fontSize: 22,
        fontWeight: "800",
        fontStyle: "normal",
        lineHeight: 28.8,
        letterSpacing: 0,
        color: "#2c2c2d"
    },
    formTextInput: {
        height: 60,
        borderRadius: 12,
        borderStyle: "solid",
        borderWidth: 2.5,
        borderColor: '#A8A8A8',
        padding: 18,
        fontFamily: "Montserrat-SemiBold",
        fontSize: 15,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 19.7,
        letterSpacing: 0.75,
        color: "#2c2c2d"
    
    },
    formButtonLinear: {
        height: 45,
        borderRadius: 10,
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 12,
            height: 26
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        justifyContent: 'center',
        alignItems: 'center'
    
    },
    linerButtonText: {
        fontFamily: "Montserrat-Bold",
        fontSize: 15,
        fontWeight: "bold",
        fontStyle: "normal",
        letterSpacing: 0.5,
        textAlign: "left",
        color: "#ffffff"
    },
    
    
    
    lineContainer: {
        marginTop: 30,
        marginBottom: 30,
        flexDirection: 'row',
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center'
    },
    
    lineSeprator: {
        width: 129,
        height: 1.5,
        opacity: 0.5,
        backgroundColor: "#000000",
    
    },
    lineText: {
        opacity: 0.5,
        fontFamily: "Montserrat-SemiBold",
        fontSize: 13,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 21.6,
        letterSpacing: 0,
        textAlign: "center",
        color: "rgba(9, 5, 28, 0.64)",
        marginLeft: 15,
        marginRight: 15,
    
    },
    
    
    
    
    buttonContainer: {
        // flex: 1,
        justifyContent: 'center',
        height: 51,
        borderRadius: 12,
        borderStyle: "solid",
        borderWidth: 2,
        borderColor: "rgb(61, 60, 179)",
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10
    
    },
    
    buttonAlignment: {
    
        backgroundColor: "#ffffff",
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        // padding:10
    
    },
    buttonText: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 15,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 19.7,
        letterSpacing: 0,
        textAlign: "left",
        color: "rgb(61, 60, 179)"
    
    
    },
    buttonContainerWithColor: {
        // flex: 1,
        justifyContent: 'center',
        height: 51,
        borderRadius: 12,
        borderStyle: "solid",
    
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10,
        backgroundColor: "#1877f2",
    
    
    
    },
    buttonAlignmentWithColor: {
    
        backgroundColor: "#1877f2",
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row'
    
    },
    buttonTextWithColor: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 14,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 18.3,
        letterSpacing: 0,
        //  textAlign: "left",
        color: "#ffffff",
    
    
    
    },
    imageButton: {
        width: 28.3,
        height: 29,
        borderRadius: 5,
        shadowColor: "rgba(0, 0, 0, 0.09)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 4,
        shadowOpacity: 1,
        marginRight: 15
    }, amountHeading: {
      fontFamily: "Montserrat-Bold",
      fontSize: 14,
      fontWeight: "bold",
      fontStyle: "normal",
      lineHeight: 15.7,
      letterSpacing: 0,
      textAlign: "center",
      color: "#09051c",
      alignItems: 'flex-start',
    
    },
    productAddress: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 12,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 16.3,
        letterSpacing: 0,
        textAlign: "left",
        color: "#332b55"
    
    },
    
      });  
    export default EditOrderAddress;