import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
} from "react-native";

import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";
import { AppButton } from "../../components/button/AppButton";

import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import CalendarCardView from "../../components/calendar/CalendarCardView";
import OrderStatusLabels from "../../components/OrderStatusLabels";
import AmountAdjustment from "../../components/AmountAdjustment";
import HorizontalLine from "../../components/HorizontalLine";

import DashboardHeader from "../../components/shared/DashboardHeader";
import PrimaryButton from "../../components/button/PrimaryButton";
import LinearGradientView from "../../components/LinearGradientView";
import ProductCard from "../orderlist/ProductCard";
import TabBarNavigation from "../../navigation/TabBarNavigation";
import PrimaryButtonResize from "../../components/button/PrimaryButtonResize";
import OrderHistory from "./OrderHistory";

const productData = [
  {
    key: 112,
    value: [
      {
        productName: "Anik Pure Milk",
        qty: "200 ml",
        planType: "Daily",
        amount: 114,
        date: "23 Mon 2022",
        order_status: "Order Delivered",
        image: images.productImg1,
        order_status_code: "1",
      },
      {
        productName: "Anik Pure Milk",
        qty: "6 Pcs",
        planType: "Daily",
        amount: 114,
        date: "23 Mon 2022",
        order_status: "Active Order",
        image: images.productImg2,
        order_status_code: "-1",
      },
    ],
  },
];

const orderStatus = {
  HISTORY: "History",
  PENDING: "Pending",
};

const OrderPending = (props) => {
  const [orderType, setOrderType] = useState(orderStatus.PENDING);
  const navigateToScreen = () => {
    props.navigation.goBack();
  };

  getOrders = (order_type) => {
    setOrderType(order_type);
  };
  // console.log("order>>", props.nav);

  return (
    <React.Fragment>
      {/* {props.nav &&
        props.nav.length > 0 &&
        props.nav.map((item, index) => {
          return ( */}
      <View style={styles.productSubContainer} key={props.nav.order_id}>
        <View style={[styles.productInnerContainer, {}]}>
          <View
            style={[
              styles.productDetailContainer,
              { flexDirection: "row", padding: 5 },
            ]}
          >
            {/* <Image source={images.productImg1} style={{ resizeMode: 'cover' }} /> */}
            <View style={{ marginLeft: 5, flex: 1, marginTop: 8 }}>
              <Text style={styles.productNameText}>
                Order ID- {props.nav.order_id}
              </Text>
              <View style={[styles.productStatus, { marginTop: 2 }]}>
                <Text style={styles.productStatusText}>
                  {props.nav.order_delivery_type.replace("_", "")}
                </Text>
              </View>
              {/* <Text style={[styles.productPlanTypeText, { marginTop: 4 }]}>
                Delivery Time : {props.nav.delivery_time}
              </Text> */}
            </View>
          </View>
          <View style={styles.productAmountContainer}>
            <View
              style={{
                flex: 1,
                marginTop: 3,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <TouchableOpacity
                onPress={() => {
                  let id = props.nav.order_id;
                  props.navscreen.navigation.navigate("OrderDetailspage", id);
                }}
              >
                <View style={[styles.productAmountButton, { marginTop: 4 }]}>
                  <Text style={[styles.productButtonText, {}]}>View</Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
      {/* ); })} */}
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  showAllContainer: {
    paddingLeft: 15,
    paddingRight: 15,
  },
  buttonContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    alignItems: "center",
    paddingTop: 15,
    paddingBottom: 21,
  },
  buttonCustomStyle: {
    width: 109,
    height: 33,
    borderRadius: 58,
    borderStyle: "solid",
    borderWidth: 2,
  },
  buttonTextStyle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 16.4,
    letterSpacing: 0,
  },

  productContainer: {
    flex: 1,
    width: "100%",
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    //marginTop: 5
  },
  productSubContainer: {
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    marginTop: 10,
    backgroundColor: "#fff",
    paddingLeft: 10,
    paddingRight: 10,
  },
  productInnerContainer: {
    flexDirection: "row",
    marginBottom: 5,
  },
  productDetailContainer: {
    width: "70%",
    height: "100%",
    //padding: 10
  },
  productAmountContainer: {
    width: "30%",
  },
  productNameText: {
    fontFamily: "Montserrat-SemiBold",

    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#09051c",
  },
  productStatus: {
    width: "60%",
    height: 18,
    borderRadius: 16,
    backgroundColor: "#64a1fd",
    justifyContent: "center",
    alignItems: "center",
  },
  productStatusText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 11,
    fontStyle: "normal",
    lineHeight: 12,
    letterSpacing: 0,
    textAlign: "left",

    color: "#413f3f",
  },
  productPlanTypeText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 10,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 13.1,
    letterSpacing: 0,
    textAlign: "left",
    color: "#3d3cb3",
  },

  productAmountButton: {
    width: 98,
    height: 31.3,
    borderRadius: 6,
    backgroundColor: "#3d3cb3",
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  productButtonText: {
    alignSelf: "center",
    fontFamily: "Montserrat-Bold",
    fontSize: 12,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    // textAlign: "left",
    color: "#f5f5f6",
  },
});

export default OrderPending;
