import { getApi,putApi } from '../../utils/apiServices';

const OrderOngoingAPiUrl = "order/myOrders/ALL/ONGOING?";
const OrderHistoryAPiUrl = "order/myOrders/ALL/HISTORY?";
const OrderDetailsApiUrl='order/singleOrder/';
const OrderCancelApiUrl='order/cancelOrder/';
const UpdateOrderAddressApiUrl='order/updateAddress/';
export const getorderOngoingApi = async (token,offset) => {
    let putData = {
        "page": offset,
        "per_page":10
    };
    const config = {
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
            Authorization : `Bearer ${token}`}
    };

        let resdata = await getApi(OrderOngoingAPiUrl, config,putData)
            .then((response) => {
                return response;
    
            }).catch(function (error) {
                return error;
            });
        // console.log('BillpaymentService>>>',resdata)
        return resdata;
    
    }

    export const getorderHistoryApi = async (token,offset) => {
        let putData = {
            "page": offset,
            "per_page":10
        };
        const config = {
            headers: {
                'Accept': 'application/json',
                "Content-Type": "application/json",
                Authorization : `Bearer ${token}`}
        };
    
            let resdata = await getApi(OrderHistoryAPiUrl, config,putData)
                .then((response) => {
                    return response;
        
                }).catch(function (error) {
                    return error;
                });
             console.log('BillpaymentService>>>',OrderHistoryAPiUrl, config,putData)
            return resdata;
        
        }

        
    export const getorderdetailApi = async (token,offset,ID) => {
        let putData = {
            "page": offset,
            "per_page":10
        };
        const config = {
            headers: {
                'Accept': 'application/json',
                "Content-Type": "application/json",
                Authorization : `Bearer ${token}`}
        };
    
            let resdata = await getApi(OrderDetailsApiUrl+ID, config,putData)
                .then((response) => {
                    return response;
        
                }).catch(function (error) {
                    return error;
                });
             console.log('BillpaymentService>>>',OrderDetailsApiUrl+ID, config,putData)
            return resdata;
        
        }

        export const getordercancelApi = async (token,ID) => {
            const config = {
                headers: {
                    'Accept': 'application/json',
                    "Content-Type": "application/json",
                    Authorization : `Bearer ${token}`}
            };
        
                let resdata = await getApi(OrderCancelApiUrl+ID, config,'')
                    .then((response) => {
                        return response;
            
                    }).catch(function (error) {
                        return error;
                    });
                 console.log('BillpaymentService>>>',OrderDetailsApiUrl+ID, config,'')
                return resdata;
            
            }
            
            export const getorderupdateaddressApi = async (token,ID,phone,name,emailId,
                Shipping_address_id,billing_address_id,Address_type,City,Landmark,State,Street_address,Zip_code) => {

                const config = {
                    headers: {
                        'Accept': 'application/json',
                        "Content-Type": "application/json",
                        Authorization : `Bearer ${token}`}
                };
                let putData = {
                    "order_address": {
                        "delivery_pincode":Zip_code,
                        "billing_address_id":billing_address_id,
                        "shipping_address_id": Shipping_address_id,
                        "address_details": {
                            "billing_address_type": Address_type,
                            "billing_name": name,
                            "billing_email":emailId,
                            "billing_phone_number": phone,
                            "billing_street_address": Street_address,
                            "billing_landmark": Landmark,
                            "billing_city": City,
                            "billing_state": State,
                            "billing_country": "India",
                            "billing_zip_code": Zip_code,
                            "shipping_address_type": Address_type,
                            "shipping_name": name,
                            "shipping_email":emailId,
                            "shipping_phone_number": phone,
                            "shipping_street_address": Street_address,
                            "shipping_landmark": Landmark,
                            "shipping_city": City,
                            "shipping_state": State,
                            "shipping_country": "India",
                            "shipping_zip_code": Zip_code
                        }
                    }
                };
            
                    let resdata = await putApi(UpdateOrderAddressApiUrl+ID,putData, config)
                        .then((response) => {
                            return response;
                
                        }).catch(function (error) {
                            return error;
                        });
                     console.log('Update Address===>>>',UpdateOrderAddressApiUrl+ID, putData,config)
                    return resdata;
                
                }