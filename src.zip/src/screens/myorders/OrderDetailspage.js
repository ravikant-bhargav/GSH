import React, { useRef, useEffect, useState, useCallback } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  Button,
  Alert,
} from "react-native";
import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";

import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import DashboardHeader from "../../components/shared/DashboardHeader";
import TabBarNavigation from "../../navigation/TabBarNavigation";
import PrimaryButtonResize from "../../components/button/PrimaryButtonResize";
import Orderproductcard from "../../components/OrderProductCard";
import HorizontalLine from "../../components/HorizontalLine";

import DashedLine from "react-native-dashed-line";
import PaymentFooter from "../../components/PaymentFooter";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import {
  getorderdetailApi,
  getordercancelApi,
  getorderupdateaddressApi,
} from "./../myorders/OrderlistApiservice";
import Loader from "../../components/Loader";

const OrderDetailspage = (props) => {
  console.log("props data===>>>", props.route.params);

  const [isLoading, setIsLoading] = React.useState(false);
  const [Orderitems, setOrderitems] = useState([]);
  const [Order_data, setOrder_data] = useState([]);
  const [address, setaddress] = useState("");
  const [orderstatus, setorderstatus] = useState("");
  const [orderValue, setorderValue] = useState([]);

  const [shouldShowCreate, setShouldShowCreate] = useState(false);
  const [shouldShow1Create, setShouldShow1Create] = useState(true);

  const [shouldShowACCEPTED, setShouldShowACCEPTED] = useState(false);
  const [shouldShow1ACCEPTED, setShouldShow1ACCEPTED] = useState(true);

  const [shouldShowSHIPPED, setShouldShowSHIPPED] = useState(false);
  const [shouldShow1SHIPPED, setShouldShow1SHIPPED] = useState(true);

  const [shouldShowCOMPLETED, setShouldShowCOMPLETED] = useState(false);
  const [shouldShow1COMPLETED, setShouldShow1COMPLETED] = useState(true);
  const [shouldhideOrderdeliver, setshouldhideOrderdeliver] = useState(true);

  let OrderID = props.route.params;

  const navigateToScreen = () => {
    props.navigation.goBack();
  };

  const orderDetails = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getorderdetailApi(token, 1, OrderID);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      // let msg = reasData?.data?.status?.message || "";
      // Alert.alert("", msg);
      // setproduct(reasData.data.data);
      setorderValue(reasData.data.data);
      let address =
        reasData.data.data.Order_address[0].shipping_street_address +
        " , " +
        reasData.data.data.Order_address[0].shipping_city +
        ", " +
        reasData.data.data.Order_address[0].shipping_landmark +
        ", " +
        reasData.data.data.Order_address[0].shipping_state +
        ", " +
        reasData.data.data.Order_address[0].shipping_zip_code;
      setOrderitems(reasData.data.data.Order_items);
      console.log("OrderDetails==>>", reasData.data.data);
      setOrder_data(reasData.data.data);
      setaddress(address);
      setorderstatus(reasData.data.data.order_status);

      let billing_address_id = reasData.data.data.Order_address[0].id;
      let shipping_address_id = reasData.data.data.Order_address[0].id;

      //        ['ORDER_CREATED', 'ORDER_ACCEPTED', 'CANCELLED_BY_SELLER', 'CANCELLED_BY_USER',
      // 'ORDER_SHIPPED', 'ORDER_DELIVERED', 'SUBSCRIPTION_STARTED', 'SUBSCRIPTION_COMPLETED']
      if (reasData.data.data.order_status == "ORDER_CREATED") {
        setShouldShowCreate(true);
        setShouldShow1Create(false);
      } else if (reasData.data.data.order_status == "ORDER_ACCEPTED") {
        setShouldShowACCEPTED(true);
        setShouldShow1ACCEPTED(false);
      } else if (reasData.data.data.order_status == "ORDER_SHIPPED") {
        setShouldShowSHIPPED(true);
        setShouldShow1SHIPPED(false);
      } else if (reasData.data.data.order_status == "ORDER_DELIVERED") {
        setShouldShowCOMPLETED(true);
        setShouldShow1COMPLETED(false);
        setshouldhideOrderdeliver(false);
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  const CancelOrder = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getordercancelApi(token, props.route.params);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      Alert.alert("", msg);
      // setproduct(reasData.data.data);

      props.navigation.navigate("Dashboard");
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  const updateaddress = async (
    Shipping_address_id,
    billing_address_id,
    Address_type,
    City,
    Landmark,
    State,
    Street_address,
    Zip_code
  ) => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let phone = await AsyncStorage.getItem(appConstant.PHONENUMBER);
    let name = await AsyncStorage.getItem(appConstant.NAME);
    let emailId = await AsyncStorage.getItem(appConstant.EMAIL);

    setIsLoading(true);
    const reasData = await getorderupdateaddressApi(
      token,
      OrderID,
      phone,
      name,
      emailId,
      Shipping_address_id,
      billing_address_id,
      Address_type,
      City,
      Landmark,
      State,
      Street_address,
      Zip_code
    );

    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      Alert.alert("", msg);
      // setproduct(reasData.data.data);
      orderDetails();
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  useEffect(() => {
    orderDetails();
  }, []);
  const getaddrressValue = (value) => {
    let Shipping_address_id = value.id;
    let billing_address_id = value.id;
    let Address_type = value.address_type;
    let City = value.city;
    let Landmark = value.landmark;
    let State = value.state;
    let Street_address = value.street_address;
    let Zip_code = value.zip_code;

    updateaddress(
      Shipping_address_id,
      billing_address_id,
      Address_type,
      City,
      Landmark,
      State,
      Street_address,
      Zip_code
    );
  };

  return (
    <React.Fragment>
      <Loader isLoading={isLoading} />
      <DashboardHeader
        showBackArrow={true}
        headerTitle={"Order" + "\n" + "Details"}
        navScreen={props.navigation}
        headerContainerStyle={{
          borderBottomColor: "rgba(0, 0, 0, 0.14)",
          borderBottomWidth: 1,
        }}
        onPress={() => navigateToScreen()}
      />
      <MiddleContentWrapper
        navigation={props.navigation}
        {...props}
        style={{ paddingBottom: 75 }}
      >
        <View style={[styles.showAllContainer, {}]}>
          <Text style={styles.headingTitle}>
            Order ID: {props.route.params}
          </Text>
          <View style={styles.orderStatusContainer}>
            <View
              style={{
                flexDirection: "row",
                paddingLeft: 10,
                paddingRight: 10,
                paddingBottom: 10,
              }}
            >
              <View
                style={{
                  flexDirection: "column",
                  alignItems: "center",
                  width: "18%",
                  marginTop: 22,
                }}
              >
                {shouldShow1Create ? (
                  <View
                    style={{
                      width: 28,
                      height: 28,
                      backgroundColor: "rgba(61, 60, 179, 0.2)",
                      borderRadius: 20,
                    }}
                  />
                ) : null}
                {shouldShowCreate ? (
                  <Image
                    source={images.CheckProductStatusIcon}
                    style={{ width: 30, height: 30, resizeMode: "cover" }}
                  />
                ) : null}
                <Text style={[styles.statusText, {}]}>Order </Text>
                <Text style={[styles.statusText, {}]}>Place</Text>
              </View>
              <View style={{ width: "10%", justifyContent: "center" }}>
                <DashedLine
                  dashLength={8}
                  dashThickness={3}
                  dashGap={5}
                  dashColor="#3d3cb3"
                  dashStyle={{ borderRadius: 5 }}
                />
              </View>
              <View
                style={{
                  flexDirection: "column",
                  alignItems: "center",
                  width: "18%",
                  marginTop: 22,
                }}
              >
                {shouldShow1ACCEPTED ? (
                  <View
                    style={{
                      width: 28,
                      height: 28,
                      backgroundColor: "rgba(61, 60, 179, 0.2)",
                      borderRadius: 20,
                    }}
                  />
                ) : null}
                {shouldShowACCEPTED ? (
                  <Image
                    source={images.CheckProductStatusIcon}
                    style={{ width: 30, height: 30, resizeMode: "cover" }}
                  />
                ) : null}
                <Text style={[styles.statusText, {}]}>Order </Text>
                <Text style={[styles.statusText, {}]}>confirmed</Text>
              </View>
              <View style={{ width: "10%", justifyContent: "center" }}>
                <DashedLine
                  dashLength={8}
                  dashThickness={3}
                  dashGap={5}
                  dashColor="#3d3cb3"
                  dashStyle={{ borderRadius: 5 }}
                />
              </View>

              <View
                style={{
                  flexDirection: "column",
                  alignItems: "center",
                  width: "18%",
                  marginTop: 22,
                }}
              >
                {shouldShow1SHIPPED ? (
                  <View
                    style={{
                      width: 28,
                      height: 28,
                      backgroundColor: "rgba(61, 60, 179, 0.2)",
                      borderRadius: 20,
                    }}
                  />
                ) : null}
                {shouldShowSHIPPED ? (
                  <Image
                    source={images.CheckProductStatusIcon}
                    style={{ width: 30, height: 30, resizeMode: "cover" }}
                  />
                ) : null}

                <Text style={[styles.statusText1, {}]}>Order </Text>
                <Text style={[styles.statusText1, {}]}>Picked up</Text>
              </View>
              <View style={{ width: "10%", justifyContent: "center" }}>
                <DashedLine
                  dashLength={8}
                  dashThickness={3}
                  dashGap={5}
                  dashColor="#3d3cb3"
                  dashStyle={{ borderRadius: 5 }}
                />
              </View>
              <View
                style={{
                  flexDirection: "column",
                  alignItems: "center",
                  width: "18%",
                  marginTop: 22,
                }}
              >
                {shouldShow1COMPLETED ? (
                  <View
                    style={{
                      width: 28,
                      height: 28,
                      backgroundColor: "rgba(61, 60, 179, 0.2)",
                      borderRadius: 20,
                    }}
                  />
                ) : null}
                {shouldShowCOMPLETED ? (
                  <Image
                    source={images.CheckProductStatusIcon}
                    style={{ width: 30, height: 30, resizeMode: "cover" }}
                  />
                ) : null}
                <Text style={[styles.statusText1, {}]}>Order </Text>
                <Text style={[styles.statusText1, {}]}>Delivered</Text>
              </View>
            </View>
            <View
              style={{
                flexDirection: "row",
                marginTop: 15,
                paddingLeft: 20,
                paddingRight: 20,
                alignItems: "center",
              }}
            >
              <Image
                source={images.locationIcon}
                style={{ width: 38, height: 38, resizeMode: "cover" }}
              />
              <View
                style={{
                  flexDirection: "column",
                  paddingLeft: 6,
                  paddingRight: 20,
                }}
              >
                <Text
                  style={{
                    opacity: 0.8,
                    fontFamily: "Montserrat-ExtraBold",
                    fontSize: 8,
                    fontWeight: "800",
                    fontStyle: "normal",
                    letterSpacing: 0.5,
                    color: "#3d3cb3",
                  }}
                >
                  Delivery Location
                </Text>
                <Text
                  style={{
                    opacity: 0.8,
                    fontFamily: "Montserrat-SemiBold",
                    fontSize: 12,
                    fontWeight: "600",
                    fontStyle: "normal",
                    letterSpacing: 0.5,
                    color: "#101010",
                  }}
                >
                  {address}
                </Text>
              </View>
            </View>

            <View
              style={{
                flexDirection: "row",
                marginTop: 15,
                paddingLeft: 20,
                paddingRight: 20,
                alignItems: "center",
                width: "100%",
              }}
            >
              <View style={{ flexDirection: "row", width: "50%", padding: 6 }}>
                <Image
                  source={images.CalendarStatusIcon}
                  style={{ width: 26, height: 26, resizeMode: "cover" }}
                />
                <View
                  style={{
                    flexDirection: "column",
                    paddingLeft: 6,
                    paddingRight: 20,
                  }}
                >
                  <Text
                    style={{
                      opacity: 0.8,
                      fontFamily: "Montserrat-ExtraBold",
                      fontSize: 8,
                      fontWeight: "800",
                      fontStyle: "normal",
                      letterSpacing: 0.5,
                      color: "#3d3cb3",
                    }}
                  >
                    Order Date
                  </Text>
                  <Text
                    style={{
                      opacity: 0.8,
                      fontFamily: "Montserrat-SemiBold",
                      fontSize: 12,
                      fontWeight: "600",
                      fontStyle: "normal",
                      letterSpacing: 0.5,
                      color: "#101010",
                    }}
                  >
                    , <Text> </Text>{" "}
                  </Text>
                </View>
              </View>
              <View style={{ flexDirection: "row", width: "50%", padding: 6 }}>
                <Image
                  source={images.TimeStatusIcon}
                  style={{ width: 26, height: 26, resizeMode: "cover" }}
                />
                <View
                  style={{
                    flexDirection: "column",
                    paddingLeft: 6,
                    paddingRight: 20,
                  }}
                >
                  <Text
                    style={{
                      opacity: 0.8,
                      fontFamily: "Montserrat-ExtraBold",
                      fontSize: 8,
                      fontWeight: "800",
                      fontStyle: "normal",
                      letterSpacing: 0.5,
                      color: "#3d3cb3",
                    }}
                  >
                    Delivery Time
                  </Text>
                  <Text
                    style={{
                      opacity: 0.8,
                      fontFamily: "Montserrat-SemiBold",
                      fontSize: 12,
                      fontWeight: "600",
                      fontStyle: "normal",
                      letterSpacing: 0.5,
                      color: "#101010",
                    }}
                  >
                    {" "}
                  </Text>
                </View>
              </View>
            </View>
          </View>

          <HorizontalLine />
          <View style={styles.productContainer}>
            <Orderproductcard nav={Orderitems} />
          </View>
          {shouldhideOrderdeliver ? (
            <View style={{ flexDirection: "row", marginTop: 20 }}>
              <PrimaryButtonResize
                showImage={false}
                btnText={"Edit Address"}
                btnCustomStyle={{
                  width: 133,
                  borderRadius: 8,
                  borderStyle: "solid",
                  borderWidth: 2.5,
                  color: "#fff",

                  backgroundColor: "#3d3cb3",
                }}
                btnTextStyle={{
                  fontFamily: "Montserrat-Bold",
                  fontSize: 14,
                  fontWeight: "bold",
                  fontStyle: "normal",
                  lineHeight: 15.3,
                  letterSpacing: 0,
                  color: "#fff",
                }}
                onPress={() => {
                  if (
                    orderstatus == "ORDER_CREATED" ||
                    orderstatus == "ORDER_ACCEPTED"
                  ) {
                    props.navigation.navigate("MyAddress", {
                      onGoBack: (e) => getaddrressValue(e),
                    });
                  } else {
                    Alert.alert("Please check order status");
                  }
                }}
              />
              <PrimaryButtonResize
                showImage={false}
                btnText={"Cancel Order"}
                btnCustomStyle={{
                  width: 133,
                  borderRadius: 8,
                  borderStyle: "solid",
                  borderWidth: 2.5,
                  borderColor: "#3d3cb3",
                  backgroundColor: "transparent",
                }}
                btnTextStyle={{
                  fontFamily: "Montserrat-Bold",
                  fontSize: 14,
                  fontWeight: "bold",
                  fontStyle: "normal",
                  lineHeight: 15.3,
                  letterSpacing: 0,
                  color: "#3d3cb3",
                }}
                onPress={() => {
                  if (
                    orderstatus == "ORDER_CREATED" ||
                    orderstatus == "ORDER_ACCEPTED" ||
                    orderstatus == "ORDER_SHIPPED" ||
                    orderstatus == "ORDER_ACCEPTED"
                  ) {
                    Alert.alert(
                      "",
                      "Do you want to cancel order :" + props.route.params,
                      [
                        {
                          text: "Cancel",
                          onPress: () => console.log("Cancel Pressed"),
                          style: "cancel",
                        },

                        { text: "OK", onPress: () => CancelOrder() },
                      ]
                    );
                  } else {
                    Alert.alert("Not possible");
                  }
                }}
              />
            </View>
          ) : null}
        </View>
      </MiddleContentWrapper>

      <PaymentFooter
        text="Total Order Amount"
        amount={Order_data.grand_total}
        customStyleAmount={{ color: "#201f9b" }}
      />
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  showAllContainer: {
    padding: 15,
  },
  headingTitle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 12,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 15.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#09051c",
  },
  orderStatusContainer: {
    height: 218,
    backgroundColor: "#ffffff",
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    borderRadius: 20,
    marginTop: 10,
    marginBottom: 10,
  },
  statusTextDiv: {
    width: "33.3%",
    borderColor: "green",
    borderWidth: 1,
  },
  statusText: {
    opacity: 0.8,
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 10,
    fontWeight: "800",
    fontStyle: "normal",
    letterSpacing: 0.5,
    //textAlign: "left",
    color: "#000000",
  },
  statusText1: {
    opacity: 0.8,
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 10,
    fontWeight: "800",
    fontStyle: "normal",
    letterSpacing: 0.5,
    //textAlign: "left",
    color: "#56504f",
  },

  productContainer: {
    flex: 1,
    width: "100%",
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    //marginTop: 5
  },
});

export default OrderDetailspage;
