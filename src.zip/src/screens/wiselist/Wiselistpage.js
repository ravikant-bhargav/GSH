import React, { useRef, useEffect, useState } from "react";
import { Image, Text, View, StyleSheet, Platform, Alert } from "react-native";

import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import DashboardHeader from "../../components/shared/DashboardHeader";
import AsyncStorage from "@react-native-async-storage/async-storage";
import images from "../../utils/sharedImages";
import appConstant from "../../utils/appConstant";
import WiseListCard from "../../components/WiseListCard";
import Loader from "../../components/Loader";
import { getwiseList, delwiselistitemApi } from "./wiselistService";

const Wiselistpage = (props) => {
  const [isLoading, setIsLoading] = React.useState(false);
  const [shouldShowNodata, setshouldShowNodata] = React.useState(false);
  const [listitem, setlistitem] = useState([]);
  const navigateToScreen = () => {
    props.navigation.goBack();
  };
  useEffect(() => {
    listDetails();
  }, []);

  const listDetails = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getwiseList(token);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);

      if (reasData.data.data.length == 0) {
        setshouldShowNodata(true);
      } else {
        setshouldShowNodata(false);
        setlistitem(reasData.data.data);
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  const getIdDelete = (value) => {
    Alert.alert("", "Do you want delete your item ?", [
      {
        text: "Cancel",
        onPress: () => console.log("Cancel Pressed"),
        style: "cancel",
      },
      { text: "OK", onPress: () => deletewiselistproduct(value) },
    ]);
  };

  const deletewiselistproduct = async (id) => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await delwiselistitemApi(token, id);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      listDetails();
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      // Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  console.log('"delete value>>>>', listitem.length);
  return (
    <React.Fragment>
      <Loader isLoading={isLoading} />
      <DashboardHeader
        showBackArrow={true}
        headerTitle={"Wish List"}
        navScreen={props.navigation}
        headerContainerStyle={{
          borderBottomColor: "rgba(0, 0, 0, 0.14)",
          borderBottomWidth: 1,
        }}
        onPress={() => navigateToScreen()}
      />
      <MiddleContentWrapper
        navigation={props.navigation}
        {...props}
        style={{ paddingBottom: 75 }}
      >
        <View style={[styles.showAllContainer, {}]}>
          {listitem.length > 0 ? (
            listitem.map((item) => {
              console.log(">>>>>>>>>ITEM", item);
              return <WiseListCard nav={item} getIdDelete={getIdDelete} />;
            })
          ) : (
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <View style={{ marginLeft: 30, marginRight: 30 }}>
                <Text style={styles.headingContainer1}>No order found</Text>
              </View>

              <Image source={images.noOrderFound} style={{ marginTop: 30 }} />
            </View>
          )}
        </View>
        {/* <View style={{ flex: 1, marginTop: 3, justifyContent: "center" }}>
          {shouldShowNodata ? (
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <View style={{ marginLeft: 30, marginRight: 30 }}>
                <Text style={styles.headingContainer1}>No order found</Text>
              </View>

              <Image source={images.noOrderFound} style={{ marginTop: 30 }} />
            </View>
          ) : null}
        </View> */}
      </MiddleContentWrapper>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  showAllContainer: {
    padding: 15,
  },
  headingTitle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 12,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 15.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#09051c",
  },
  orderStatusContainer: {
    height: 218,
    backgroundColor: "#ffffff",
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    borderRadius: 20,
    marginTop: 10,
    marginBottom: 10,
  },
  statusTextDiv: {
    width: "33.3%",
    borderColor: "green",
    borderWidth: 1,
  },
  statusText: {
    opacity: 0.8,
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 10,
    fontWeight: "800",
    fontStyle: "normal",
    letterSpacing: 0.5,
    //textAlign: "left",
    color: "#000000",
  },
  statusText1: {
    opacity: 0.8,
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 10,
    fontWeight: "800",
    fontStyle: "normal",
    letterSpacing: 0.5,
    //textAlign: "left",
    color: "#56504f",
  },

  productContainer: {
    flex: 1,
    width: "100%",
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    //marginTop: 5
  },

  showAllContainer: {
    paddingLeft: 15,
    paddingRight: 15,
  },
  headingContainer: {
    fontFamily: "Montserrat-Bold",
    fontSize: 19,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 24.9,
    letterSpacing: 0,
    color: "#09051c",
    textAlign: "center",
  },
  headingContainer1: {
    opacity: 0.8,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    color: "#09051c",
    textAlign: "center",
  },
  btnMainStyle: { flex: 1 / 4, marginTop: 40 },
  btnStyle: {
    width: 111,
    height: 45,
    borderRadius: 10,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    borderStyle: "solid",
    borderWidth: 2.5,
    borderColor: "#3d3cb3",
    backgroundColor: "#fff",
  },
  btnTextStyle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#3d3cb3",
  },
});

export default Wiselistpage;
