import { postApi, getApi, deleteApi } from "../../utils/apiServices";

const addwiselist = "wishlist/add/";
const wiselisturl = "wishlist/wishlist";
const wiselistitemdel = "wishlist/remove/";

export const postaddwiselistApi = async (token, id) => {
  let putData = {
    "": "",
  };
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  ///  let resdata = await postApi(otpVerificationAPiUrl, postData, headers, false)
  let resdata = await postApi(addwiselist + id, putData, config, false)
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  console.log("addwiselist,>>", resdata, addwiselist + id);
  //  console.log("Response>>>",resdata);
  return resdata;
};

export const getwiseList = async (token) => {
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };

  let resdata = await getApi(wiselisturl, config, "")
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  console.log("wiselisturl, config,putData>>>", wiselisturl, config, "");
  return resdata;
};

export const delwiselistitemApi = async (token, id) => {
  console.log(">>>>>>>>>IDTODELETE", id);
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  let resdata = await deleteApi(wiselistitemdel + id, config)
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  console.log("wiselistitemdel, config,===>", wiselistitemdel + id, config);
  return resdata;
};
