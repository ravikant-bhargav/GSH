import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
} from 'react-native';

import appColors from './../../utils/appColors';
import images from './../../utils/sharedImages';
import LinearGradient from 'react-native-linear-gradient';
import OnBoardingHeader from '../../components/shared/OnBoardingHeader';
import SignUpHeader from '../../components/shared/SignUpHeader';


const MiddleContent = (props) => {

    return (
        <React.Fragment>
            <View style={styles.container}>
                <SignUpHeader
                    showBackArrow={props.showBackArrow || false}
                    navScreen={props.navScreen}
                />
                <View style={styles.middleContent}>
                    <ScrollView showsVerticalScrollIndicator={false}>
                        <View style={styles.middleContentWrapper}>
                            {props.children}
                        </View>
                    </ScrollView>
                </View>
            </View>
        </React.Fragment>


    );
};

export const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    
    middleContent: {
        flex: 1,
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        backgroundColor: appColors.WHITE,
        shadowColor: "rgba(0, 0, 0, 0.62)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 4,
        shadowOpacity: 1,
        marginTop: -20,

    },
    middleContentWrapper: {
        marginTop: 50,
        padding: 25,
        flex: 1
    },


});

export default MiddleContent;