import { postApi } from '../../utils/apiServices';
import AsyncStorage from '@react-native-async-storage/async-storage';
import appConstant from '../../utils/appConstant';


const authAPiUrl = "auth/authenticate";
const otpVerificationAPiUrl = "auth/otp-verification";

const getOtpApi = async (mobilenumber,LanguageId) => {
    let postData = {
        "phone_number": mobilenumber,
        "language_id": LanguageId
    };

    let headers = {
        'Accept': 'application/json',
        "Content-Type": "application/json"
    };
    let resdata = await postApi(authAPiUrl, postData, headers, false)
        .then((response) => {
            console.log('res',response)
            return response;

        }).catch(function (error) {
            return error;
        });
    return resdata;

}
const otpVerificationApi = async (postData) => {
    let headers = {
        'Accept': 'application/json',
        "Content-Type": "application/json"
    };
    let resdata = await postApi(otpVerificationAPiUrl, postData, headers, false)
        .then(async(response) => {
            console.log("response==>", response.data);
            let resData = response?.data?.data || '';
            console.log('resData==>',resData);
            let isPhoneVerified = resData && resData.user && resData.user.is_phone_verified;
            let token = resData && resData.token;
            let user = resData && resData.user;
            if (isPhoneVerified === true && token !== '') {
                console.log('SignUPCARD>>',isPhoneVerified,token)
                await AsyncStorage.setItem(appConstant.APP_TOKEN, JSON.stringify(token));
                await AsyncStorage.setItem(appConstant.USER_DATA, JSON.stringify(user));
               
            }
            return response;

        }).catch(function (error) {
            return error;
        });
    console.log("otpdata", resdata);
    return resdata;

}

export {
    getOtpApi,
    otpVerificationApi
}