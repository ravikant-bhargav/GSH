import { createAction, createReducer } from '@reduxjs/toolkit'

export const setAuthUser = createAction('signup/setAuthUser');
export const resetAuthUser = createAction('signup/resetAuthUser');


const initialState = {
    user: [],
    token: ''
};

export const authReducer = createReducer(initialState, (builder) => {
    builder.addCase(setAuthUser, (state, action) => {
        state.user = action.payload.data.userData;
        state.token = action.payload.data.token;
    })
    builder.addCase(resetAuthUser, (state, action) => {
        state.user = [];
        state.token = '';
    })

        .addDefaultCase((state, action) => {
            console.log('initialState=>', state, action)
            return state;
        })
})