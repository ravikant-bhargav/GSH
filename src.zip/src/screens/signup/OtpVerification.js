import React, { useRef, useEffect, useState, useCallback } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  Alert,
} from "react-native";

import LinearGradient from "react-native-linear-gradient";
import { useDispatch } from "react-redux";
import Loader from "../../components/Loader";
import OtpInput from "../../components/OtpInput";
import { setAuthUser } from "./AuthReducer";
import MiddleContent from "./MiddleContent";
import { otpVerificationApi, getOtpApi } from "./SignUpCURD";

import { useSelector } from "react-redux";

const OtpVerification = (props) => {
  const LanguageId = useSelector((state) => state.applanguage);
  let mSelect = LanguageId.id;
  const [otpVal, setOtpValue] = useState(props?.route?.params?.otpNumber || "");
  const [isLoading, setIsLoading] = React.useState(false);
  const [seconds, setSeconds] = React.useState(30);

  const [mNumber, setMobileNumber] = useState(
    props?.route?.params?.mobilenumber || ""
  );
  const [mOtpVal, setmOtpValue] = useState(
    props?.route?.params?.otpNumber || ""
  );
  const [shouldShowResend, setshouldShowResend] = useState(false);
  const dispatch = useDispatch();

  useEffect(() => {
    const interval = setInterval(() => {
      if (parseInt(seconds) > 0) {
        setSeconds((seconds) => seconds - 1);
        setshouldShowResend(false);
        ///console.log('seconds==>',seconds)
      } else {
        //console.log('seconds else body==>',seconds)
        if (seconds == 0) {
          setshouldShowResend(true);
        } else {
          setshouldShowResend(false);
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [seconds]);

  const checkOtp = async () => {
    if (!otpVal) {
      Alert.alert("OTP number is required");
      return;
    }
    setIsLoading(true);
    let requestData = {
      phone_number: mNumber,
      otp: otpVal,
    };
    const reasData = await otpVerificationApi(requestData);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";

      await dispatch(setAuthUser(reasData.data));
      props.navigation.reset({
        index: 0,
        routes: [{ name: "CustomDrawer" }],
      });
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  const resendOtp = async () => {
    setIsLoading(true);

    if (mNumber) {
      const reasData = await getOtpApi(mNumber, mSelect);
      if (reasData && reasData.status === 200) {
        setIsLoading(false);
        setmOtpValue(reasData?.data?.data?.phone_verification_token);
        let msg = reasData?.data?.status?.message || "";
        Alert.alert("", msg);
        setSeconds(30);
      } else {
        setIsLoading(false);
        Alert.alert("Something went wrong.Please try again.");
      }
    }
  };

  return (
    <React.Fragment>
      <MiddleContent showBackArrow={true} navScreen={props.navigation}>
        <Loader isLoading={isLoading} />
        <View style={styles.formContainer}>
          <View>
            <Text style={styles.formTextHeading}>OTP Verification</Text>
            <Text style={styles.formSubHeading}>
              Enter the OTP sent to {"+91 " + mNumber}
            </Text>
            <Text style={styles.formSubHeading}>OTP Number : {mOtpVal}</Text>
            <TouchableOpacity>
              <Text style={styles.formSubHeadingResent2}>
                Resend OTP : {seconds} Sec
              </Text>
            </TouchableOpacity>

            {shouldShowResend ? (
              <TouchableOpacity
                onPress={() => {
                  resendOtp();
                }}
              >
                <Text style={styles.formSubHeadingResent}>Resend OTP</Text>
              </TouchableOpacity>
            ) : null}
            <View style={{ marginTop: 10 }}>
              <OtpInput getOtpVal={(e) => setOtpValue(e)} />
            </View>
          </View>
          <TouchableOpacity
            style={{ marginTop: 15 }}
            onPress={() => checkOtp()}
          >
            <LinearGradient
              colors={["#3d3cb3", "rgba(61, 60, 179, 0.73)"]}
              style={styles.formButtonLinear}
            >
              <Text style={styles.linerButtonText}>SUBMIT</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </MiddleContent>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  formContainer: {},
  formTextHeading: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 20,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 26.2,
    letterSpacing: 0,
    //textAlign: "center",
    color: "#2c2c2d",
  },
  formSubHeading: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#2c2c2d",
    marginTop: 6,
    marginBottom: 9,
  },
  formSubHeadingResent: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 13,
    fontWeight: "600",
    fontStyle: "bold",
    lineHeight: 17.7,
    letterSpacing: 2,
    textAlign: "left",
    color: "#4140b5",
  },
  formSubHeadingResent2: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 12,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 15.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#4140b5",
  },
  formTextInput: {
    height: 60,
    borderRadius: 12,
    borderStyle: "solid",
    borderWidth: 2.5,
    borderColor: "rgb(61, 60, 179)",
    padding: 18,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0.75,
    color: "#2c2c2d",
  },
  formButtonLinear: {
    height: 57,
    borderRadius: 10,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  linerButtonText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#ffffff",
  },
});

export default OtpVerification;
