import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  Alert,
} from "react-native";

import appColors from "./../../utils/appColors";
import images from "./../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";

import MiddleContent from "./MiddleContent";
import { getStateFromPath } from "@react-navigation/native";
import { getOtpApi } from "./SignUpCURD";
import Loader from "../../components/Loader";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { useSelector } from "react-redux";
const SignUpScreen = (props) => {
  const LanguageId = useSelector((state) => state.applanguage);

  let mSelect = LanguageId.id;
  const [number, onChangeNumber] = React.useState("");
  const [isLoading, setIsLoading] = React.useState(false);

  const getMobileOtp = async () => {
    let res = number.replace("+91", "");
    if (!res) {
      Alert.alert("Mobile number is required");
      return;
    }

    setIsLoading(true);
    const reasData = await getOtpApi(res, mSelect);
    console.log("===.>reasData",reasData)
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      Alert.alert("", msg);
      props.navigation.navigate("OtpVerification", {
        mobilenumber: res,
        otpNumber: reasData?.data?.data?.phone_verification_token,
      });
    } else {
      setIsLoading(false);
      Alert.alert("Something went wrong.Please try again.");
    }
  };

  useEffect(() => {
    async () => {
      const token = await AsyncStorage.getItem("APP_TOKEN");
      const userData = await AsyncStorage.getItem("USER_DATA");
    };
  }, []);

  return (
    <React.Fragment>
      <MiddleContent>
        <Loader isLoading={isLoading} />
        <View style={styles.formContainer}>
          <View>
            <Text style={styles.formTextHeading}>Mobile Number</Text>
            <View style={{ marginTop: 10 }}>
              <View
                style={[
                  styles.formTextInput,
                  {
                    flexDirection: "row",
                    flex: 1,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.otpTextStyle,
                    {
                      justifyContent: "center",
                      alignItems: "center",
                      marginLeft: 5,
                      marginRight: 5,
                    },
                  ]}
                >
                  +91
                </Text>
                <TextInput
                  style={{
                    height: 80,
                    fontFamily: "Montserrat-SemiBold",
                    fontSize: 15,
                    fontWeight: "600",
                    fontStyle: "normal",
                    flex: 1,
                    color: "#2c2c2d",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                  onChangeText={onChangeNumber}
                  value={number}
                  placeholder=""
                  maxLength={10}
                  placeholderTextColor={"#dcdcdc"}
                  keyboardType="number-pad"
                />
              </View>
            </View>
          </View>
          <TouchableOpacity
            style={{ marginTop: 15 }}
            onPress={() => {
              if (onChangeNumber.length <= 10) {
                if (mSelect == 1 || mSelect == 2) {
                  getMobileOtp();
                } else {
                  Alert.alert("Please select you language");
                }
              } else {
                Alert.alert("Please check you number");
              }
            }}
          >
            <LinearGradient
              colors={["#3d3cb3", "rgba(61, 60, 179, 0.73)"]}
              style={styles.formButtonLinear}
            >
              <Text style={styles.linerButtonText}>GET OTP</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        <View style={{ marginTop: 30 }}>
          <Text style={styles.otpTextStyle}>
            We will send you a OTP on this number
          </Text>
        </View>
        <View style={styles.lineContainer}>
          <View style={styles.lineSeprator} />
          <Text style={styles.lineText}>OR</Text>
          <View style={styles.lineSeprator} />
        </View>

        {/* <View style={styles.buttonContainer}>
                    <TouchableOpacity >
                        <View style={styles.buttonAlignment}>
                            <Image
                                source={images.googleIcon}
                                style={styles.imageButton}
                            />
                            <Text style={styles.buttonText}>Login with Email</Text>
                        </View>
                    </TouchableOpacity>
                </View> */}
        {/* <View style={styles.buttonContainerWithColor}>
                    <TouchableOpacity >
                        <View style={styles.buttonAlignmentWithColor}>
                            <Image
                                source={images.facebookIcon}
                                style={styles.imageButton}
                            />
                            <Text style={styles.buttonTextWithColor}>Login with Facebook</Text>
                        </View>
                    </TouchableOpacity>
                </View> */}

        <View
          style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
        >
          <Text
            style={{
              fontFamily: "Montserrat-Bold",
              fontSize: 16,
              fontWeight: "bold",
              fontStyle: "normal",
              lineHeight: 26.6,
              letterSpacing: 0,
              textAlign: "center",
              color: "#3d3db4",
            }}
          >
            Continue as a Guest
          </Text>
          <View
            style={{
              width: 155,
              height: 1.5,
              opacity: 0.5,
              backgroundColor: "#3d3db4",
              marginTop: -3,
            }}
          />
        </View>
      </MiddleContent>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  formContainer: {},
  formTextHeading: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 22,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 28.8,
    letterSpacing: 0,
    color: "#2c2c2d",
  },
  formTextInput: {
    height: 60,
    borderRadius: 12,
    borderStyle: "solid",
    borderWidth: 2.5,
    justifyContent: "center",
    alignItems: "center",

    marginLeft: 10,
    marginRight: 10,
    borderColor: "rgb(61, 60, 179)",
  },
  formTextInput2: {
    height: 60,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 19.7,
    marginLeft: 10,
    marginRight: 10,
    justifyContent: "center",
    alignItems: "center",
    letterSpacing: 0.75,
    color: "#2c2c2d",
  },
  formButtonLinear: {
    height: 45,
    borderRadius: 10,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  linerButtonText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#ffffff",
  },

  otpTextStyle: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    textAlign: "center",
    color: "#2c2c2d",
  },

  lineContainer: {
    marginTop: 30,
    marginBottom: 30,
    flexDirection: "row",
    justifyContent: "center",
    alignContent: "center",
    alignItems: "center",
  },

  lineSeprator: {
    width: 129,
    height: 1.5,
    opacity: 0.5,
    backgroundColor: "#000000",
  },
  lineText: {
    opacity: 0.5,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 13,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 21.6,
    letterSpacing: 0,
    textAlign: "center",
    color: "rgba(9, 5, 28, 0.64)",
    marginLeft: 15,
    marginRight: 15,
  },

  buttonContainer: {
    // flex: 1,
    justifyContent: "center",
    height: 51,
    borderRadius: 12,
    borderStyle: "solid",
    borderWidth: 2,
    borderColor: "rgb(61, 60, 179)",
    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
  },

  buttonAlignment: {
    backgroundColor: "#ffffff",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    // padding:10
  },
  buttonText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "rgb(61, 60, 179)",
  },
  buttonContainerWithColor: {
    // flex: 1,
    justifyContent: "center",
    height: 51,
    borderRadius: 12,
    borderStyle: "solid",

    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
    backgroundColor: "#1877f2",
  },
  buttonAlignmentWithColor: {
    backgroundColor: "#1877f2",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  buttonTextWithColor: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    //  textAlign: "left",
    color: "#ffffff",
  },
  imageButton: {
    width: 28.3,
    height: 29,
    borderRadius: 5,
    shadowColor: "rgba(0, 0, 0, 0.09)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
    marginRight: 15,
  },
});

export { SignUpScreen };
