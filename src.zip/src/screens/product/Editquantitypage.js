import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  Alert,
} from "react-native";

import TabBarNavigation from "../../navigation/TabBarNavigation";
import images from "../../utils/sharedImages";
import AddToCartFooter from "./AddToCartFooter";
import AppButton from "../../components/button/AppButton";
import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import HorizontalLine from "../../components/HorizontalLine";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import { ModificationcardproductApi } from "./CardApicall";

import Loader from "../../components/Loader";
const EditquantityPage = (props) => {
  console.log("EditQTY==>>", props.route.params.value);
  const [Counter, setCounter] = useState(1);
  const [price, setprice] = useState(props.route.params.value.Price);
  const [isLoading, setIsLoading] = React.useState(false);

  const modificationProductApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await ModificationcardproductApi(
      token,
      props.route.params.value.productid,
      Counter,// quantity
      props.route.params.value.is_active,
      props.route.params.value.product_delivery_type,
      props.route.params.value.product_variation_type,
      props.route.params.value.product_variation_value,
      props.route.params.value.product_coupon_code,
      props.route.params.value.delivery_start_date,
      props.route.params.value.delivery_end_date,
      props.route.params.value.delivery_time_slot,
      props.route.params.value.auto_renew_subscription,
      props.route.params.value.milk_delivery_type,
      props.route.params.value.milk_delivery_slot,
      props.route.params.value.additional_rule_json
    );
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      Alert.alert("", msg);
      props.navigation.navigate("AddToCart");
      ///  console.log('DeleteResponse>>>>',reasData.data.data)
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  handleIncrementClick = () => {
    console.log("Click increment");
    setCounter(Counter + 1);
    let sum = 0;
    setprice(
      (sum =
        props.route.params.value.Price +
        Counter * props.route.params.value.Price)
    );
  };
  handleDecrementClick = () => {
    console.log("Click decrement");
    setCounter(Counter - 1);
    let sum = props.route.params.value.Price;
    setprice((sum = sum - Counter * props.route.params.value.Price));
  };

  return (
    <React.Fragment>
      <MiddleContentWrapper
        style={{ paddingBottom: 72 }}
        navigation={props.navigation}
        {...props}
      >
        <View
          style={{
            width: "100%",
            flexDirection: "row",
            marginTop: 20,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Text style={styles.productNameText}>
            {props.route.params.value.Name}
          </Text>
          <View style={{ flexDirection: "row", marginLeft: 18 }}>
            <TouchableOpacity
              onPress={() => {
                handleDecrementClick();
              }}
            >
              <Image
                source={images.minusIcon}
                style={{ width: 25, height: 25, marginRight: 8 }}
              />
            </TouchableOpacity>
            <Text
              style={{
                fontFamily: "Montserrat-SemiBold",
                fontSize: 15,
                fontWeight: "600",
                fontStyle: "normal",
                lineHeight: 14.2,
                letterSpacing: 0,
                textAlign: "left",
                color: "#000000",
                marginRight: 8,
                justifyContent: "center",
                alignSelf: "center",
                alignItems: "center",
                marginTop: 3,
              }}
            >
              {Counter + " kg"}
            </Text>
            <TouchableOpacity
              onPress={() => {
                handleIncrementClick();
              }}
            >
              <Image
                source={images.plusIcon}
                style={{ width: 25, height: 25 }}
              />
            </TouchableOpacity>
          </View>
        </View>
      </MiddleContentWrapper>

      <AddToCartFooter
        btnText={"Save"}
        showImage={false}
        onPress={() => {
          modificationProductApi();
        }}
        fooetrStyle={{ bottom: 71 }}
      />
      <TabBarNavigation navigation={props.navigation} {...props} />
    </React.Fragment>
  );
};
export const styles = StyleSheet.create({
  productNameText: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 18,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 16.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#332b55",
  },
});
export default EditquantityPage;
