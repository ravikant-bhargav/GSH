import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  FlatList,
  Dimensions,
  Modal,
  Pressable,
  Alert,
} from "react-native";

import images from "../../utils/sharedImages";
import AppButton from "../../components/button/AppButton";
import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import HorizontalLine from "../../components/HorizontalLine";
import DashboardHeader from "../../components/shared/DashboardHeader";
import AddToCartFooter from "./AddToCartFooter";
import FullCardView from "../../components/FullCardView";
import ActionSheetDialog from "../../components/ActionSheetDialog";
const windowHeight = Dimensions.get("window").height;
import ActionSheet, { SheetManager } from "react-native-actions-sheet";
// import AllInOneSDKManager from "paytm_allinone_react-native";
// paytm_allinone_react-native "for future"
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import { createorderdApi } from "./../product/CardApicall";

const Sheets = {
  testSheet: "test_sheet_id",
};

const PaymentMethod = (props) => {
  let grand_total = props.route.params.cart_details.cart_details.grand_total;
  const [method, setMethod] = useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const navigateToScreen = () => {
    props.navigation.goBack();
  };
  const selectPaymentMethod = (method) => {
    setMethod(!method);
  };

//   const invokePaytm = async (
//     orderNumber,
//     txnToken,
//     amount,
//     callBack,
//     isStaging
//   ) => {
//     console.log(
//       orderNumber.toString() +
//         "\n" +
//         appConstant.PAYTM_MID.toString() +
//         "\n" +
//         txnToken.toString() +
//         "\n" +
//         amount.toString() +
//         "\n" +
//         callBack.toString() +
//         "\n" +
//         isStaging
//     );

//     AllInOneSDKManager.startTransaction(
//       orderNumber.toString(),
//       appConstant.PAYTM_MID.toString(),
//       txnToken.toString(),
//       amount.toString(),
//       callBack.toString(),
//       isStaging,
//       true
//     )
//       .then(async (result) => {
//         console.log("PAYTM RESULT =====> ", JSON.stringify(result));
//         if (result.RESPCODE === "01") {
//           // result will be here
//         }
//       })
//       .catch((err) => {
//         console.log("PAYTM ERROR =====> ", JSON.stringify(err));
//       });
//   };

  /////Order create APi Method/////////////////
  const createorderApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let name = await AsyncStorage.getItem(appConstant.NAME);
    let phnumber = await AsyncStorage.getItem(appConstant.PHONENUMBER);

    let shipping_address_id = await AsyncStorage.getItem(
      appConstant.Shipping_address_id
    );
    let billing_address_id = await AsyncStorage.getItem(
      appConstant.Billing_address_id
    );
    let zip_code = await AsyncStorage.getItem(appConstant.Zip_code);

    let Address_typ = await AsyncStorage.getItem(appConstant.Address_type);
    let City = await AsyncStorage.getItem(appConstant.City);
    let Landmark = await AsyncStorage.getItem(appConstant.Landmark);
    let State = await AsyncStorage.getItem(appConstant.State);
    let Street = await AsyncStorage.getItem(appConstant.Street_address);
    let Email = await AsyncStorage.getItem(appConstant.EMAIL);

    setIsLoading(true);
    const reasData = await createorderdApi(
      token,
      name,
      phnumber,
      shipping_address_id,
      billing_address_id,
      zip_code,
      Address_typ,
      City,
      Landmark,
      State,
      Street,
      Email
    );
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      Alert.alert("", msg);
      if (reasData.data.count <= 0) {
        Alert.alert("", "No data found");
      } else {
        ///  await AsyncStorage.setItem(appConstant.CARD_ID,reasData.data.cart_uuid );
        //props.navigation.navigate("AddToCart")
      }
      console.log("PaymentResponse>>>>", reasData.data.data.order_id);
      let orderId = reasData.data.data.order_id;
      props.navigation.navigate("OrderConfirmed", orderId);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  return (
    <React.Fragment>
      <DashboardHeader
        showBackArrow={true}
        headerTitle1={"Payment Method"}
        navScreen={props.navigation}
        onPress={() => navigateToScreen()}
        headerContainerStyle={{
          borderBottomColor: "rgba(0, 0, 0, 0.14)",
          borderBottomWidth: 1,
        }}
      />

      <MiddleContentWrapper style={{ paddingBottom: 72 }}>
        <View style={styles.showAllContainer}>
          <Text style={styles.headingTitle}>Select Payment Method</Text>

          {/* <TouchableOpacity onPress={() => { console.log('hello') }} style={[styles.buttonContainer, props.btnContainer]}>
                        <View style={[styles.buttonAlignment, props.btnStyle]}>
                            <View style={{ width: "70%" }}>
                                <Image
                                    source={images.razorPayIcon}
                                    style={styles.imageButton}
                                />

                            </View>
                            <View style={{ width: "30%" }}>
                                <Text style={[styles.buttonText, props.btnTextStyle]}>Link Account</Text>
                            </View>
                        </View>
                    </TouchableOpacity> */}

          <TouchableOpacity
            onPress={async () => {
            //   await invokePaytm(
            //     "123456789",
            //     "8933f29f8e45464d8d85abfcdde3671e1620109593364",
            //     "200",
            //     "https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=123456789",
            //     true
            //   );
            }}
            style={[styles.buttonContainer, props.btnContainer]}
          >
            <View style={[styles.buttonAlignment, props.btnStyle]}>
              <View style={{ width: "70%" }}>
                <Image
                  source={images.razorPayIcon}
                  style={styles.imageButton}
                />
              </View>
              <View style={{ width: "30%" }}>
                <Text style={[styles.buttonText, props.btnTextStyle]}>
                  Paytm
                </Text>
              </View>
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              console.log("hello");
            }}
            style={[styles.buttonContainer, props.btnContainer]}
          >
            <View style={[styles.buttonAlignment, props.btnStyle]}>
              <View
                style={{
                  width: "70%",
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                <Image
                  source={images.codIcon}
                  style={[
                    styles.imageButton,
                    { width: 36, height: 36, marginLeft: 10 },
                  ]}
                />
                <Text
                  style={{
                    fontFamily: "Montserrat-Bold",
                    fontSize: 14,
                    fontWeight: "bold",
                    fontStyle: "normal",
                    lineHeight: 15.3,
                    letterSpacing: 0,
                    textAlign: "right",
                    color: "#3d3cb3",
                  }}
                >
                  Cash on Delivery
                </Text>
              </View>

              <TouchableOpacity
                style={{
                  width: "30%",
                  alignItems: "flex-end",
                  paddingRight: 18,
                }}
                onPress={() => console.log("hello")}
              >
                <Image source={images.OKAYFlag} style={styles.imageRightFlag} />
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        </View>
      </MiddleContentWrapper>

      <AddToCartFooter
        fooetrStyle={{ height: 114 }}
        text={"Total"}
        amount={grand_total}
        btnText={"Confirm Payment"}
        showImage={false}
        onPress={() => {
          createorderApi();
        }}
        fType={"payment-method"}
      />
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  showAllContainer: {
    padding: 15,
  },
  PB5: {
    paddingBottom: 5,
  },

  headingTitle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#09051c",
  },
  buttonContainer: {
    // flex: 1,
    justifyContent: "center",
    height: 51,
    borderRadius: 12,
    borderStyle: "solid",
    borderWidth: 2,
    borderColor: "rgb(61, 60, 179)",
    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
  },
  buttonAlignment: {
    //backgroundColor: "#ffffff",
    flexDirection: "row",
    //justifyContent: 'center',
    alignItems: "center",
    // padding:10
  },
  buttonText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 14,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 15.3,
    letterSpacing: 0,
    // textAlign: "right",
    color: "#3d3cb3",
  },
  imageButton: {
    width: 115,
    height: 30,

    borderRadius: 5,
    shadowColor: "rgba(0, 0, 0, 0.09)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
    marginRight: 15,
  },
  lanuageContainer: {
    alignItems: "center",
    flexDirection: "row",
    marginLeft: 15,
    marginRight: 15,
  },
  flagContainer: {
    justifyContent: "center",
    alignItems: "center",
    width: 48,
    height: 48,
    backgroundColor: "#f0f0f9",
    borderRadius: 20,
  },
  imageFlag: {
    width: 31,
    height: 31,
  },
  flagTextContainer: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 17,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 30.7,
    letterSpacing: 0,
    color: "#000000",
    width: "70%",
    marginLeft: 15,
  },
  outerContainer: {
    width: 29,
    height: 29,
    // alignItems: 'center',
    // justifyContent: 'center'
  },

  imageRightFlag: {
    width: 29,
    height: 29,
  },
  inActiveContainer: {
    width: 29,
    height: 29,
    backgroundColor: "rgba(111, 111, 111, 0.45)",
    borderRadius: 20,
  },
});

export default PaymentMethod;
