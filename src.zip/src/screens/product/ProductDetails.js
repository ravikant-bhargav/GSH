import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  FlatList,
  Dimensions,
  Modal,
  Pressable,
  Alert,
  Button,
  SectionList,
  TouchableNativeFeedback,
} from "react-native";
import { useSelector } from "react-redux";
import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";
import { AppButton } from "../../components/button/AppButton";

import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import CalendarCardView from "../../components/calendar/CalendarCardView";
import OrderStatusLabels from "../../components/OrderStatusLabels";
import AmountAdjustment from "../../components/AmountAdjustment";
import HorizontalLine from "../../components/HorizontalLine";

import DashboardHeader from "../../components/shared/DashboardHeader";
import PrimaryButton from "../../components/button/PrimaryButton";
import LinearGradientView from "../../components/LinearGradientView";
import PrimaryInputBox from "../../components/inputbox/PrimaryInputBox";
import PrimaryButtonResize from "../../components/button/PrimaryButtonResize";
import ProductCard from "../../components/product/ProductCard";
import ProductImage from "./ProductImage";
import AddToCartFooter from "./AddToCartFooter";
import AppCalendar from "../../components/calendar/AppCalendar";

import RNPickerSelect from "react-native-picker-select";
const { width } = Dimensions.get("window");

const windowHeight = Dimensions.get("window").height;
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import {
  getProductDetailsApi,
  delcartlistApi,
} from "./../product/ProductCallApi";
import { addcardApi } from "./../product/CardApicall";
import {
  delwiselistitemApi,
  postaddwiselistApi,
} from "./../wiselist/wiselistService";
import { getwiseList } from "./../wiselist/wiselistService";
import Loader from "../../components/Loader";
import { deviceHeight, deviceWidth } from "../../utils/mixin";
import moment from "moment";

const buttonList = [
  {
    name: "Daily",
    value: "daily",
    isActive: false,
  },
  {
    name: "One Time",
    value: "one_time",
    isActive: true,
  },
  {
    name: "Custom",
    value: "custom",
    isActive: false,
  },
];

const ProductDetails = (props) => {
  let ItemID;
  ItemID = props.route.params.itemId;
  const [serachText, onChangeText] = React.useState(null);

  const [deliveryMode, onChangeMode] = React.useState(
    props.route.params.screenCalendar === "calendarScreen"
      ? "custom"
      : "one_time"
  );
  // const [QtyDropdown, onChangeqtyDropdown] = useState(1);
  const [TimeDropdown, onChangetimeDropdown] = React.useState("");

  const [modalVisible, setModalVisible] = React.useState(false);
  const [product, setproduct] = useState([]);
  const [isLoading, setIsLoading] = React.useState(false);
  const [date, setDateTime] = useState();
  const [startdate, setstartdate] = useState(
    props.route.params.delivery_date && props.route.params.screenCalendar
      ? props.route.params.delivery_date
      : ""
  );
  const [enddate, setenddate] = useState(
    props.route.params.delivery_date && props.route.params.screenCalendar
      ? props.route.params.delivery_date
      : ""
  );
  const [price, setprice] = useState("");
  const [Counter, setCounter] = useState(1);
  const [alartVisible, setAlartVisible] = useState(false);
  const [isspineesrVisible, setspineesrVisible] = useState(false);
  const [rulevalues, setrulevalues] = useState([]);
  const [wishlistids, setWishlistIds] = useState([]);
  const [res, setRes] = useState([]);
  const [detailModal, setDerailedModal] = useState(false);
  const [detailType, setDetailType] = useState("DESC");
  const [wishlistID, setWishListID] = useState([]);
  //const [qty,setQty]= React.useState(1);

  // var res;
  // let cart_products={};
  const toggleModalVisibility = () => {
    setspineesrVisible(false);
  };

  // Api Calling product Details
  const getselectProductApi = async () => {
    // setprice("");
    // setenddate("");
    // setstartdate("");
    // onChangeMode("");
    // onChangeqtyDropdown('');
    // onChangetimeDropdown("");
    if (props.route.params.screenCalendar === "calendarScreen") {
      buttonList.map((item, index) => {
        item.isActive = false;
        if (item.value === "custom") {
          item.isActive = true;
        }
        return item;
      });
    }

    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let pincode = await AsyncStorage.getItem(appConstant.Zip_code);
    setIsLoading(true);
    const reasData = await getProductDetailsApi(token, ItemID, pincode);

    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      console.log(">>>>>>>>>>>", reasData.data.data, ItemID);
      setproduct(reasData.data.data);

      // const item = reasData.data.data.filter(
      //   (pro) => parseInt(pro.product_id) === parseInt(ItemID)
      // );

      // setWishListID(item[0].id);

      setCounter(parseInt(reasData.data.data.min_buy_quantity));
      if (reasData.data.data.is_on_sale == true) {
        setprice(reasData.data.data.special_sale_price);
      } else {
        setprice(reasData.data.data.max_retail_price);
      }

      //if(array.length != null && array.length >= 2)
      if (
        reasData.data.data.prod_conf_rules.length != null ||
        reasData.data.data.prod_conf_rules.length >= 0
      ) {
        if (reasData.data.data.prod_conf_rules[0].slug == "milk_delivery") {
          setrulevalues(reasData.data.data.prod_conf_rules[0].rule_values);
          // setdata(reasData.data.data.prod_conf_rules[0].rule_values);
          const resValues =
            reasData.data.data.prod_conf_rules[0].rule_values.map((item) => {
              return {
                Name: item.name,
                data: item.time_slot,
              };
            });
          setRes(resValues);
          onChangetimeDropdown("Select time");
        } else {
          setspineesrVisible(false);
          setrulevalues([]);
          onChangetimeDropdown("not available");
          toggleModalVisibility(false);
        }
      } else {
        setrulevalues([]);
        setspineesrVisible(false);
        onChangetimeDropdown("not available");
        toggleModalVisibility(false);
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  // ////Add to Cart Api Call////////////////////////////////////////////////

  const addcardProductApi = async (cart_products) => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let pincode = await AsyncStorage.getItem(appConstant.Zip_code);
    // setIsLoading(true);
    let catData = {
      zip_code: pincode,
      cart_products: cart_products,
    };

    const reasData = await addcardApi(token, catData);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      Alert.alert("", msg);
      if (reasData.data.count <= 0) {
        Alert.alert("", "No data found");
      } else {
        ///  await AsyncStorage.setItem(appConstant.CARD_ID,reasData.data.cart_uuid );
        /* props.navigation.navigate("AddToCart",
              {
                onGoBackRefresh: (e) => OnRefresh(e),
              }
              ) */
        // props.navigation.pop(2);
        props.navigation.navigate("AddToCart");
        props.route.params.getCallback(catData);
      }

      var Object = [];
      //     Object.assign(Object, reasData.data);

      //     let data = Object[0];

      //    var  val=data && data.cart_uuid;
    } else if (reasData && reasData.err_status === 409) {
      setIsLoading(false);
      Alert.alert(
        reasData?.err_message?.status?.message,
        "Do you want replace your card ?",
        [
          {
            text: "Cancel",

            style: "cancel",
          },
          { text: "OK", onPress: () => replacecard() },
        ]
      );

      // setAlartVisible(true)
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  //////////Add wiseList//////////////////////////////////////////////////////

  const addwiselistApi = async () => {
    // const check = wishlistids.includes(props.route.params.itemId);

    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    // setIsLoading(true);
    if (product.user_wishlist !== null) {
      const res = await delwiselistitemApi(token, product.user_wishlist.id);
      if (res && res.status === 200) {
        setIsLoading(false);
        let msg = res?.data?.status?.message || "";
        Alert.alert("", msg);

        // getWishList();
        getselectProductApi();
      } else if (res && (res.err_status === 400 || res.err_status === 404)) {
        setIsLoading(false);
        Alert.alert("", res?.err_message?.status?.message);
      }
    } else {
      const reasData = await postaddwiselistApi(token, ItemID);
      if (reasData && reasData.status === 200) {
        setIsLoading(false);
        let msg = reasData?.data?.status?.message || "";
        Alert.alert("", msg);
        // getWishList();
        getselectProductApi();
      } else if (
        reasData &&
        (reasData.err_status === 400 || reasData.err_status === 404)
      ) {
        setIsLoading(false);
        Alert.alert("", reasData?.err_message?.status?.message);
      }
    }
  };

  useEffect(() => {
    getselectProductApi();
    // getWishList();
    showDate();
  }, []);

  const getWishList = async () => {
    const token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    const reasData = await getwiseList(token);
    // setIsLoading(true);
    if (reasData && reasData.status === 200) {
      const item = reasData.data.data.filter(
        (pro) => parseInt(pro.product_id) === parseInt(ItemID)
      );

      setWishListID(item[0].id);
      const ids = reasData.data.data.map((item) => {
        return item.product_id;
      });
      setWishlistIds(ids);
      setIsLoading(false);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  ////////////////Current DateTime///////////////////////////////////////////////////////
  const showDate = () => {
    //Get Current Date
    var date = String(new Date().getDate()).padStart(2, "0");

    //Get Current Month
    var month = String(new Date().getMonth() + 1).padStart(2, "0");

    //Get Current Year
    var year = new Date().getFullYear();

    //Get Current Time Hours
    var hours = new Date().getHours();

    //Get Current Time Minutes
    var min = new Date().getMinutes();

    //Get Current Time Seconds
    var sec = new Date().getSeconds();

    ///Get Next month
    var month2 = String(new Date().getMonth() + 2).padStart(2, "0");

    var finalObject = year + "-" + month + "-" + date;

    var endObject = year + "-" + month2 + "-" + date;

    let startdate = moment(new Date()).format("YYYY-MM-DD");

    setDateTime(startdate);

    if (props.route.params.screenCalendar !== "calendarScreen") {
      setstartdate(startdate);
      setenddate(endObject);
    }
  };

  const navigateToScreen = () => {
    props.navigation.goBack();
  };
  const changeDeliveryMode = (mode_name) => {
    buttonList.map((item, index) => {
      item.isActive = false;
      if (item.value === mode_name) {
        item.isActive = true;
      }
      return item;
    });
    onChangeMode(mode_name);
  };

  const getDate = (value) => {
    setstartdate(value.startDate);
    setenddate(value.endDate);
  };

  moveToNextScreen = (
    product_id,
    product_sku,
    quantity,
    deliverymode,
    startdate,
    enddate,
    TimeDropdown,
    variation_type,
    variantion_value
  ) => {
    // if(){
    // "product_id": 3,
    // "product_sku": "aaa",
    // "quantity": 1,
    // "product_delivery_type": "one-time",
    // "product_variation_type": "color",
    // "product_variation_value": "RED",
    // "product_coupon_code": null,
    // "delivery_start_date": null,
    // "delivery_end_date": null,
    // "delivery_time_slot": null,
    // "auto_renew_subscription": false,
    // "milk_delivery_type": null,
    // "milk_delivery_slot": null,
    // "additional_rule_json": null

    //let cartproducts=[];
    let cart_products = {
      product_id: product_id,
      product_sku: product_sku,
      quantity: quantity,
      product_delivery_type: deliverymode,
      product_variation_type: variation_type,
      product_variation_value: variantion_value,
      product_coupon_code: "",
      delivery_start_date: startdate,
      delivery_end_date: enddate,
      delivery_time_slot: TimeDropdown,
      auto_renew_subscription: false,
      milk_delivery_type: "",
      milk_delivery_slot: "",
      additional_rule_json: "",
    };

    // cartproducts.push(object);

    addcardProductApi(cart_products);

    /// props.navigation.navigate("AddToCart")

    // }else{
    //     Alert.alert("Please Select Language");
    // }
  };

  // const OnRefresh = ((value) => {

  //     getselectProductApi()
  //   });

  const addressModal = () => {
    props.route.params.onGoBackRefresh("refresh");
    props.navigation.goBack();
  };

  const replacecard = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    // setIsLoading(true);
    const reasData = await delcartlistApi(token);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);

      props.navigation.navigate("Dashboard");
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      // Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  // Custom Spiner List/////////////////////////////////////////////////////
  // res = rulevalues.map((item) => {
  //   return {
  //     Name: item.name,
  //     data: item.time_slot,
  //   };
  // });
  const Item = ({ value }) => (
    <TouchableOpacity
      style={[styles.item, { backgroundColor: "transparent" }]}
      onPress={() => {
        onChangetimeDropdown(value);
        setspineesrVisible(false);
      }}
    >
      <Text
        style={[
          styles.title,
          {
            fontSize: 14,
            color: "#FFFFFF",
            fontWeight: "bold",
            fontFamily: "Montserrat-SemiBold",
          },
        ]}
      >
        {value}
      </Text>
    </TouchableOpacity>
  );
  handleIncrementClick = () => {
    var maxQty = product.max_buy_quantity;
    if (parseInt(Counter) <= parseInt(maxQty)) {
      setCounter(Counter + 1);
    }

    /// let sum = 0;
    //   setprice(sum= props.route.params.value.Price+Counter*props.route.params.value.Price);
  };
  handleDecrementClick = () => {
    var minQty = product.min_buy_quantity;

    if (parseInt(minQty) <= parseInt(Counter)) {
      setCounter(Counter - 1);
    }

    // let sum = props.route.params.value.Price;
    //  setprice(sum=sum-Counter*props.route.params.value.Price);
  };

  //////////////////////////////////////////////////////////////////////////////
  return (
    <React.Fragment>
      <Loader isLoading={isLoading} />
      {/* <Modal
        animationType="slide"
        transparent
        visible={detailModal}
        // visible={true}
        presentationStyle="overFullScreen"
        onDismiss={toggleModalVisibility}
      >
        <View style={styles.viewWrapper}>
          <View style={[styles.modalView, { backgroundColor: "#EAEAEA" }]}>
            <Text
              style={{ textAlign: "right", marginVertical: 10 }}
              onPress={() => setDerailedModal(!detailModal)}
            >
              X
            </Text>
            <View
              style={{
                width: "100%",
                height: 50,
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <TouchableOpacity
                style={{
                  width: "45%",
                  borderRadius: 12,
                  height: 40,
                  justifyContent: "center",
                  alignContent: "center",
                  alignItems: "center",
                  backgroundColor: detailType === "DESC" ? "#3d3cb3" : "white",
                }}
                onPress={() => setDetailType("DESC")}
              >
                <Text
                  style={{
                    textAlign: "center",
                    fontSize: 15,
                    color: detailType === "DESC" ? "white" : "black",
                  }}
                >
                  Deccription
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  width: "45%",
                  height: 40,
                  borderRadius: 12,
                  justifyContent: "center",
                  alignContent: "center",
                  alignItems: "center",
                  backgroundColor: detailType === "PROD" ? "#3d3cb3" : "white",
                }}
                onPress={() => setDetailType("PROD")}
              >
                <Text
                  style={{
                    textAlign: "center",
                    fontSize: 15,
                    color: detailType === "PROD" ? "white" : "black",
                  }}
                >
                  About Product
                </Text>
              </TouchableOpacity>
            </View>
            {detailType === "PROD" ? (
              <View
                style={{
                  marginVertical: 30,
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Text>Product Details</Text>
                <Text>Under Development</Text>
              </View>
            ) : (
              <View
                style={{
                  marginVertical: 30,
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Text>Product Description</Text>
                <Text>Under Development</Text>
              </View>
            )}
          </View>
        </View>
      </Modal> */}
      <DashboardHeader
        showBackArrow={true}
        likeIcon={true}
        // likeiconhallow={wishlistids.includes(props.route.params.itemId)}
        likeiconhallow={product.user_wishlist === null ? false : true}
        navScreen={props.navigation}
        onPress={() => navigateToScreen()}
        headerContainerStyle={{ backgroundColor: "#ffff" }}
        onPressLike={() => {
          addwiselistApi();
        }}
      />

      <MiddleContentWrapper
        style={{ backgroundColor: "#ffff", paddingBottom: 72 }}
      >
        <ProductImage product={product} />
        <View
          style={[
            styles.innerContainer,
            Platform.OS === "ios"
              ? styles.iosOpticity
              : styles.androidOptiocity,
          ]}
        >
          <View style={styles.PB5}>
            <Text style={styles.productHeading}>{product.name}</Text>
          </View>
          <View style={styles.PB5}>
            <Text style={styles.productPrice}>₹ {price}</Text>
          </View>
          {/* <View style={styles.PB5}>
            <Text
              style={[
                styles.productDescription,
                { textDecorationLine: "underline" },
              ]}
              onPress={() => setDerailedModal(!detailModal)}
            >
              More Details
            </Text>
          </View> */}

          <View style={[styles.btnContainer, {}]}>
            {buttonList &&
              buttonList.length > 0 &&
              buttonList.map((c_item, c_index) => {
                let bgColor = c_item.isActive === true ? "#3d3cb3" : "#f6f6f6";

                let txtColor = c_item.isActive === true ? "#ffffff" : "#3d3cb3";
                let newStyle =
                  c_index === 0
                    ? { marginLeft: 0, marginRight: 20 }
                    : c_index === 1
                    ? { marginRight: 20 }
                    : { marginRight: 12 };
                let button_disable = false;
                if (
                  c_item.value === "daily" &&
                  props.route.params.screenCalendar === "calendarScreen"
                ) {
                  button_disable = true;
                } else if (
                  c_item.value === "one_time" &&
                  props.route.params.screenCalendar === "calendarScreen"
                ) {
                  button_disable = true;
                }

                return (
                  <React.Fragment key={c_index}>
                    <PrimaryButtonResize
                      btnText={c_item.name}
                      btnCustomStyle={[
                        styles.btnStyle,
                        { backgroundColor: bgColor, ...newStyle },
                      ]}
                      btnTextStyle={{ color: txtColor }}
                      onPress={() => {
                        changeDeliveryMode(c_item.value);
                      }}
                      disabled={button_disable}
                    />
                  </React.Fragment>
                );
              })}
          </View>

          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => {
              setModalVisible(!modalVisible);
            }}
          >
            <View style={styles.centeredView}>
              <View style={styles.modalView1}>
                <AppCalendar
                  getDate={getDate}
                  onClose={setModalVisible}
                  onCurrentDate={(currentDate = date)}
                  setEnddateClick={
                    (endclick = { startdate, enddate, deliveryMode })
                  }
                  screenName={
                    deliveryMode === "daily" ? "show30Days" : "showCustom"
                  }
                />

                <PrimaryButtonResize
                  onPress={() => {
                    setModalVisible(false);
                  }}
                  btnText={"Select"}
                  btnCustomStyle={{
                    width: "70%",
                    borderRadius: 5,
                    borderStyle: "solid",
                    borderWidth: 2,
                    borderColor: "#3d3cb3",
                    backgroundColor: "transparent",
                  }}
                  btnTextStyle={{
                    fontFamily: "Montserrat-Bold",
                    fontSize: 14,
                    fontWeight: "bold",
                    fontStyle: "normal",
                    lineHeight: 15.3,
                    letterSpacing: 0,
                    textAlign: "right",
                    color: "#3d3cb3",
                  }}
                />
              </View>
            </View>
          </Modal>

          <SafeAreaView style={styles.screen}>
            <StatusBar style="auto" />
            <Modal
              animationType="slide"
              transparent={true}
              visible={isspineesrVisible}
              presentationStyle="overFullScreen"
              onDismiss={toggleModalVisibility}
              /* onRequestClose={() => {
                            setspineesrVisible(!isspineesrVisible);
                          }}*/
            >
              <View style={styles.viewWrapper}>
                <View style={styles.modalView}>
                  <View
                    style={{
                      height: deviceHeight,
                      width: "100%",
                      paddingHorizontal: 20,
                      paddingTop: 60,
                      backgroundColor: "#00000090",
                    }}
                  >
                    <TouchableNativeFeedback
                      onPress={() => toggleModalVisibility()}
                    >
                      <Image
                        style={{
                          height: 20,
                          width: 20,
                          position: "absolute",
                          top: 60,
                          right: 20,
                          tintColor: "#fff",
                        }}
                        source={images.CrossIcon}
                      />
                    </TouchableNativeFeedback>

                    <Text
                      style={{
                        color: "#fff",
                        fontWeight: "bold",
                        fontSize: 18,
                        fontFamily: "Montserrat-Bold",
                        alignSelf: "center",
                      }}
                    >
                      {"Please select a time slot."}
                    </Text>
                    <View style={{ height: 20 }} />

                    <SectionList
                      sections={res}
                      stickySectionHeadersEnabled={false}
                      keyExtractor={(item, index) => item + index}
                      renderItem={({ item }) => <Item value={item.name} />}
                      renderSectionHeader={({ section: { Name } }) => (
                        <Text
                          style={[
                            styles.header,
                            {
                              width: "100%",
                              backgroundColor: "#f3f3f3",
                              fontFamily: "Montserrat-SemiBold",
                              paddingHorizontal: 20,
                              marginBottom: 10,
                              marginTop: 20,
                            },
                          ]}
                        >
                          {Name}
                        </Text>
                      )}
                    />
                  </View>
                  {/* <Button title="Close" onPress={toggleModalVisibility} /> */}
                </View>
              </View>
            </Modal>
          </SafeAreaView>

          {(deliveryMode &&
            (deliveryMode === "daily" || deliveryMode === "custom") && (
              <View style={styles.deliveryDateContainer}>
                <Text style={styles.deliveryHeading}>Set Delivery Date </Text>
                {((deliveryMode === "daily" || deliveryMode === "custom") && (
                  <View style={styles.inputContainer}>
                    <View style={styles.startDateContainer}>
                      <TouchableOpacity
                        onPress={() => {
                          setModalVisible(true);
                        }}
                        disabled={
                          props.route.params.screenCalendar === "calendarScreen"
                            ? true
                            : false
                        }
                        style={styles.startInnerConatiner}
                      >
                        <View
                          style={[
                            styles.serachBoxContainer,
                            { flexDirection: "column" },
                          ]}
                        >
                          <Text style={[styles.dateText, { marginBottom: 3 }]}>
                            Start Date
                          </Text>
                          <Text style={styles.serachInputContainer}>
                            {startdate}
                          </Text>
                        </View>
                        <Image
                          source={images.pencilEditIcon}
                          style={styles.searchButton}
                        />
                      </TouchableOpacity>
                    </View>
                    <View style={styles.endDateContainer}>
                      <TouchableOpacity
                        onPress={() => {
                          setModalVisible(true);
                        }}
                        disabled={
                          props.route.params.screenCalendar === "calendarScreen"
                            ? true
                            : false
                        }
                        style={styles.endInnerConatiner}
                      >
                        <View
                          style={[
                            styles.serachBoxContainer,
                            { flexDirection: "column" },
                          ]}
                        >
                          <Text style={[styles.dateText, { marginBottom: 3 }]}>
                            End Date
                          </Text>
                          <Text style={styles.serachInputContainer}>
                            {enddate}
                          </Text>
                        </View>
                        <Image
                          source={images.pencilEditIcon}
                          style={styles.searchButton}
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                )) ||
                  null}

                {(deliveryMode === "daily" && (
                  <View style={[styles.inputContainer, {}]}>
                    {res.length > 0 && (
                      <View
                        style={[
                          styles.deliveryTimeCOntainer,
                          { marginRight: 10 },
                        ]}
                      >
                        <Text
                          style={[styles.deliveryHeading, { paddingBottom: 9 }]}
                        >
                          Delivery Time
                        </Text>
                        <View style={{ marginTop: 5 }}>
                          <TouchableOpacity
                            style={[styles.timeTextshow, {}]}
                            onPress={() => {
                              setspineesrVisible(true);
                            }}
                          >
                            <Text
                              style={{
                                color: "#000000",
                                marginRight: 5,
                                marginLeft: 2,
                                alignItems: "center",
                                justifyContent: "center",
                              }}
                            >
                              {TimeDropdown}
                            </Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                    )}
                    <View style={styles.endDateContainer}>
                      <View style={styles.inputContainer1}>
                        <View style={styles.startInnerConatiner}>
                          <View
                            style={[
                              styles.serachBoxContainer,
                              { flexDirection: "column" },
                            ]}
                          >
                            <Text
                              style={[
                                styles.deliveryHeading,
                                { paddingBottom: 20, marginTop: 1 },
                              ]}
                            >
                              Quantity
                            </Text>
                            <View
                              style={{
                                flexDirection: "row",
                                justifyContent: "space-around",
                              }}
                            >
                              <TouchableOpacity
                                onPress={() => {
                                  var minQty = product.min_buy_quantity;
                                  var maxQty = product.max_buy_quantity;
                                  if (parseInt(minQty) < parseInt(Counter)) {
                                    handleDecrementClick();
                                  } else {
                                    Alert.alert(
                                      "Minimum quantity of order to be placed:",
                                      minQty
                                    );
                                  }
                                }}
                              >
                                <Image
                                  source={images.minusIcon}
                                  style={{
                                    width: 25,
                                    height: 25,
                                    marginRight: 2,
                                  }}
                                />
                              </TouchableOpacity>
                              <Text
                                style={{
                                  fontFamily: "Montserrat-SemiBold",
                                  fontSize: 15,
                                  fontWeight: "600",
                                  fontStyle: "normal",
                                  lineHeight: 14.2,
                                  marginLeft: 8,
                                  letterSpacing: 0,
                                  textAlign: "left",
                                  color: "#000000",
                                  marginRight: 8,
                                  justifyContent: "center",
                                  alignSelf: "center",
                                  alignItems: "center",
                                  marginTop: 3,
                                }}
                              >
                                {Counter + " kg"}
                              </Text>
                              <TouchableOpacity
                                onPress={() => {
                                  var maxQty = product.max_buy_quantity;
                                  if (parseInt(Counter) < parseInt(maxQty)) {
                                    handleIncrementClick();
                                  } else {
                                    Alert.alert(
                                      "Maximum quantity of order to be placed:",
                                      maxQty
                                    );
                                  }
                                }}
                              >
                                <Image
                                  source={images.plusIcon}
                                  style={{ width: 25, height: 25 }}
                                />
                              </TouchableOpacity>
                            </View>
                          </View>
                        </View>
                      </View>
                    </View>
                  </View>
                )) ||
                  null}
              </View>
            )) ||
            null}

          {((deliveryMode === "one_time" || deliveryMode === "custom") && (
            <View
              style={{
                width: "100%",
                flexDirection: "column",
                marginTop: 4,
                alignItems: "flex-start",
              }}
            >
              <View style={styles.endDateContainer}>
                <View style={styles.startInnerConatiner}>
                  <View
                    style={[
                      styles.serachBoxContainer,
                      { flexDirection: "column" },
                    ]}
                  >
                    <Text
                      style={[
                        styles.deliveryHeading,
                        { paddingBottom: 9, marginTop: 1 },
                      ]}
                    >
                      Quantity
                    </Text>
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-around",
                      }}
                    >
                      <TouchableOpacity
                        onPress={() => {
                          var minQty = product.min_buy_quantity;
                          var maxQty = product.max_buy_quantity;
                          if (parseInt(minQty) < parseInt(Counter)) {
                            handleDecrementClick();
                          } else {
                            Alert.alert(
                              "Minimum quantity of order to be placed:",
                              minQty
                            );
                          }
                        }}
                      >
                        <Image
                          source={images.minusIcon}
                          style={{ width: 25, height: 25, marginRight: 2 }}
                        />
                      </TouchableOpacity>
                      <Text
                        style={{
                          fontFamily: "Montserrat-SemiBold",
                          fontSize: 15,
                          fontWeight: "600",
                          fontStyle: "normal",
                          lineHeight: 14.2,
                          marginLeft: 8,
                          letterSpacing: 0,
                          textAlign: "left",
                          color: "#000000",
                          marginRight: 8,
                          justifyContent: "center",
                          alignSelf: "center",
                          alignItems: "center",
                          marginTop: 3,
                        }}
                      >
                        {Counter + " kg"}
                      </Text>
                      <TouchableOpacity
                        onPress={() => {
                          var maxQty = product.max_buy_quantity;
                          if (parseInt(Counter) < parseInt(maxQty)) {
                            handleIncrementClick();
                          } else {
                            Alert.alert(
                              "Maximum quantity of order to be placed:",
                              maxQty
                            );
                          }
                        }}
                      >
                        <Image
                          source={images.plusIcon}
                          style={{ width: 25, height: 25 }}
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
            </View>
          )) ||
            null}
        </View>
        <View>
          <View
            style={{
              width: "50%",
              height: 50,
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <TouchableOpacity
              style={{
                width: "45%",
                borderRadius: 12,
                height: 40,
                justifyContent: "center",
                alignContent: "center",
                alignItems: "center",
                // backgroundColor: detailType === "DESC" ? "#3d3cb3" : "white",
              }}
              onPress={() => setDetailType("DESC")}
            >
              <Text
                style={{
                  textAlign: "center",
                  fontSize: 13,
                  color: detailType === "DESC" ? "black" : "grey",
                  textDecorationLine:
                    detailType === "DESC" ? "underline" : "none",
                  textDecorationColor: "#EAEAEA",
                }}
              >
                Description
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                width: "45%",
                height: 40,
                borderRadius: 12,
                justifyContent: "center",
                alignContent: "center",
                alignItems: "center",
                // backgroundColor: detailType === "PROD" ? "#3d3cb3" : "white",
              }}
              onPress={() => setDetailType("PROD")}
            >
              <Text
                style={{
                  textAlign: "center",
                  fontSize: 13,
                  color: detailType === "PROD" ? "black" : "grey",
                  textDecorationLine:
                    detailType === "PROD" ? "underline" : "none",
                  textDecorationColor: "#EAEAEA",
                }}
              >
                About Product
              </Text>
            </TouchableOpacity>
          </View>
          {detailType === "PROD" ? (
            <View
              style={{
                marginVertical: 10,
                padding: 10,
              }}
            >
              <View style={{ marginBottom: 6 }}>
                <Text
                  style={{ fontWeight: "bold", fontSize: 15, color: "black" }}
                >
                  Product Categories
                </Text>
                {product?.prod_categories.map((item, index) => {
                  return (
                    <Text style={{ color: "grey" }}>
                      {index + 1}- {item.name}
                    </Text>
                  );
                })}
              </View>
              <View style={{ marginBottom: 6 }}>
                <Text
                  style={{ fontWeight: "bold", fontSize: 15, color: "black" }}
                >
                  Product Attributes
                </Text>
                {product?.prod_attributes.map((item, index) => {
                  return (
                    <Text style={{ color: "grey" }}>
                      {index + 1}- {item.name}
                    </Text>
                  );
                })}
              </View>
            </View>
          ) : (
            <View
              style={{
                marginVertical: 10,
                padding: 10,
              }}
            >
              <View style={{ marginBottom: 6 }}>
                <Text
                  style={{ fontWeight: "bold", fontSize: 15, color: "black" }}
                >
                  Product Description
                </Text>
                <Text style={{ color: "grey" }}>{product.description}</Text>
              </View>
              <View style={{ marginBottom: 6 }}>
                <Text
                  style={{ fontWeight: "bold", fontSize: 15, color: "black" }}
                >
                  Stock Quantity
                </Text>
                <Text style={{ color: "grey" }}>{product.stock_quantity}</Text>
              </View>
              <View style={{ marginBottom: 6 }}>
                <Text
                  style={{ fontWeight: "bold", fontSize: 15, color: "black" }}
                >
                  Min. Buy Quantity
                </Text>
                <Text style={{ color: "grey" }}>
                  {product.min_buy_quantity}
                </Text>
              </View>
              <View style={{ marginBottom: 6 }}>
                <Text
                  style={{ fontWeight: "bold", fontSize: 15, color: "black" }}
                >
                  Max. Buy Quantity
                </Text>
                <Text style={{ color: "grey" }}>
                  {product.max_buy_quantity}
                </Text>
              </View>
            </View>
          )}
        </View>
      </MiddleContentWrapper>

      <AddToCartFooter
        onPress={() => {
          var minQty = product.min_buy_quantity;
          var maxQty = product.max_buy_quantity;
          var stockqty = product.stock_quantity;

          if (deliveryMode == "custom") {
            if (startdate < enddate) {
              Alert.alert("Please check start date & End Date");
            } else {
              if (
                parseInt(minQty) <= parseInt(Counter) &&
                parseInt(Counter) <= parseInt(maxQty) &&
                parseInt(Counter) <= parseInt(stockqty)
              ) {
                let product_id = product.id;
                let product_sku = product.sku;
                let quantity = Counter;
                let deliverymode = "custom";
                let strstartdate = startdate;
                let strenddate = enddate;
                let TimeDropdown = null;
                var variation_type = null;
                var variantion_value = null;

                moveToNextScreen(
                  product_id,
                  product_sku,
                  quantity,
                  deliverymode,
                  strstartdate,
                  strenddate,
                  TimeDropdown,
                  variation_type,
                  variantion_value
                );
              } else {
                // Alert.alert("Minimum quantity of order to be placed:", minQty);

                if (parseInt(minQty) < parseInt(Counter)) {
                  Alert.alert(
                    "Minimum quantity of order to be placed:",
                    minQty
                  );
                }
                if (parseInt(Counter) > parseInt(stockqty)) {
                  Alert.alert("Quantity in stock:", stockqty);
                }
                if (parseInt(Counter) > parseInt(maxQty)) {
                  Alert.alert(
                    "Maximum quantity of order to be placed:",
                    maxQty
                  );
                }
              }
              // if (parseInt(Counter) <= parseInt(maxQty)) {
              //   let product_id = product.id;
              //   let product_sku = product.sku;
              //   let quantity = Counter;
              //   let deliverymode = "custom";
              //   let strstartdate = startdate;
              //   let strenddate = enddate;
              //   let TimeDropdown = null;
              //   var variation_type = null;
              //   var variantion_value = null;

              //   moveToNextScreen(
              //     product_id,
              //     product_sku,
              //     quantity,
              //     deliverymode,
              //     strstartdate,
              //     strenddate,
              //     TimeDropdown,
              //     variation_type,
              //     variantion_value
              //   );
              // } else {
              //   Alert.alert("Maximum quantity of order to be placed:", maxQty);
              // }
              // if (parseInt(Counter) <= parseInt(stockqty)) {
              //   let product_id = product.id;
              //   let product_sku = product.sku;
              //   let quantity = Counter;
              //   let deliverymode = "custom";
              //   let strstartdate = startdate;
              //   let strenddate = enddate;
              //   let TimeDropdown = null;
              //   var variation_type = null;
              //   var variantion_value = null;

              //   moveToNextScreen(
              //     product_id,
              //     product_sku,
              //     quantity,
              //     deliverymode,
              //     strstartdate,
              //     strenddate,
              //     TimeDropdown,
              //     variation_type,
              //     variantion_value
              //   );
              // } else {
              //   Alert.alert("Quantity in stock:", stockqty);
              // }
            }
          } else if (deliveryMode == "daily") {
            if (TimeDropdown == "Select time") {
              Alert.alert("Please Select Delivery Time ");
            } else {
              if (
                parseInt(minQty) <= parseInt(Counter) &&
                parseInt(Counter) <= parseInt(maxQty) &&
                parseInt(Counter) <= parseInt(stockqty)
              ) {
                let product_id = product.id;
                let product_sku = product.sku;
                let quantity = Counter;
                let deliverymode = "daily";
                let strstartdate = startdate;
                let strenddate = enddate;
                var variation_type = null;
                var variantion_value = null;

                moveToNextScreen(
                  product_id,
                  product_sku,
                  quantity,
                  deliverymode,
                  strstartdate,
                  strenddate,
                  TimeDropdown
                );
              } else {
                if (parseInt(minQty) < parseInt(Counter)) {
                  Alert.alert(
                    "Minimum quantity of order to be placed:",
                    minQty
                  );
                }
                if (parseInt(Counter) > parseInt(stockqty)) {
                  Alert.alert("Quantity in stock:", stockqty);
                }
                if (parseInt(Counter) > parseInt(maxQty)) {
                  Alert.alert(
                    "Maximum quantity of order to be placed:",
                    maxQty
                  );
                }
              }
              //   if (parseInt(Counter) <= parseInt(maxQty)) {
              //     let product_id = product.id;
              //     let product_sku = product.sku;
              //     let quantity = Counter;
              //     let deliverymode = "daily";
              //     let strstartdate = startdate;
              //     let strenddate = enddate;
              //     var variation_type = null;
              //     var variantion_value = null;

              //     moveToNextScreen(
              //       product_id,
              //       product_sku,
              //       quantity,
              //       deliverymode,
              //       strstartdate,
              //       strenddate,
              //       TimeDropdown
              //     );
              //   } else {
              //     Alert.alert("Maximum quantity of order to be placed:", maxQty);
              //   }
              //   if (parseInt(Counter) <= parseInt(stockqty)) {
              //     let product_id = product.id;
              //     let product_sku = product.sku;
              //     let quantity = Counter;
              //     let deliverymode = "daily";
              //     let strstartdate = startdate;
              //     let strenddate = enddate;
              //     var variation_type = null;
              //     var variantion_value = null;

              //     moveToNextScreen(
              //       product_id,
              //       product_sku,
              //       quantity,
              //       deliverymode,
              //       strstartdate,
              //       strenddate,
              //       TimeDropdown
              //     );
              //   } else {
              //     Alert.alert("Quantity in stock:", stockqty);
              //   }
            }
          } else {
            if (
              parseInt(minQty) <= parseInt(Counter) &&
              parseInt(Counter) <= parseInt(maxQty) &&
              parseInt(Counter) <= parseInt(stockqty)
            ) {
              let product_id = product.id;
              let product_sku = product.sku;
              let quantity = Counter;
              let deliverymode = "one-time";
              let strstartdate = new Date();
              let strenddate = new Date();
              let TimeDropdown = null;
              var variation_type = null;
              var variantion_value = null;
              moveToNextScreen(
                product_id,
                product_sku,
                quantity,
                deliverymode,
                strstartdate,
                strenddate,
                TimeDropdown,
                variation_type,
                variantion_value
              );
            } else {
              if (parseInt(minQty) < parseInt(Counter)) {
                Alert.alert("Minimum quantity of order to be placed:", minQty);
              }
              if (parseInt(Counter) > parseInt(stockqty)) {
                Alert.alert("Quantity in stock:", stockqty);
              }
              if (parseInt(Counter) > parseInt(maxQty)) {
                Alert.alert("Maximum quantity of order to be placed:", maxQty);
              }
            }
          }
        }}
        // else {
        //   Alert.alert("Minimum quantity of order to be placed:", minQty);
        // }
        // if (parseInt(Counter) <= parseInt(maxQty)) {
        //   let product_id = product.id;
        //   let product_sku = product.sku;
        //   let quantity = Counter;
        //   let deliverymode = "one-time";
        //   let strstartdate = new Date();
        //   let strenddate = new Date();
        //   let TimeDropdown = null;
        //   var variation_type = null;
        //   var variantion_value = null;

        //   moveToNextScreen(
        //     product_id,
        //     product_sku,
        //     quantity,
        //     deliverymode,
        //     strstartdate,
        //     strenddate,
        //     TimeDropdown,
        //     variation_type,
        //     variantion_value
        //   );
        // } else {
        //   Alert.alert("Maximum quantity of order to be placed:", maxQty);
        // }
        // if (parseInt(Counter) <= parseInt(stockqty)) {
        //   let product_id = product.id;
        //   let product_sku = product.sku;
        //   let quantity = Counter;
        //   let deliverymode = "one-time";
        //   let strstartdate = new Date();
        //   let strenddate = new Date();
        //   let TimeDropdown = null;
        //   var variation_type = null;
        //   var variantion_value = null;

        //   moveToNextScreen(
        //     product_id,
        //     product_sku,
        //     quantity,
        //     deliverymode,
        //     strstartdate,
        //     strenddate,
        //     TimeDropdown,
        //     variation_type,
        //     variantion_value
        //   );
        // } else {
        //   Alert.alert("Quantity in stock:", stockqty);
        // }
        // }
        // }
        // }
        amount={Counter * price}
      />
    </React.Fragment>
  );
};

const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    width: "100%",
    height: 26,
    borderRadius: 3,
    borderStyle: "solid",
    borderWidth: 1.5,
    borderColor: "#3d3cb3",
  },
  inputAndroid: {
    width: "100%",
    height: 26,
    borderRadius: 3,
    borderStyle: "solid",
    borderWidth: 1.5,
    borderColor: "#3d3cb3",
    flexDirection: "row",
    justifyContent: "center",
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
});

export const styles = StyleSheet.create({
  showAllContainer: {
    padding: 15,
  },
  PB5: {
    paddingBottom: 5,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0,0.4)",
    height: "50%",
  },

  modalView1: {
    borderRadius: 20,
    padding: 10,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    backgroundColor: "#fff",
    width: "92%",
  },

  innerContainer: {
    backgroundColor: "#f6f6f6",
    flex: 1,
    width: "100%",
    height: "100%",
    paddingLeft: 23,
    paddingRight: 23,
    paddingBottom: 10,
    paddingTop: 15,
  },
  iosOpticity: {
    shadowColor: "rgba(0, 0, 0, 0.1)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 22,
    shadowOpacity: 1,
  },
  androidOptiocity: {
    elevation: 10,
  },
  productHeading: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 20,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 21.9,
    letterSpacing: 0,
    color: "#332b55",
  },
  productPrice: {
    fontFamily: "Montserrat-Bold",
    fontSize: 20,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 21.9,
    letterSpacing: 0,
    color: "#3d3cb3",
  },
  productDescription: {
    fontFamily: "Montserrat-Medium",
    fontSize: 12,
    fontWeight: "500",
    fontStyle: "normal",
    lineHeight: 13.1,
    letterSpacing: 0,
    textAlign: "left",
    color: "#000000",
  },
  btnContainer: {
    flexDirection: "row",
    flex: 1,
    width: "100%",
    flexWrap: "wrap",
    paddingTop: 18,
    paddingBottom: 18,
  },
  btnStyle: {
    width: "27%",
    height: 33,
    borderRadius: 58,
    backgroundColor: "#3d3cb3",
    borderStyle: "solid",
    borderWidth: 2,
    borderColor: "#3d3cb3",
  },
  deliveryDateContainer: {
    flex: 1,
    width: "100%",
    height: "100%",
  },
  deliveryHeading: {
    fontFamily: "Montserrat-Bold",
    fontSize: 13,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 14.2,
    letterSpacing: 0,
    textAlign: "left",
    color: "#000000",
  },
  inputContainer1: {
    paddingTop: 1,
    paddingBottom: 1,
    marginLeft: 14,
    marginRight: 14,
    flex: 1,
    width: "100%",
    flexDirection: "row",
    flexWrap: "wrap",
  },

  inputContainer: {
    paddingTop: 10,
    paddingBottom: 10,
    flex: 1,
    width: "100%",
    flexDirection: "row",
    flexWrap: "wrap",
  },
  startDateContainer: {
    width: "50%",
  },
  startInnerConatiner: {
    width: "70%",
    flexDirection: "row",
    borderBottomColor: "#3d3cb3",
    borderBottomWidth: 1,
  },
  endDateContainer: {
    width: "50%",
  },
  endInnerConatiner: {
    width: "70%",
    flexDirection: "row",
    borderBottomColor: "#3d3cb3",
    borderBottomWidth: 1,
  },
  dateText: {
    fontFamily: "Montserrat-Medium",
    fontSize: 14,
    fontWeight: "500",
    fontStyle: "normal",
    lineHeight: 15.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#000000",
  },
  serachBoxContainer: {
    flex: 1,
    flexDirection: "row",
    borderRadius: 10,
    marginBottom: 4,
  },
  searchButton: {
    width: 25,
    height: 25,
    marginTop: 4,
  },
  serachInputContainer: {
    flex: 1,
    paddingRight: 3,
    paddingLeft: 0,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 15.3,
    letterSpacing: 0,
    color: "#000000",
  },

  deliveryTimeCOntainer: {
    width: "45%",
    flexDirection: "column",
  },

  inputBoxContainer: {
    width: "100%",
    height: 26,
    borderRadius: 3,
    borderStyle: "solid",
    borderWidth: 1.5,
    borderColor: "#3d3cb3",
    flexDirection: "row",
    justifyContent: "space-evenly",
    flex: 1,
  },
  screen: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
  },
  viewWrapper: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
    borderStyle: "solid",
  },
  modalView: {
    width: "90%",
    // alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    borderRadius: 7,
    padding: 10,
  },
  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
    marginHorizontal: 16,
  },
  item: {
    backgroundColor: "#dcdcdc",
    padding: 4,
    marginVertical: 4,
  },
  header: {
    fontSize: 18,
    fontFamily: "Montserrat-SemiBold",
    color: "#000000",
    backgroundColor: "#fff",
  },
  title: {
    fontSize: 24,
  },
  formTextInput: {
    height: 30,
    borderRadius: 12,
    borderStyle: "solid",
    borderWidth: 2,
    marginTop: 8,
    borderColor: "rgb(61, 60, 179)",
    padding: 8,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 10,
    marginRight: 4,
    alignItems: "center",
    justifyContent: "center",
    letterSpacing: 0.75,
    color: "#2c2c2d",
  },
  timeTextshow: {
    height: 30,
    borderRadius: 12,
    borderStyle: "solid",
    borderWidth: 2,
    marginTop: 5,
    borderColor: "rgb(61, 60, 179)",
    padding: 5,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 10,
    alignItems: "flex-start",
    justifyContent: "flex-start",
    letterSpacing: 0.75,
    color: "#2c2c2d",
  },
});

export default ProductDetails;
