import { postApi, getApi, putApi } from "../../utils/apiServices";
const addcardAPiUrl = "cart/addProduct";
const cardListAPiUrl = "cart/getUserActiveCart";
const ModificationcardApiUrl = "cart/modifyCartProduct";
const deleteCartAPi = "cart/deleteCartItem";
const cardCheckoutAPiUrl = "/order/getCheckout";
const CreateOrderApiUrl = "/order/create";
const adjustmentAmount = "/user/user-payment-details?customer_id=";
////////////////Add Cart Api////////////////////////////////////////////
export const addcardApi = async (token, cardproduct) => {
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  ///  let resdata = await postApi(otpVerificationAPiUrl, postData, headers, false)
  let resdata = await postApi(addcardAPiUrl, cardproduct, config)
    .then((response) => {
      console.log("response ===> ", response);
      return response;
    })
    .catch(function (error) {
      console.log("console error ===> ", error);
      return error;
    });
  console.log(
    "addcardAPiUrl, config,postData>>>",
    resdata,
    addcardAPiUrl,
    cardproduct,
    config
  );
  //  console.log("Response>>>",resdata);
  return resdata;
};
/////// Cart List Api/////////////////////////////////////////////////////////////
export const getCartList = async (token, offset) => {
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };

  let resdata = await getApi(cardListAPiUrl, config, "")
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  console.log("addcardAPiUrl, config,putData>>>", cardListAPiUrl, config, "");
  console.log("Response>>>", resdata);
  return resdata;
};

export const getAdjustmentAmount = async (token, id) => {
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  console.log("API////", adjustmentAmount + id);
  let resdata = await getApi(adjustmentAmount + id, config, "")
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });

  console.log("Response>>>", resdata);
  return resdata;
};

////////Delete card Product Api////////////////////////////////////
//  "product_id": 1,
// props.route.params.value.productid,Counter,props.route.params.value.is_active,
// props.route.params.value.product_delivery_type,props.route.params.value.product_variation_type,
// props.route.params.value.product_variation_value,props.route.params.value.product_coupon_code
// ,props.route.params.value.delivery_start_date,props.route.params.value.delivery_end_date,
// props.route.params.value.delivery_time_slot,props.route.params.value.auto_renew_subscription,
// props.route.params.value.milk_delivery_type, props.route.params.value.milk_delivery_slot,
// props.route.params.value.additional_rule_json

export const ModificationcardproductApi = async (
  token,
  cart_id,
  id
  // productid,
  // quantity,
  // is_active,
  // product_delivery_type,
  // product_variation_type,
  // product_variation_value,
  // product_coupon_code,
  // delivery_start_date,
  // delivery_end_date,
  // delivery_time_slot,
  // auto_renew_subscription,
  // milk_delivery_type,
  // milk_delivery_slot,
  // additional_rule_json
) => {
  let catData = {
    cart_id: cart_id,
    id: id,
    // product_id: productid,
    // quantity: quantity,
    // is_active: is_active,
    // product_delivery_type: product_delivery_type,
    // product_variation_type: product_variation_type,
    // product_variation_value: product_variation_value,
    // product_coupon_code: product_coupon_code,
    // delivery_start_date: delivery_start_date,
    // delivery_end_date: delivery_end_date,
    // delivery_time_slot: delivery_time_slot,
    // auto_renew_subscription: auto_renew_subscription,
    // milk_delivery_type: milk_delivery_type,
    // milk_delivery_slot: milk_delivery_slot,
    // additional_rule_json: additional_rule_json,
  };
  console.log("===>catData", catData);

  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  ///  let resdata = await postApi(otpVerificationAPiUrl, postData, headers, false)
  let resdata = await putApi(deleteCartAPi, catData, config, false)
    .then((response) => {
      console.log("===>response",response)
      return response;
    })
    .catch(function (error) {
      return error;
    });
  //  console.log("addcardAPiUrl, config,putData>>>",ModificationcardApiUrl,catData,config,false);
  //  console.log("Response>>>",resdata);
  return resdata;
};

////////////////checkout Cart Api////////////////////////////////////////////
export const chackoutcardApi = async (
  token,
  coupon_code,
  Shipping_address_id,
  billing_address_id,
  Zip_code
) => {
  console.log(
    "Coupon code===>",
    token,
    coupon_code,
    Shipping_address_id,
    billing_address_id,
    Zip_code
  );
  let catData = {
    coupon_code: coupon_code,
    shipping_address_id: Shipping_address_id,
    billing_address_id: billing_address_id,
    shipping_pin_code: Zip_code,
    include_reward_coin_pay: false,
    pay_reward_coin_quantity: 10,
    currency: "INR",
  };
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  ///  let resdata = await postApi(otpVerificationAPiUrl, postData, headers, false)
  let resdata = await postApi(cardCheckoutAPiUrl, catData, config, false)
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  console.log(
    "cardCheckoutAPiUrl, config,putData>>>",
    cardCheckoutAPiUrl,
    config,
    catData
  );
  //  console.log("Response>>>",resdata);
  return resdata;
};

////////////////Create order Cart Api////////////////////////////////////////////
export const createorderdApi = async (
  token,
  name,
  phnumber,
  shipping_address_id,
  billing_address_id,
  zip_code,
  Address_typ,
  City,
  Landmark,
  State,
  Street,
  Email
) => {
  let catData = {
    shipping_pin_code: zip_code,
    billing_address_id: billing_address_id,
    shipping_address_id: shipping_address_id,
    remote_ip: "",
    payment_method: "PENDING",
    address_details: {
      billing_address_type: Address_typ,
      billing_name: name,
      billing_email: Email,
      billing_phone_number: phnumber,
      billing_street_address: Street,
      billing_landmark: Landmark,
      billing_city: City,
      billing_state: State,
      billing_country: "India",
      billing_zip_code: zip_code,
      shipping_address_type: Address_typ,
      shipping_name: name,
      shipping_email: Email,
      shipping_phone_number: phnumber,
      shipping_street_address: Street,
      shipping_landmark: Landmark,
      shipping_city: City,
      shipping_state: State,
      shipping_country: "India",
      shipping_zip_code: zip_code,
    },
  };

  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  ///  let resdata = await postApi(otpVerificationAPiUrl, postData, headers, false)
  let resdata = await postApi(CreateOrderApiUrl, catData, config, false)
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  //   console.log("cardCheckoutAPiUrl, config,putData>>>",CreateOrderApiUrl, config,cardproduct);
  //  console.log("Response>>>",resdata);
  return resdata;
};
