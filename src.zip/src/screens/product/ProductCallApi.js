import { getApi, deleteApi } from "../../utils/apiServices";
const ProductAPiUrl = "product/products";
const DetailsProductAPiUrl = "product/";
const CatagoryProductApiUrl = "product/categoryProducts/";
const ReplacecartApiUrl = "cart/clearCart";
const ProductSearchiApiUrl = "product/search/product?searchQuery=";
///https://api.gharsehaat.com/v1/api/product/products?page=1&per_page=10

export const getProductallApi = async (token, page_no) => {
  let putData = {
    page: page_no,
    per_page: 20,
  };
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  let resdata = await getApi(ProductAPiUrl, config, putData)
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  return resdata;
};
///////////////////////Product Details//////////////////////////////////////////////////////
export const getProductDetailsApi = async (token, id, pincode) => {
  let putData = {
    zip_code: pincode,
  };

  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  let resdata = await getApi(DetailsProductAPiUrl + id, config, putData)
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  //  console.log('DetailsProductAPiUrl+id, config,putData===>',DetailsProductAPiUrl+id, config,putData)
  return resdata;
};
// ////////////////Catagorywise product////////////////////////////////////////////////////////////////////////////////
///{{url}}/v1/api/product/categoryProducts/1?page=1&per_page=10
export const getCatagoryProductApi = async (token, page_no, id) => {
  let putData = {
    page: page_no,
    per_page: 20,
  };
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  let resdata = await getApi(CatagoryProductApiUrl + id, config, putData)
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  ///  console.log('Catagory wise product>>>>',resdata,CatagoryProductApiUrl+id, config,putData)
  return resdata;
};
///////////////////////Replace cart//////////////////////////////////////////////////////
export const delcartlistApi = async (token) => {
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  let resdata = await deleteApi(ReplacecartApiUrl, config)
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  console.log(
    "ReplacecartApiUrl, config,DeleteData===>",
    ReplacecartApiUrl,
    config
  );
  return resdata;
};

///////////////////Searching product
export const getProductSearchingApi = async (token, searchword) => {
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };
  let resdata = await getApi(ProductSearchiApiUrl + searchword, config, "")
    .then((response) => {
      console.log(">>>>>APIres....", response.data);
      return response;
    })
    .catch(function (error) {
      return error;
    });
  console.log(
    "searching==>",
    resdata,
    ProductSearchiApiUrl + searchword,
    config,
    ""
  );
  return resdata;
};
