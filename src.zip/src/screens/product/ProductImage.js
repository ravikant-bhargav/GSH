import React, { useRef, useEffect, useState } from 'react';


import {
    SafeAreaView,
    Image,
    Text,
    View,
    StyleSheet,
    Dimensions,
    Animated,
    StatusBar,
    TouchableOpacity,
    FlatList, Platform
} from 'react-native';

import appColors from '../../utils/appColors';
import images from '../../utils/sharedImages';
const ProductImage = (props) => {
    const [state, setState] = useState({});
    //console.log('Product image>>',props.product.product_images)

    var Object=[];
    Object.assign(Object, props.product.product_images);
    
    let data = Object[0];
    
   var  val=data && data.url;
//    var bar=JSON.stringify(val);
//     console.log('Value >>',""+bar)
 
    const [featuredImage, onChangeImage] = React.useState();
    const updateFeaturedImage = (item) => {
        onChangeImage({uri:item.url});
    }
    // useEffect(() => {
       
    //  }, [])
    ///featuredImage=""+bar
     console.log('featuredImage>>',featuredImage)

    return (

        <View style={styles.productImageContainer}>
            <View style={styles.featuredImage}>
                <Image source={{uri:val}} style={{ width: "80%", height: "100%", resizeMode: 'cover', alignItems: 'center' }} />
            </View>
            <View style={styles.allImageList}>
                <FlatList
                    data={props.product.product_images}
                    renderItem={({ item }) => {
                        return (
                            <TouchableOpacity
                                activeOpacity={0.8}
                                style={styles.singleImage}
                                onPress={() => { updateFeaturedImage(item) }}
                            >
                                <View style={Platform.OS === 'ios' ? styles.groupItemIOS : styles.groupItemAndroid}>
                                    <Image source={{uri:item.url}} style={{ width: 43, height: 43, alignItems: 'center' }} />
                                </View>
                            </TouchableOpacity>
                        )
                    }}
                    keyExtractor={item => item.id}
                    horizontal={true}
                    initialNumToRender={2}
                    showsHorizontalScrollIndicator={false}
                />

            </View>
        </View>



    );
};

export const styles = StyleSheet.create({
    productImageContainer: {
        flex: 1,
        width: "100%",
        height: 300,
        alignItems: 'center',
        marginTop: 4,
        backgroundColor: "#ffff",
    },
    featuredImage: {
        flex: 1,
        width: 222,
        height: 170,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10
    },
    allImageList: {
        width: "70%",
        height: 130,
        flexDirection: 'row',
        justifyContent: 'center',
        flexWrap: 'wrap',
        alignItems: 'center',

        //flex:1
    },
    singleImage: {
        width: 72,
        height: 72,
        margin: Platform.OS === 'ios' ? 10 : 14,
    },
    groupItemIOS: {
        width: 68,
        height: 68,
        borderRadius: 10,
        backgroundColor: "#fff",
        shadowColor: "rgba(0, 0, 0, 0.25)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 6,
        shadowOpacity: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    groupItemAndroid: {
        width: 68,
        height: 68,
        elevation: 10,
        backgroundColor: "#fff",
        borderRadius: 10,
        alignItems: 'center',
        justifyContent: 'center',
    },

});

export default ProductImage;