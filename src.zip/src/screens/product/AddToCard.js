import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  FlatList,
  Dimensions,
  Modal,
  Pressable,
  Alert,
} from "react-native";

import images from "../../utils/sharedImages";
import AppButton from "../../components/button/AppButton";
import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import HorizontalLine from "../../components/HorizontalLine";
import DashboardHeader from "../../components/shared/DashboardHeader";
import AddToCartFooter from "./AddToCartFooter";
import FullCardView from "../../components/FullCardView";
import ActionSheetDialog from "../../components/ActionSheetDialog";
const windowHeight = Dimensions.get("window").height;
import ActionSheet, { SheetManager } from "react-native-actions-sheet";
import TabBarNavigation from "../../navigation/TabBarNavigation";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import { EditAddress, getAddresslist } from "../myaddress/AddressService";
import {
  getCartList,
  ModificationcardproductApi,
  chackoutcardApi,
  getAdjustmentAmount,
} from "./../product/CardApicall";

import Loader from "../../components/Loader";

import PlannerSheet from "../planner/PlannerSheet";

import moment from "moment";

const Sheets = {
  testSheet: "test_sheet_id",
};
const AddToCart = (props) => {
  const [serachText, onChangeText] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const [deliveryMode, onChangeMode] = React.useState("daily");
  const [modalVisible, setModalVisible] = React.useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState();

  const [Counter, setCounter] = useState(1);
  const [shouldShow, setShouldShow] = useState(true);
  const [exixtingitemShow, setexixtingitemShow] = useState(true);

  const [isStatus, setStatus] = useState(true);
  const [adjustment_Amount, setAmount] = useState(0);
  const [price, setprice] = useState(0);
  const actionSheetRef = useRef(null);
  const [cartlist, setcartlist] = useState([]);
  const [cartAmount, setCartAmount] = useState();
  const [Address_type, setAddress_type] = useState("");
  const [City, setCity] = useState("");
  const [Landmark, setLandmark] = useState("");
  const [State, setState] = useState("");
  const [Street_address, setStreet_address] = useState("");
  const [Zip_code, setZip_code] = useState("");

  let coupon_code = "";

  const navigateToScreen = () => {
    props.navigation.goBack();
    getcartListApi();
  };

  // Api Calling Card List

  const getcartListApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    /// setIsLoading(true);
    const reasData = await getCartList(token, "");

    if (reasData && reasData.status === 200) {
      //setIsLoading(false);
      console.log(">>>>>>>>>USERCART", reasData.data.data.user_cart_products);
      setcartlist(reasData.data.data.user_cart_products);

      let sum = 0;
      for (var i = 0; i < reasData.data.data.user_cart_products.length; i++) {
        setprice(
          (sum =
            sum +
            reasData.data.data.user_cart_products[i].quantity *
              reasData.data.data.user_cart_products[i].cart_product_detail
                .max_retail_price)
        );
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      //  setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  ///////////Modification Api Calling//////////////////////////////////////

  const modificationProductApi = async (
    // productid,
    // quantity,
    // is_active,
    // product_delivery_type,
    // product_variation_type,
    // product_variation_value,
    // product_coupon_code,
    // delivery_start_date,
    // delivery_end_date,
    // delivery_time_slot,
    // auto_renew_subscription,
    // milk_delivery_type,
    // milk_delivery_slot,
    // additional_rule_json
    value
  ) => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);

    const reasData = await ModificationcardproductApi(
      token,
      // productid,
      // quantity,
      // is_active,
      // product_delivery_type,
      // product_variation_type,
      // product_variation_value,
      // product_coupon_code,
      // delivery_start_date,
      // delivery_end_date,
      // delivery_time_slot,
      // auto_renew_subscription,
      // milk_delivery_type,
      // milk_delivery_slot,
      // additional_rule_json
      value.cart_id,
      value.id
    );

    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      Alert.alert("", msg);
      if (reasData.data.count <= 0) {
        Alert.alert("", "No data found");
      } else {
        ///  await AsyncStorage.setItem(appConstant.CARD_ID,reasData.data.cart_uuid );
        //  props.navigation.navigate("AddToCart")
        getcartListApi();
        setprice("");
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      console.log(">>>>>>>>>>ERROR", reasData);
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  const checkoutcardProductApi = async () => {
    setIsLoading(true);
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let shipping_address_id = await AsyncStorage.getItem(
      appConstant.Shipping_address_id
    );
    let billing_address_id = await AsyncStorage.getItem(
      appConstant.Billing_address_id
    );
    let zip_code = await AsyncStorage.getItem(appConstant.Zip_code);

    const reasData = await chackoutcardApi(
      token,
      coupon_code,
      shipping_address_id,
      billing_address_id,
      zip_code
    );
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      Alert.alert("", msg);
      if (reasData.data.data.errors.length == 0) {
        let cheoutlist = reasData.data.data;
        console.log("CHECKOUTLIST>>>>>>>", cheoutlist);
        setCartAmount(cheoutlist);
        //useState
        openActionSheet();
        // props.navigation.navigate("CheckoutCardPage", (param = { cheoutlist }));
      } else {
        let message = reasData.data.data.errors[0].error;
        Alert.alert("Warning!", message);
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  const getaddrressValue = (value) => {
    let straddress_type = value.address_type;
    let strcity = value.city;
    let strlandmark = value.landmark;
    let strstate = value.state;
    let strstreet_address = value.street_address;
    let strzip_code = value.zip_code;
    var setdefault = true;
    let ID = value.id;

    let strshipping_address_id = value.id;
    let strbilling_address_id = value.id;

    editAddressApi(
      ID,
      straddress_type,
      strstreet_address,
      strcity,
      strlandmark,
      strstate,
      strzip_code,
      setdefault
    );
  };
  const editAddressApi = async (
    ID,
    straddress_type,
    strstreet_address,
    strcity,
    strlandmark,
    strstate,
    strzip_code,
    setdefault
  ) => {
    setIsLoading(true);
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let phone = await AsyncStorage.getItem(appConstant.PHONENUMBER);
    const reasData = await EditAddress(
      token,
      ID,
      phone,
      straddress_type,
      strstreet_address,
      strcity,
      strlandmark,
      strstate,
      strzip_code,
      setdefault
    );
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      getsddresslistApi();
      // setLocalDB(strshipping_address_id,strbilling_address_id,
      //     straddress_type,strcity,strlandmark,strstate,strstreet_address,strzip_code);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  const getsddresslistApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getAddresslist(token, 1);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);

      for (i = 0; i < reasData.data.data.length; i++) {
        if (reasData.data.data[i].is_default == true) {
          await AsyncStorage.setItem(
            appConstant.Shipping_address_id,
            "" + reasData.data.data[i].id.toString()
          );
          await AsyncStorage.setItem(
            appConstant.Billing_address_id,
            "" + reasData.data.data[i].id.toString()
          );
          await AsyncStorage.setItem(
            appConstant.Address_type,
            reasData.data.data[i].address_type
          );

          await AsyncStorage.setItem(
            appConstant.City,
            reasData.data.data[i].city
          );
          await AsyncStorage.setItem(
            appConstant.Landmark,
            reasData.data.data[i].landmark
          );
          await AsyncStorage.setItem(
            appConstant.State,
            reasData.data.data[i].state
          );
          await AsyncStorage.setItem(
            appConstant.Street_address,
            reasData.data.data[i].street
          );
          await AsyncStorage.setItem(
            appConstant.Zip_code,
            "" + reasData.data.data[i].zipcode.toString()
          );
        }
      }
      getLocalDB();
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  // setInterval(()=> {
  // setStatus(!isStatus)
  // }, 5000)

  useEffect(() => {
    getcartListApi();
    getLocalDB();
    fetchAdjustmentAmount();
  }, [props]);

  const fetchAdjustmentAmount = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let user_data = JSON.parse(
      await AsyncStorage.getItem(appConstant.USER_DATA)
    );

    await getAdjustmentAmount(token, user_data.id)
      .then((res) => {
        const cr_adjustment = res?.data?.cr_adjustment || 0;
        const dr_adjustment = res?.data?.dr_adjustment || 0;
        const value = parseFloat(cr_adjustment) - parseFloat(dr_adjustment);
        const setAdjustmentvalue =
          parseFloat(value) >= 0 ? parseFloat(value) : 0;
        setAmount(setAdjustmentvalue);
      })
      .catch((err) => {
        console.log("ERR/////", err);
      });
  };

  const getLocalDB = async () => {
    let Address_type = await AsyncStorage.getItem(appConstant.Address_type);
    if (Address_type != null) {
      // do something
      setAddress_type(Address_type);
    } else {
      // do something else
      setAddress_type("");
    }
    let Landmark = await AsyncStorage.getItem(appConstant.Landmark);
    if (Landmark != null) {
      // do something
      setLandmark(Landmark);
    } else {
      // do something else
      setLandmark("");
    }
    let State = await AsyncStorage.getItem(appConstant.State);
    if (State != null) {
      // do something
      setState(State);
    } else {
      // do something else
      setState("");
    }
    let City = await AsyncStorage.getItem(appConstant.City);
    if (City != null) {
      // do something
      setCity(City);
    } else {
      // do something else
      setCity("");
    }
    let Street_address = await AsyncStorage.getItem(appConstant.Street_address);
    if (Street_address != null) {
      // do something
      setStreet_address(Street_address);
    } else {
      // do something else
      setStreet_address("");
    }
    let Zip_code = await AsyncStorage.getItem(appConstant.Zip_code);
    if (Zip_code != null) {
      // do something
      setZip_code(Zip_code);
    } else {
      // do something else
      setZip_code("");
    }

    setAddress_type(Address_type);
    setCity(City);
    setLandmark(Landmark);
    setState(State);
    setStreet_address(Street_address);
    setZip_code(Zip_code);
  };

  const getEditData = async (value) => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let productid = value.productid;
    let quantity = value.quantity;
    let is_active = value.is_active;
    let product_delivery_type = value.product_delivery_type;
    let product_variation_type = value.product_variation_type;
    let product_variation_value = value.product_variation_value;
    let product_coupon_code = value.product_coupon_code;
    let delivery_start_date = value.delivery_start_date;
    let delivery_end_date = value.delivery_end_date;
    let delivery_time_slot = value.delivery_time_slot;
    let auto_renew_subscription = value.auto_renew_subscription;
    let milk_delivery_type = value.milk_delivery_type;
    let milk_delivery_slot = value.milk_delivery_slot;
    let additional_rule_json = value.additional_rule_json;
    setIsLoading(true);
    await ModificationcardproductApi(
      token,
      productid,
      quantity,
      is_active,
      product_delivery_type,
      product_variation_type,
      product_variation_value,
      product_coupon_code,
      delivery_start_date,
      delivery_end_date,
      delivery_time_slot,
      auto_renew_subscription,
      milk_delivery_type,
      milk_delivery_slot,
      additional_rule_json
    )
      .then((res) => {
        setIsLoading(false);
      })
      .catch((err) => {
        setIsLoading(false);
      });

    // props.navigation.navigate(
    //   "EditQuantityPage",
    //   (nav = { value }),
    //   (navscreen = { props })
    // );
  };

  const getDate = (value) => {
    ///{"PID": 16, "is_active": false, "quantity": "10"}

    // if (value.is_active == false) {
    //   let productid = value.PID;
    //   let quantity = value.quantity;
    //   var is_active = value.is_active;
    //   let product_delivery_type = value.delivery_type;
    //   let product_variation_type = value.variation_type;
    //   let product_variation_value = value.variation_value;
    //   let product_coupon_code = value.coupon_code;

    //   let delivery_start_date =
    //     value.start_date || moment().format("YYYY-MM-DD");
    //   let delivery_end_date = value.end_date || moment().format("YYYY-MM-DD");

    //   let delivery_time_slot = value.time_slot;
    //   let auto_renew_subscription = value.renew_subscription;
    //   let milk_delivery_type = value.milk_delivery_Type;
    //   let milk_delivery_slot = value.delivery_slot;
    //   let additional_rule_json = value.rule_json;

    modificationProductApi(
      value
      // productid,
      // quantity,
      // is_active,
      // product_delivery_type,
      // product_variation_type,
      // product_variation_value,
      // product_coupon_code,
      // delivery_start_date,
      // delivery_end_date,
      // delivery_time_slot,
      // auto_renew_subscription,
      // milk_delivery_type,
      // milk_delivery_slot,
      // additional_rule_json
    );
    // } else {
    // }
  };
  const OnRefresh = (value) => {
    getcartListApi();
  };

  const openActionSheet = () => {
    SheetManager.show("test_sheet_id", { text: "Hello World" });
  };

  return (
    <React.Fragment>
      <DashboardHeader
        showBackArrow={true}
        headerTitle={"Shopping Cart"}
        navScreen={props.navigation}
        onPress={() => navigateToScreen()}
        headerContainerStyle={{
          borderBottomColor: "rgba(0, 0, 0, 0.14)",
          borderBottomWidth: 1,
        }}
      />

      <MiddleContentWrapper
        style={{ paddingBottom: 72 }}
        navigation={props.navigation}
        {...props}
      >
        <View style={[styles.amountContainer]}>
          <Text style={styles.amountHeading}>Adjustment amount:</Text>
          <Text style={styles.totalPrice}>₹ {adjustment_Amount}</Text>
        </View>
        <HorizontalLine />

        <View style={styles.showAllContainer}>
          <Text style={styles.headingTitle}>Order Summary</Text>
          <View style={styles.productContainer}>
            <View style={styles.productSubContainer}>
              <View style={[styles.productInnerContainer, {}]}>
                <View
                  style={[
                    styles.productDetailContainer,
                    { flexDirection: "row", padding: 5 },
                  ]}
                >
                  <Image
                    source={images.locationIcon}
                    style={{ resizeMode: "cover", alignSelf: "center" }}
                  />
                  <View style={{ marginLeft: 5, flex: 1, marginTop: 8 }}>
                    <Text style={styles.productNameText}>
                      {Address_type.charAt(0).toUpperCase() +
                        Address_type.slice(1)}
                    </Text>
                    <Text style={[styles.productAddress, { marginTop: 2 }]}>
                      {City +
                        " , " +
                        Landmark +
                        " , " +
                        Street_address +
                        " , " +
                        Zip_code}
                    </Text>
                  </View>
                </View>
                <View style={styles.productLocationChangeContainer}>
                  <TouchableOpacity
                    style={{ flex: 1, marginTop: 3, justifyContent: "center" }}
                    onPress={() => {
                      props.navigation.navigate("MyAddress", {
                        onGoBack: (e) => getaddrressValue(e),
                      });
                    }}
                  >
                    <Text style={[styles.productChangeButton, {}]}>Change</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        </View>
        <HorizontalLine />

        <View style={{ paddingLeft: 15, paddingRight: 15, paddingBottom: 15 }}>
          {/* OLD ARPAN */}
          {/* <FullCardView
            card={cartlist}
            navscreen={props}
            getEditData={getEditData}
            getDate={getDate}
          /> */}

          {cartlist.map((item, index) => {
            return (
              <FullCardView
                key={index}
                card={item}
                navscreen={props}
                getEditData={getEditData}
                getDate={modificationProductApi}
              />
            );
          })}

          <AppButton
            showImage={false}
            btnText={"Add More items"}
            btnContainer={{
              borderRadius: 8,
              borderStyle: "solid",
              borderWidth: 2.5,
              borderColor: "#3d3cb3",
            }}
            btnStyle={{ backgroundColor: "transparent" }}
            btnTextStyle={{
              fontFamily: "Montserrat-Bold",
              fontSize: 14,
              fontWeight: "bold",
              fontStyle: "normal",
              lineHeight: 15.3,
              letterSpacing: 0,
              color: "#3d3cb3",
            }}
            onPress={() => {
              props.navigation.navigate("CategoryProduct");
            }}
          />
        </View>
      </MiddleContentWrapper>
      <ActionSheetDialog
        actionSheetRef={actionSheetRef}
        sheetId={Sheets.testSheet}
      >
        <PlannerSheet
          actionSheetRef={actionSheetRef}
          cartDetails={cartAmount}
          navigation={props.navigation}
        />
      </ActionSheetDialog>

      <AddToCartFooter
        text={"Grand Total"}
        amount={price}
        btnText={"Checkout"}
        showImage={false}
        onPress={() => {
          checkoutcardProductApi();
          // openActionSheet()
        }}
        fooetrStyle={{ bottom: 71 }}
      />

      <TabBarNavigation navigation={props.navigation} {...props} />
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  showAllContainer: {
    padding: 15,
  },
  PB5: {
    paddingBottom: 5,
  },

  amountContainer: {
    flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    marginLeft: 15,
    marginRight: 15,
    marginTop: 10,
    justifyContent: "flex-start",
    alignItems: "center",
  },
  amountHeading: {
    fontFamily: "Montserrat-Bold",
    fontSize: 14,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 15.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#09051c",
    alignItems: "center",
  },
  totalPrice: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#3d3cb3",
    marginLeft: 10,
  },
  headingTitle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 20,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#09051c",
  },
  locationContainer: {
    marginTop: 6,
    height: 64,
    borderRadius: 8,
    backgroundColor: "#ffffff",
  },
  productContainer: {
    flex: 1,
    width: "100%",
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    marginTop: 5,
  },
  productSubContainer: {
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    marginTop: 5,
    backgroundColor: "#fff",
  },
  productInnerContainer: {
    flexDirection: "row",
    marginBottom: 5,
  },
  productDetailContainer: {
    width: "80%",
    height: "100%",
    padding: 5,
  },
  productLocationChangeContainer: {
    width: "20%",
  },
  productNameText: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 12,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 16.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#332b55",
  },
  productAddress: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 12,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 16.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#332b55",
  },
  productPlanTypeText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 12,
    fontWeight: "600",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "rgb(16, 16, 16)",
  },
  productAmountText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 17,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 22.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#201f9b",
  },
  productChangeButton: {
    fontFamily: "Montserrat-Bold",
    fontSize: 13,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 14.2,
    letterSpacing: 0,
    textAlign: "left",
    color: "#3d3cb3",
  },
  productAmountDateText1: {
    //opacity: 0.6,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 9,
    fontWeight: "normal",
    fontStyle: "normal",
    letterSpacing: 0.5,
    //textAlign: "center",
    color: "#3b3b3b",
  },
  productAmountButton: {
    width: 81,
    // height: 14,
    borderRadius: 4,
    backgroundColor: "#52b69a",
    justifyContent: "center",
    alignItems: "center",
    padding: 2,
  },
  productStatusText: {
    alignSelf: "center",
    fontFamily: "Montserrat-SemiBold",
    fontSize: 9,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 11.8,
    letterSpacing: 0,
    // textAlign: "left",
    color: "#ffffff",
  },
});

export default AddToCart;
