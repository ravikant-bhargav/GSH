import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  FlatList,
  Dimensions,
  Modal,
  Pressable,
  Alert,
  PermissionsAndroid,
} from "react-native";
import AppButton from "../../components/button/AppButton";
import appColors from "./../../utils/appColors";
import images from "./../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";
import MiddleContent from "../signup/MiddleContent";
import Loader from "../../components/Loader";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import { postaddnewAddress } from "../myaddress/AddressService";
import { CheckBox } from "react-native-elements";
import DashboardHeader from "../../components/shared/DashboardHeader";
import RNPickerSelect from "react-native-picker-select";
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete";
import MapView, { Marker, enableLatestRenderer } from "react-native-maps";
import Geolocation from "@react-native-community/geolocation";
import { API_KEY } from "../../utils/mixin";
import MapComponent from "../../components/map/map";
const qtyDropdown = [
  {
    label: "Home",
    value: "home",
  },
  {
    label: "Office",
    value: "office",
  },
  {
    label: "Other",
    value: "other",
  },
];
const placeholderQty = {
  label: "Select Delivery Type",
  value: null,
  fontFamily: "Montserrat-Medium",
  fontSize: 16,
  fontWeight: "500",
  fontStyle: "normal",
  lineHeight: 13.1,
  letterSpacing: 0,
  textAlign: "left",
  color: "#000000",
};

const AddnewAddress = (props) => {
  // console.log(props);
  const [Lable, onChangeLable] = useState("");
  const [Address, onChangeAddress] = useState("");
  const [city, onChangecity] = useState("");
  const [landmark, onChangelandmark] = useState("");
  const [lattitude_value, setLattitude] = useState(0);
  const [longitude_value, setLongitude] = useState(0);
  const [state, onChangestate] = useState("");
  const [zip_code, onChangezip_code] = useState("");
  const [isLoading, setIsLoading] = React.useState(false);
  const [checked, setChecked] = useState(false);

  const [QtyDropdown, onChangeqtyDropdown] = React.useState("");

  useEffect(() => {
    requestLocationPermission();
  }, []);

  const requestLocationPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: "App Location Permission",
          message: "App need to access your location",
          buttonNeutral: "Ask me later",
          buttonPositive: "Ok",
          buttonNegative: "Cancel",
        }
      );
      console.log(">>>>>>>>>>>>>", granted);
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        console.log("You can use the location");
        getCurrentPosition();
      } else {
        console.log("location permission denied");
      }
    } catch (err) {
      console.warn(err);
    }
  };

  const getCurrentPosition = () => {
    setIsLoading(true);
    Geolocation.getCurrentPosition(
      (pos) => {
        console.log("POS///////////", pos);
        // setTimeout(() => {
        const latitude = pos.coords.latitude;
        const longitude = pos.coords.longitude;
        setLattitude(pos.coords.latitude);
        setLongitude(pos.coords.longitude);
        setIsLoading(false);
        // }, 3000);
      },
      (error) => Alert.alert("GetCurrentPosition Error", JSON.stringify(error)),
      { enableHighAccuracy: true }
    );
  };

  const navigateToScreen = () => {
    props.navigation.goBack();
  };
  //  console.log(radioButtons);
  const addressModal = () => {
    props.route.params.onGoBackRefresh("refresh");
    props.navigation.goBack();
  };

  enableLatestRenderer();

  const addAddressApi = async (
    Type,
    Add,
    City,
    Landmark,
    State,
    Zip_code,
    setdefault
  ) => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let phone = await AsyncStorage.getItem(appConstant.PHONENUMBER);
    setIsLoading(true);
    const reasData = await postaddnewAddress(
      token,
      phone,
      Type,
      Add,
      City,
      Landmark,
      State,
      Zip_code,
      setdefault
    );
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      Alert.alert("", msg);
      // console.log("Address>>>", reasData);
      addressModal();
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  return (
    <React.Fragment>
      <DashboardHeader
        showBackArrow={true}
        headerTitle={"Add Addresses"}
        navScreen={props.navigation}
        onPress={() => navigateToScreen()}
        headerContainerStyle={{
          borderBottomColor: "rgba(0, 0, 0, 0.14)",
          borderBottomWidth: 1,
        }}
      />
      <ScrollView>
        <View style={styles.formContainer}>
          <Loader isLoading={isLoading} />
          {lattitude_value !== 0 && longitude_value !== 0 && (
            <MapComponent
              lattitude_value={lattitude_value}
              longitude_value={longitude_value}
              onChange={(lat, long) => (setLattitude(lat), setIsLoading(long))}
            />
          )}
          {/* <View
            style={{
              height: 40,
              justifyContent: "center",
            }}
          >
            <GooglePlacesAutocomplete
              placeholder="Type a place"
              styles={{
                textInput: {
                  height: 38,
                  color: "#5d5d5d",
                  fontSize: 16,
                  backgroundColor: "transparent",
                  borderRadius: 12,
                  borderStyle: "solid",
                  borderWidth: 2.5,
                  borderColor: "#A8A8A8",
                },
              }}
              onPress={(data, details = null) => console.log(data, details)}
              query={{
                key: "AIzaSyAg7HTmUqhU5MWT8V2VOu8JBQC62LKPZy4",
              }}
              fetchDetails={true}
              onFail={(error) => console.log(error)}
              onNotFound={() => console.log("no results")}
              listEmptyComponent={() => (
                <View style={{ flex: 1 }}>
                  <Text>No results were found</Text>
                </View>
              )}
            />
          </View>
          <View style={{ height: 400 }}>
            <MapView
              // provider={PROVIDER_GOOGLE} // remove if not using Google Maps
              style={styles.map}
              showsUserLocation={true}
              showsMyLocationButton={true}
              zoomEnabled={true}
              zoomControlEnabled={true}
              followsUserLocation={true}
              region={{
                latitude: lattitude_value,
                longitude: longitude_value,
                latitudeDelta: 0.015,
                longitudeDelta: 0.0121,
              }}
            >
              <Marker
                coordinate={{
                  latitude: lattitude_value,
                  longitude: longitude_value,
                  latitudeDelta: 0.015,
                  longitudeDelta: 0.0121,
                }}
                draggable
                onDragEnd={(e) => {
                  console.log("e>>>>>>>>", e.nativeEvent);
                  setLattitude(e.nativeEvent.coordinate.latitude);
                  setLongitude(e.nativeEvent.coordinate.longitude);
                }}
              />
            </MapView>
          </View> */}
          <View>
            <View style={{ marginTop: 10 }}>
              <TextInput
                style={styles.formTextInput}
                keyboardType="default"
                onChangeText={onChangeAddress}
                value={Address}
                placeholder="Flat No/Building/Street"
                placeholderTextColor={"#A8A8A8"}
              />
            </View>
          </View>
          <View>
            <View style={{ marginTop: 10 }}>
              <TextInput
                style={styles.formTextInput}
                keyboardType="default"
                onChangeText={onChangelandmark}
                value={landmark}
                placeholder="landmark"
                placeholderTextColor={"#A8A8A8"}
              />
            </View>
          </View>
          <View>
            <View style={{ marginTop: 10 }}>
              <TextInput
                style={styles.formTextInput}
                keyboardType="default"
                onChangeText={onChangecity}
                value={city}
                placeholder="City"
                placeholderTextColor={"#A8A8A8"}
              />
            </View>
          </View>
          <View>
            <View style={{ marginTop: 10 }}>
              <TextInput
                style={styles.formTextInput}
                keyboardType="default"
                onChangeText={onChangestate}
                value={state}
                placeholder="State"
                placeholderTextColor={"#A8A8A8"}
              />
            </View>
          </View>
          <View>
            <View style={{ marginTop: 10 }}>
              <TextInput
                style={styles.formTextInput}
                keyboardType="number-pad"
                onChangeText={onChangezip_code}
                value={zip_code}
                maxLength={6}
                placeholder="Zip code"
                placeholderTextColor={"#A8A8A8"}
              />
            </View>
          </View>
          <View style={[styles.deliveryTimeCOntainer, { marginLeft: 10 }]}>
            <View style={{ marginTop: 10 }}>
              <Text style={[styles.formTextHeading2, {}]}>Delivery type</Text>
              <RNPickerSelect
                onValueChange={(value) => onChangeqtyDropdown(value)}
                items={qtyDropdown}
                placeholder={placeholderQty}
                style={{
                  ...pickerSelectStyles,
                  iconContainer: {
                    alignItems: "left",
                    justifyContent: "flex-start",
                    height: "100%",
                  },
                }}
              />
              <View>
                <View
                  style={{
                    paddingLeft: 8,
                    paddingRight: 8,
                    paddingBottom: 15,
                    marginTop: 10,
                  }}
                ></View>
              </View>
              <View style={{ marginTop: 10 }}>
                <CheckBox
                  containerStyle={{ backgroundColor: "transparent" }}
                  checkedIcon={
                    <Image
                      source={require("../../assets/images/icons/checkbox.png")}
                      style={{ height: 20, width: 20 }}
                    />
                  }
                  uncheckedIcon={
                    <Image
                      source={require("../../assets/images/icons/unchecked.png")}
                      style={{ height: 20, width: 20 }}
                    />
                  }
                  title={"Make this my default address"}
                  checked={checked}
                  onPress={() => {
                    setChecked(!checked);
                  }}
                />
              </View>
            </View>
          </View>
          <TouchableOpacity
            style={{ marginTop: 15 }}
            onPress={() => {
              if (
                QtyDropdown == "" ||
                Address == "" ||
                city == "" ||
                landmark == "" ||
                state == "" ||
                zip_code == ""
              ) {
                Alert.alert("Please Check address details");
              } else {
                let Type = QtyDropdown;
                let Add = Address;
                let City = city;
                let Landmark = landmark;
                let State = state;
                let Zip_code = zip_code;
                var setdefault = checked;
                addAddressApi(
                  Type,
                  Add,
                  City,
                  Landmark,
                  State,
                  Zip_code,
                  setdefault
                );
              }
            }}
          >
            <LinearGradient
              colors={["#3d3cb3", "rgba(61, 60, 179, 0.73)"]}
              style={styles.formButtonLinear}
            >
              <TouchableOpacity
                onPress={() => {
                  if (
                    QtyDropdown == "" ||
                    Address == "" ||
                    city == "" ||
                    landmark == "" ||
                    state == "" ||
                    zip_code == ""
                  ) {
                    Alert.alert("Please Check address details");
                  } else {
                    let Type = QtyDropdown;
                    let Add = Address;
                    let City = city;
                    let Landmark = landmark;
                    let State = state;
                    let Zip_code = zip_code;
                    var setdefault = checked;
                    addAddressApi(
                      Type,
                      Add,
                      City,
                      Landmark,
                      State,
                      Zip_code,
                      setdefault
                    );
                  }
                }}
              >
                <Text style={styles.linerButtonText}>Save</Text>
              </TouchableOpacity>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </React.Fragment>
  );
};

const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    width: "100%",
    height: 26,
    borderRadius: 3,
    borderStyle: "solid",
    borderWidth: 1.5,
    borderColor: "#3d3cb3",
  },
  inputAndroid: {
    width: "100%",
    height: 26,
    borderRadius: 3,
    borderStyle: "solid",
    borderWidth: 1.5,
    borderColor: "#3d3cb3",
    flexDirection: "row",
    justifyContent: "center",
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
});

const styles = StyleSheet.create({
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  header: {
    backgroundColor: "#3d3cb3",
    height: 170,
  },
  avatar: {
    width: 130,
    height: 130,
    borderRadius: 63,
    borderWidth: 4,
    borderColor: "white",
    marginBottom: 10,
    alignSelf: "center",
    position: "absolute",
    marginTop: 50,
  },

  formContainer: {
    marginHorizontal: 15,
    marginVertical: 10,
    flex: 1,
  },
  formTextHeading: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 22,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 28.8,
    letterSpacing: 0,
    color: "#2c2c2d",
  },
  formTextHeading2: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 16,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 28.8,
    letterSpacing: 0,
    color: "#2c2c2d",
  },
  formTextInput: {
    height: 60,
    borderRadius: 12,
    borderStyle: "solid",
    borderWidth: 2.5,
    borderColor: "#A8A8A8",
    padding: 18,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0.75,
    color: "#2c2c2d",
  },
  formButtonLinear: {
    height: 45,
    borderRadius: 10,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  linerButtonText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    color: "#ffffff",
  },

  lineContainer: {
    marginTop: 30,
    marginBottom: 30,
    flexDirection: "row",
    justifyContent: "center",
    alignContent: "center",
    alignItems: "center",
  },

  lineSeprator: {
    width: 129,
    height: 1.5,
    opacity: 0.5,
    backgroundColor: "#000000",
  },
  lineText: {
    opacity: 0.5,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 13,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 21.6,
    letterSpacing: 0,
    textAlign: "center",
    color: "rgba(9, 5, 28, 0.64)",
    marginLeft: 15,
    marginRight: 15,
  },

  buttonContainer: {
    // flex: 1,
    justifyContent: "center",
    height: 51,
    borderRadius: 12,
    borderStyle: "solid",
    borderWidth: 2,
    borderColor: "rgb(61, 60, 179)",
    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
  },

  buttonAlignment: {
    backgroundColor: "#ffffff",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    // padding:10
  },
  buttonText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "rgb(61, 60, 179)",
  },
  buttonContainerWithColor: {
    // flex: 1,
    justifyContent: "center",
    height: 51,
    borderRadius: 12,
    borderStyle: "solid",

    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
    backgroundColor: "#1877f2",
  },
  buttonAlignmentWithColor: {
    backgroundColor: "#1877f2",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  buttonTextWithColor: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    //  textAlign: "left",
    color: "#ffffff",
  },
  imageButton: {
    width: 28.3,
    height: 29,
    borderRadius: 5,
    shadowColor: "rgba(0, 0, 0, 0.09)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
    marginRight: 15,
  },
  amountHeading: {
    fontFamily: "Montserrat-Bold",
    fontSize: 14,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 15.7,
    letterSpacing: 0,
    textAlign: "center",
    color: "#09051c",
    alignItems: "center",
  },
  productAddress: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 12,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 16.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#332b55",
  },
  image: {
    width: 350,
    height: 200,
  },
  deliveryTimeCOntainer: {
    width: "90%",
    flexDirection: "column",
  },
});

export default AddnewAddress;
