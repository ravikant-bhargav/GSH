import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  FlatList,
  Dimensions,
  Modal,
  Pressable,
  Alert,
} from "react-native";

import images from "../../utils/sharedImages";
import AppButton from "../../components/button/AppButton";
import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import HorizontalLine from "../../components/HorizontalLine";
import DashboardHeader from "../../components/shared/DashboardHeader";

const windowHeight = Dimensions.get("window").height;
import ActionSheet, { SheetManager } from "react-native-actions-sheet";
import TabBarNavigation from "../../navigation/TabBarNavigation";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import { getAddresslist, deleteAddress } from "./../myaddress/AddressService";
import Loader from "../../components/Loader";
const Sheets = {
  testSheet: "test_sheet_id",
};

const MyAddress = (props) => {
  const [shouldShowNodata, setshouldShowNodata] = React.useState(false);
  const [serachText, onChangeText] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const [deliveryMode, onChangeMode] = React.useState("daily");
  const [modalVisible, setModalVisible] = React.useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState();
  const [addresslist, setaddresslis] = useState([]);
  const actionSheetRef = useRef(null);

  const navigateToScreen = () => {
    props.navigation.goBack();
  };

  const getsddresslistApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getAddresslist(token, 1);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      // Alert.alert("", msg);
      if (reasData.data.count <= 0) {
        // Alert.alert("User addresss not found");
        //  props.navigation.navigate('NoOrder')

        setshouldShowNodata(true);
      } else {
        setshouldShowNodata(false);
        setaddresslis(reasData.data.data);
        // console.log('Address>>',reasData.data.data)
        for (i = 0; i < reasData.data.data.length; i++) {
          //  console.log('defaultaddress==>>',reasData.data.data[i].is_default);
          if (reasData.data.data[i].is_default == true) {
            await AsyncStorage.setItem(
              appConstant.Shipping_address_id,
              "" + reasData.data.data[i].id.toString()
            );
            await AsyncStorage.setItem(
              appConstant.Billing_address_id,
              "" + reasData.data.data[i].id.toString()
            );
            await AsyncStorage.setItem(
              appConstant.Address_type,
              reasData.data.data[i].address_type
            );

            await AsyncStorage.setItem(
              appConstant.City,
              reasData.data.data[i].city
            );
            await AsyncStorage.setItem(
              appConstant.Landmark,
              reasData.data.data[i].landmark
            );
            await AsyncStorage.setItem(
              appConstant.State,
              reasData.data.data[i].state
            );
            await AsyncStorage.setItem(
              appConstant.Street_address,
              reasData.data.data[i].street
            );
            await AsyncStorage.setItem(
              appConstant.Zip_code,
              "" + reasData.data.data[i].zipcode.toString()
            );
          }
        }
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  const deleteaddressApi = async (id) => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await deleteAddress(token, id);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      Alert.alert("", msg);
      // console.log('DeleteResponse>>>>',reasData)
      getsddresslistApi();
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  const addressModal = (
    ID,
    shipping_address_type,
    shipping_street_address,
    shipping_landmark,
    shipping_city,
    shipping_state,
    shipping_zip_code
  ) => {
    let addressRange = {
      id: ID,
      address_type: shipping_address_type,
      street_address: shipping_street_address,
      landmark: shipping_landmark,
      city: shipping_city,
      state: shipping_state,
      zip_code: shipping_zip_code,
    };
    // console.log("props==>",props)
    props.route.params.onGoBack(addressRange);
    props.navigation.goBack();
  };

  useEffect(() => {
    getsddresslistApi();
  }, []);

  const OnRefresh = (value) => {
    console.log("getAddress==>>", value);
    getsddresslistApi();
  };

  return (
    <React.Fragment>
      <DashboardHeader
        showBackArrow={true}
        headerTitle={"Addresses"}
        navScreen={props.navigation}
        onPress={() => navigateToScreen()}
        headerContainerStyle={{
          borderBottomColor: "rgba(0, 0, 0, 0.14)",
          borderBottomWidth: 1,
        }}
      />
      <MiddleContentWrapper
        style={{ paddingBottom: 72 }}
        navigation={props.navigation}
        {...props}
      >
        {addresslist &&
          addresslist.length > 0 &&
          addresslist.map((item, index) => {
            console.log("addresslist>>", item.is_default);
            var adddefault = item.is_default;
            let mesdefault = "";

            if (adddefault == true) {
              mesdefault = "(" + "Default" + ")";
            } else {
              mesdefault = "";
            }
            return (
              <React.Fragment key={index}>
                <View style={styles.productContainer}>
                  <TouchableOpacity
                    style={styles.showAllContainer}
                    onPress={() => {
                      let ID = item.id;
                      let shipping_address_type = item.address_type;
                      let shipping_street_address = item.street;
                      let shipping_landmark = item.landmark;
                      let shipping_city = item.city;
                      let shipping_state = item.state;
                      let shipping_zip_code = item.zipcode;
                      console.log("does not work");
                      addressModal(
                        ID,
                        shipping_address_type,
                        shipping_street_address,
                        shipping_landmark,
                        shipping_city,
                        shipping_state,
                        shipping_zip_code
                      );
                    }}
                  >
                    <View style={styles.productContainer}>
                      <View style={styles.productSubContainer}>
                        <View style={[styles.productInnerContainer, {}]}>
                          <View
                            style={[
                              styles.productDetailContainer,
                              { flexDirection: "row", padding: 5 },
                            ]}
                          >
                            <Image
                              source={images.locationIcon}
                              style={{
                                resizeMode: "cover",
                                alignSelf: "center",
                              }}
                            />
                            <View
                              style={{ marginLeft: 5, flex: 1, marginTop: 8 }}
                            >
                              <Text style={styles.headingTitle}>
                                {item.address_type.charAt(0).toUpperCase() +
                                  item.address_type.slice(1)}
                                <Text
                                  style={[
                                    styles.headingTitle,
                                    {
                                      justifyContent: "flex-end",
                                      color: "green",
                                    },
                                  ]}
                                >
                                  {mesdefault}
                                </Text>
                              </Text>

                              <Text
                                style={[
                                  styles.productAddress,
                                  { marginTop: 2 },
                                ]}
                              >
                                {item.city +
                                  "," +
                                  item.landmark +
                                  item.street +
                                  "," +
                                  item.zipcode +
                                  "," +
                                  item.state +
                                  "(" +
                                  item.country +
                                  ")"}
                              </Text>
                            </View>
                          </View>

                          <View
                            style={[
                              styles.productLocationChangeContainer,
                              { flexDirection: "column", padding: 5 },
                            ]}
                          >
                            <View
                              style={{
                                flex: 1,
                                marginTop: 3,
                                justifyContent: "center",
                              }}
                            >
                              <TouchableOpacity
                                onPress={() => {
                                  let id = item.id;
                                  props.navigation.navigate(
                                    "EditAddress",
                                    (nav = { item })
                                    // {
                                    //     onGoBackRefresh: (e) => OnRefresh(e),

                                    // }
                                  );
                                }}
                              >
                                <Text style={[styles.productChangeButton, {}]}>
                                  Edit
                                </Text>
                              </TouchableOpacity>
                            </View>
                            {item.is_default === false && (
                              <View
                                style={styles.productLocationChangeContainer}
                              >
                                <View
                                  style={{
                                    flex: 1,
                                    marginTop: 3,
                                    justifyContent: "center",
                                  }}
                                >
                                  <TouchableOpacity
                                    onPress={() => {
                                      let id = item.id;
                                      //console.log('Delete ID>>',id)
                                      deleteaddressApi(id);
                                    }}
                                  >
                                    <Image
                                      source={images.deleteIcon}
                                      style={{
                                        resizeMode: "cover",
                                        width: 20,
                                        height: 20,
                                        justifyContent: "flex-end",
                                        marginTop: 40,
                                      }}
                                    />
                                  </TouchableOpacity>
                                </View>
                              </View>
                            )}
                          </View>
                        </View>
                      </View>
                    </View>
                  </TouchableOpacity>
                  <HorizontalLine />
                </View>
              </React.Fragment>
            );
          })}
        <View style={{ flex: 1, marginTop: 3, justifyContent: "center" }}>
          {shouldShowNodata ? (
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <View style={{ marginLeft: 30, marginRight: 30 }}>
                <Text style={styles.headingContainer1}>No Address found</Text>
              </View>
              <View style={{ marginLeft: 30, marginRight: 30 }}>
                <Text style={styles.headingContainer1}>Please add address</Text>
              </View>
              <Image source={images.noOrderFound} style={{ marginTop: 30 }} />
            </View>
          ) : null}
        </View>
      </MiddleContentWrapper>

      <View style={{ paddingLeft: 15, paddingRight: 15, paddingBottom: 15 }}>
        <AppButton
          showImage={false}
          btnText={"Add New Address"}
          onPress={() => {
            props.navigation.navigate("AddnewAddress", {
              onGoBackRefresh: (e) => OnRefresh(e),
            });
          }}
          btnContainer={{
            borderRadius: 8,
            borderStyle: "solid",
            borderWidth: 2.5,
            borderColor: "#3d3cb3",
          }}
          btnStyle={{ backgroundColor: "transparent" }}
          btnTextStyle={{
            fontFamily: "Montserrat-Bold",
            fontSize: 14,
            fontWeight: "bold",
            fontStyle: "normal",
            lineHeight: 15.3,
            letterSpacing: 0,
            color: "#3d3cb3",
          }}
        />
      </View>
      <TabBarNavigation navigation={props.navigation} {...props} />
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  showAllContainer: {
    padding: 15,
  },
  PB5: {
    paddingBottom: 5,
  },

  amountContainer: {
    flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    marginLeft: 15,
    marginRight: 15,
    marginTop: 10,
    justifyContent: "flex-start",
    alignItems: "center",
  },
  amountHeading: {
    fontFamily: "Montserrat-Bold",
    fontSize: 14,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 15.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#09051c",
    alignItems: "center",
  },
  totalPrice: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#3d3cb3",
    marginLeft: 10,
  },
  headingTitle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 16,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "#09051c",
  },
  locationContainer: {
    marginTop: 6,
    height: 64,
    borderRadius: 8,
    backgroundColor: "#ffffff",
  },
  productContainer: {
    flex: 1,
    width: "100%",
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    marginTop: 5,
  },
  productSubContainer: {
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    marginTop: 5,
    backgroundColor: "#fff",
  },
  productInnerContainer: {
    flexDirection: "row",
    marginBottom: 5,
  },
  productDetailContainer: {
    width: "85%",
    height: "100%",
    padding: 5,
  },
  productLocationChangeContainer: {
    width: "15%",
  },
  productNameText: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 12,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 16.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#332b55",
  },
  productAddress: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 12,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 16.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#332b55",
  },
  productPlanTypeText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 12,
    fontWeight: "600",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "rgb(16, 16, 16)",
  },
  productAmountText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 17,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 22.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#201f9b",
  },
  productChangeButton: {
    fontFamily: "Montserrat-Bold",
    fontSize: 13,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 14.2,
    letterSpacing: 0,
    textAlign: "left",
    color: "#3d3cb3",
  },
  productAmountDateText1: {
    //opacity: 0.6,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 9,
    fontWeight: "normal",
    fontStyle: "normal",
    letterSpacing: 0.5,
    //textAlign: "center",
    color: "#3b3b3b",
  },
  productAmountButton: {
    width: 81,
    // height: 14,
    borderRadius: 4,
    backgroundColor: "#52b69a",
    justifyContent: "center",
    alignItems: "center",
    padding: 2,
  },
  productStatusText: {
    alignSelf: "center",
    fontFamily: "Montserrat-SemiBold",
    fontSize: 9,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 11.8,
    letterSpacing: 0,
    // textAlign: "left",
    color: "#ffffff",
  },

  showAllContainer: {
    paddingLeft: 15,
    paddingRight: 15,
  },
  headingContainer: {
    fontFamily: "Montserrat-Bold",
    fontSize: 19,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 24.9,
    letterSpacing: 0,
    color: "#09051c",
    textAlign: "center",
  },
  headingContainer1: {
    opacity: 0.8,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    color: "#09051c",
    textAlign: "center",
  },
  btnMainStyle: { flex: 1 / 4, marginTop: 40 },
  btnStyle: {
    width: 111,
    height: 45,
    borderRadius: 10,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    borderStyle: "solid",
    borderWidth: 2.5,
    borderColor: "#3d3cb3",
    backgroundColor: "#fff",
  },
  btnTextStyle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#3d3cb3",
  },
});

export default MyAddress;
