import { putApi ,getApi, postApi,deleteApi} from '../../utils/apiServices';

const getAddressApiUrl = "userAddress/address/user?";
const postaddnewAddressApiUrl = "userAddress/address/";
const deleteAddressApiUrl = "userAddress/address/";
const editAddressApiUrl = "userAddress/address/";

////////////Get Address APi list
export const getAddresslist = async (token,offset) => {
    let putData = {
        "page": offset,
        "per_page":10
    };
    const config = {
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
            Authorization : `Bearer ${token}`}
    };

        let resdata = await getApi(getAddressApiUrl, config,putData)
            .then((response) => {
                return response;
    
            }).catch(function (error) {
                return error;
            });
        // console.log('BillpaymentService>>>',resdata)
        return resdata;
    
    }
    /////Add new Address
    export const postaddnewAddress=async(token,phone,Type,Add,City,Landmark,State,Zip_code,setdefault)=>{
        let putData = {
            "address_type": Type,
            "phone_number": phone,
            "street":Add,
            "landmark": Landmark,
            "city": City,
            "state": State,
            "zipcode":Zip_code,
            "country": "India",
            "is_default":setdefault
        };
        const config = {
            headers: {
                'Accept': 'application/json',
                "Content-Type": "application/json",
                Authorization : `Bearer ${token}`}
        };
            let resdata = await postApi(postaddnewAddressApiUrl,putData, config,false)
                .then((response) => {
                    return response;
        
                }).catch(function (error) {
                    return error;
                });
             console.log('BillpaymentService>>>',resdata,postaddnewAddressApiUrl,putData, config,false)
            return resdata;





    }
    //// Edit Address
    export const EditAddress=async(token,ID,phone,Type,Add,City,Landmark,State,Zip_code,setdefault)=>{
        let putData = {
            "address_type": Type,
            "phone_number": phone,
            "street":Add,
            "landmark": Landmark,
            "city": City,
            "state": State,
            "zipcode":Zip_code,
            "country": "India",
            "is_default":setdefault
        };
        const config = {
            headers: {
                'Accept': 'application/json',
                "Content-Type": "application/json",
                Authorization : `Bearer ${token}`}
        };
            let resdata = await putApi(editAddressApiUrl+ID,putData, config,false)
                .then((response) => {
                    return response;
        
                }).catch(function (error) {
                    return error;
                });
             console.log('EditAddress>>>',resdata,editAddressApiUrl,putData, config,false)
            return resdata;





    }

    /////DeleteAddress
    export const deleteAddress=async(token,id)=>{
        
        const config = {
            headers: {
                'Accept': 'application/json',
                "Content-Type": "application/json",
                Authorization : `Bearer ${token}`}
        };
            let resdata = await deleteApi(deleteAddressApiUrl+id,config)
                .then((response) => {
                    return response;
        
                }).catch(function (error) {
                    return error;
                });
             console.log('DeleteApi>>>',resdata,deleteAddressApiUrl+id,'', config,false)
            return resdata;





    }





    export const putupdateProfile = async (token,name,email) => {
        let data = new FormData()
        data.append('name',name)
        data.append('email', email)
        //console.log(data)
        const config = {
            headers: {
                'Accept': 'application/json',
                'Content-Type' : 'multipart/form-data',
                Authorization : `Bearer ${token}`}
        };
    
            let resdata = await putApi(updateProfileUrl, data,config,false)
                .then((response) => {
                    return response;
        
                }).catch(function (error) {
                    return error;
                });
            // console.log('UpdateProfile>>',resdata,updateProfileUrl,data,config)
            return resdata;
        
        }
     