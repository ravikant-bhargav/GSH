import { getApi } from '../../utils/apiServices';

const billpaymentOngoingAPiUrl = "order/myOrders/BILL_PAYMENTS/ONGOING?";
const billpaymentHistoryAPiUrl = "/order/myOrders/BILL_PAYMENTS/HISTORY?";
export const getbillpaymentOngoingApi = async (token,offset) => {
    let putData = {
        "page": offset,
        "per_page":10
    };
    const config = {
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
            Authorization : `Bearer ${token}`}
    };

        let resdata = await getApi(billpaymentOngoingAPiUrl, config,putData)
            .then((response) => {
                return response;
    
            }).catch(function (error) {
                return error;
            });
        // console.log('BillpaymentService>>>',resdata)
        return resdata;
    
    }

    export const getbillpaymentHistoryApi = async (token,offset) => {
        let putData = {
            "page": offset,
            "per_page":10
        };
        const config = {
            headers: {
                'Accept': 'application/json',
                "Content-Type": "application/json",
                Authorization : `Bearer ${token}`}
        };
    
            let resdata = await getApi(billpaymentHistoryAPiUrl, config,putData)
                .then((response) => {
                    return response;
        
                }).catch(function (error) {
                    return error;
                });
            // console.log('BillpaymentService>>>',resdata)
            return resdata;
        
        }