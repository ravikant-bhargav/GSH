import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
} from 'react-native';
import images from '../../utils/sharedImages';
import HorizontalLine from '../../components/HorizontalLine';

const rupeyCode = "&#8377";
const ProductCard = (props) => {

    const itemLength = props.data.value.length;
     return (
        <React.Fragment>
            <View style={styles.productContainer} key={props.index}>
                <Text style={styles.subHeadingText}>Order ID: #{props.data.key}</Text>
                <View style={styles.productSubContainer}>
                    {props.data && props.data.value.length > 0 && props.data.value.map((item, index) => {

                        const btnBackgroundColor    =   item.order_status_code === "1" ? "#52b69a" : item.order_status_code === "-1"? "#eab50a":"#fe6863"
                        
                        return (
                            <React.Fragment key={index}>
                                <View style={[styles.productInnerContainer, {opacity:item.order_status_code === "-2"?0.55:1}]} >
                                    <View style={[styles.productDetailContainer, { flexDirection: 'row', padding: 10 }]}>
                                        <View style={{ width: "25%" }}>
                                            <Image source={item.image} style={{
                                                width: 44,
                                                height: 61, resizeMode: 'cover'
                                            }} />
                                        </View>
                                        <View style={{ marginLeft: 5, flex: 1, marginTop: 3, width: "75%" }}>
                                            <Text style={styles.productNameText}>
                                                {item.productName}
                                            </Text>
                                            <Text style={[styles.productQtyText, { marginTop: 2 }]}>
                                                {item.qty}
                                            </Text>
                                            <Text style={[styles.productPlanTypeText, { marginTop: 4 }]}>
                                                Plan Type:
                                                <Text style={{ fontFamily: "Montserrat-Bold", color: "rgb(9, 5, 28)" }}>
                                                    {item.planType}
                                                </Text>
                                            </Text>
                                        </View>
                                    </View>
                                    <View style={styles.productAmountContainer}>
                                        <View style={{ flex: 1, marginTop: 3, justifyContent: 'center', alignItems: 'center' }}>
                                            <Text style={styles.productAmountText}>₹ {item.amount}</Text>
                                            <Text style={[styles.productAmountDateText, { marginTop: 2 }]}>Order date</Text>
                                            <Text style={[styles.productAmountDateText1, { marginTop: 2 }]}>{item.date}</Text>
                                            <View style={[styles.productAmountButton,
                                            { marginTop: 4, backgroundColor: btnBackgroundColor}]}>
                                                <Text style={[styles.productStatusText, {}]}>{item.order_status}</Text>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                                {props.itemLength >= 2 && props.itemLength !== index + 1 && (<HorizontalLine />) || null}
                            </React.Fragment>
                        )
                    }) || null}

                </View>
            </View>

            {/* <View style={styles.productContainer}>
                <Text style={styles.subHeadingText}>Order ID: #114</Text>
                <View style={styles.productSubContainer}>
                    <View style={[styles.productInnerContainer, {}]}>
                        <View style={[styles.productDetailContainer, { flexDirection: 'row', padding: 10 }]}>
                            <Image source={images.productImg1} style={{ resizeMode: 'cover' }} />
                            <View style={{ marginLeft: 5, flex: 1, marginTop: 8 }}>
                                <Text style={styles.productNameText}>Anik Pure Milk</Text>
                                <Text style={[styles.productQtyText, { marginTop: 2 }]}>500 ml</Text>
                                <Text style={[styles.productPlanTypeText, { marginTop: 4 }]}>Plan Type: <Text style={{ fontFamily: "Montserrat-Bold", color: "rgb(9, 5, 28)" }}>Daily</Text></Text>
                            </View>
                        </View>
                        <View style={styles.productAmountContainer}>
                            <View style={{ flex: 1, marginTop: 3, justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={styles.productAmountText}>₹ 114</Text>
                                <Text style={[styles.productAmountDateText, { marginTop: 2 }]}>Order date</Text>
                                <Text style={[styles.productAmountDateText1, { marginTop: 2 }]}>23 Mon 2022</Text>
                                <View style={[styles.productAmountButton, { marginTop: 4 }]}>
                                    <Text style={[styles.productStatusText, {}]}>Order Delivered</Text>
                                </View>
                            </View>
                        </View>
                    </View>



                </View>
            </View> */}


        </React.Fragment>


    );
};

export const styles = StyleSheet.create({
    subHeadingText: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 9,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 11.8,
        letterSpacing: 0,
        //textAlign: "left",
        color: "#09051c",
        marginLeft: 10
    },
    productContainer: {
        flex:1,
        width: "100%",
        borderRadius: 13,
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        marginTop: 5
    },
    productSubContainer: {
        borderRadius: 13,
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        marginTop: 5,
        backgroundColor: "#fff"
    },
    productInnerContainer: {
        flexDirection: 'row',
        marginBottom:5,
        
    },
    productDetailContainer: {
        width: "70%",
        height: "100%",
        padding: 5
    },
    productAmountContainer: {
        width: "30%",
    },
    productNameText: {
        fontFamily: "Montserrat-Bold",
        fontSize: 15,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 19.7,
        letterSpacing: 0,
        textAlign: "left",
        color: "#09051c"
    },
    productQtyText: {
        opacity: 0.3,
        fontFamily: "Montserrat-Regular",
        fontSize: 12,
        fontWeight: "normal",
        fontStyle: "normal",
        letterSpacing: 0.5,
        textAlign: "left",
        color: "#3b3b3b"
    },
    productPlanTypeText: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 12,
        fontWeight: "600",
        fontStyle: "normal",
        letterSpacing: 0.5,
        textAlign: "left",
        color: "rgb(16, 16, 16)"
    },
    productAmountText: {
        fontFamily: "Montserrat-Bold",
        fontSize: 17,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 22.3,
        letterSpacing: 0,
        textAlign: "left",
        color: "#201f9b"
    },
    productAmountDateText: {
        opacity: 0.6,
        fontFamily: "Montserrat-Regular",
        fontSize: 9,
        fontWeight: "normal",
        fontStyle: "normal",
        letterSpacing: 0.5,
        textAlign: "center",
        color: "#3b3b3b"
    },
    productAmountDateText1: {
        //opacity: 0.6,
        fontFamily: "Montserrat-SemiBold",
        fontSize: 9,
        fontWeight: "normal",
        fontStyle: "normal",
        letterSpacing: 0.5,
        //textAlign: "center",
        color: "#3b3b3b"
    },
    productAmountButton: {
        width: 81,
        // height: 14,
        borderRadius: 4,
        backgroundColor: "#52b69a",
        justifyContent: 'center',
        alignItems: 'center',
        padding: 2,

    },
    productStatusText: {
        alignSelf: 'center',
        fontFamily: "Montserrat-SemiBold",
        fontSize: 9,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 11.8,
        letterSpacing: 0,
        // textAlign: "left",
        color: "#ffffff"
    }


});

export default ProductCard;