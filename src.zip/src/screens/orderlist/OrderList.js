import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
} from "react-native";

import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";
import { AppButton } from "../../components/button/AppButton";

import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import CalendarCardView from "../../components/calendar/CalendarCardView";
import OrderStatusLabels from "../../components/OrderStatusLabels";
import AmountAdjustment from "../../components/AmountAdjustment";
import HorizontalLine from "../../components/HorizontalLine";
import ProductCard from "./ProductCard";
import DashboardHeader from "../../components/shared/DashboardHeader";
import PrimaryButton from "../../components/button/PrimaryButton";
import LinearGradientView from "../../components/LinearGradientView";
import { getAdjustmentAmount } from "../product/CardApicall";

const productData = [
  {
    key: 112,
    value: [
      {
        productName: "Anik Pure Milk",
        qty: "200 ml",
        planType: "Daily",
        amount: 114,
        date: "23 Mon 2022",
        order_status: "Order Delivered",
        image: images.productImg1,
        order_status_code: "1",
      },
      {
        productName: "Anik Pure Milk",
        qty: "6 Pcs",
        planType: "Daily",
        amount: 114,
        date: "23 Mon 2022",
        order_status: "Active Order",
        image: images.productImg2,
        order_status_code: "-1",
      },
    ],
  },
  {
    key: 114,
    value: [
      {
        productName: "Anik Pure Milk",
        qty: "250 grm",
        planType: "One Time",
        amount: 55,
        date: "23 Mon 2022",
        order_status: "Active Order",
        image: images.productImg3,
        order_status_code: "-1",
      },
      {
        productName: "Anik Pure Milk",
        qty: "250 grm",
        planType: "One Time",
        amount: 55,
        date: "23 Mon 2022",
        order_status: "Order is on Hold",
        image: images.productImg3,
        order_status_code: "-2",
      },
    ],
  },
];

const OrderList = (props) => {
  const navigateToScreen = () => {
    props.navigation.goBack();
  };

  useEffect(() => {
    fetchAdjustmentAmount();
  }, []);

  const [adjustment_Amount, setAmount] = useState(0);
  const [lowBalance_Amount, setlowBalance] = useState(0);

  const fetchAdjustmentAmount = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let user_data = JSON.parse(
      await AsyncStorage.getItem(appConstant.USER_DATA)
    );
    console.log("RES>>>>>", user_data);
    await getAdjustmentAmount(token, user_data.id)
      .then((res) => {
        console.log("RES>>>>>", res);
        const cr_adjustment = res?.data?.cr_adjustment || 0;
        const dr_adjustment = res?.data?.dr_adjustment || 0;
        const value = parseFloat(cr_adjustment) - parseFloat(dr_adjustment);
        const cr_low = res?.data?.cr_due || 0;
        const dr_low = res?.data?.dr_due || 0;
        const lowValue = cr_low - dr_low;

        const setAdjustmentvalue =
          parseFloat(value) >= 0 ? parseFloat(value) : 0;
        setAmount(setAdjustmentvalue);

        const setLowvalue =
          parseFloat(lowValue) >= 0 ? parseFloat(lowValue) : 0;
        setlowBalance(setLowvalue);
      })
      .catch((err) => {
        console.log("ERR/////", err);
      });
  };

  return (
    <React.Fragment>
      <DashboardHeader
        showBackArrow={true}
        headerTitle={"Sunday" + "\n" + "23 Februray"}
        navScreen={props.navigation}
        onPress={() => navigateToScreen()}
      />
      <MiddleContentWrapper>
        <View style={{ padding: 10 }}>
          <CalendarCardView />
          <OrderStatusLabels />
          <AmountAdjustment adjustment_Amount={adjustment_Amount} />
          <HorizontalLine />
        </View>

        <View style={[styles.showAllContainer, {}]}>
          <LinearGradientView
            colors={["rgb(30, 96, 226)", "rgb(58, 141, 255)"]}
            wrapperStyle={styles.lowBalanceContainer}
          >
            <View style={styles.lowBalanceLeftContainer}>
              <Text style={styles.lowbalanceText1}>Low Balance</Text>
              <Text style={styles.lowbalanceText2}>
                <Text style={{ width: 13, height: 13 }}>&#8377;</Text>{" "}
                {lowBalance_Amount}
              </Text>
              <Text style={styles.lowbalanceText3}>
                Next Delivery are on hold
              </Text>
            </View>
            <View style={styles.lowBalanceRightContainer}>
              <PrimaryButton
                buttonText={"Pay dues"}
                imageIcon={images.plusIconMath}
                showImage={true}
                btnStyle={{
                  width: 92,
                  height: 25,
                  borderRadius: 7,
                  backgroundColor: "#ffffff",
                  shadowColor: "rgba(0, 0, 0, 0.12)",
                  shadowOffset: {
                    width: 0,
                    height: 0,
                  },
                  shadowRadius: 4,
                  shadowOpacity: 1,
                }}
                btnImgStyle={{
                  width: 14,
                  height: 14,
                  tintColor: "#3a8dff",
                }}
                btnTextStyle={{
                  fontFamily: "Montserrat-Bold",
                  fontSize: 12,
                  fontWeight: "bold",
                  fontStyle: "normal",
                  lineHeight: 15.7,
                  letterSpacing: 0,
                  textAlign: "left",
                  color: "#3a8dff",
                }}
              />
            </View>
          </LinearGradientView>

          <View style={styles.headingContainer}>
            <Text style={styles.boldTextStyle}>Scheduled Orders</Text>
          </View>

          {productData &&
            productData.length > 0 &&
            productData.map((item, index) => {
              return (
                <ProductCard
                  data={item}
                  key={index}
                  itemLength={item.value.length}
                />
              );
            })}

          <View
            style={{
              marginTop: 45,
              marginBottom: 30,
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <PrimaryButton
              buttonText={"Add More Products"}
              imageIcon={images.AddButton}
              showImage={true}
            />
          </View>
        </View>
      </MiddleContentWrapper>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  showAllContainer: {
    paddingLeft: 15,
    paddingRight: 15,
  },
  lowBalanceContainer: {
    width: "100%",
    height: 80,
    borderRadius: 11,
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 8,
    shadowOpacity: 1,
    marginBottom: 10,
    flexDirection: "row",
  },
  lowBalanceLeftContainer: {
    width: "65%",
    padding: 10,
    justifyContent: "center",
  },
  lowBalanceRightContainer: { width: "35%" },
  lowbalanceText1: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 10,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 13.1,
    letterSpacing: 0,
    color: "#ffffff",
  },
  lowbalanceText2: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 15,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    color: "#ffffff",
  },
  lowbalanceText3: {
    fontFamily: "Montserrat-Bold",
    fontSize: 13,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 17,
    letterSpacing: 0,
    color: "#ffffff",
  },

  headingContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  boldTextStyle: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 15,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    color: "#09051c",
  },
});

export default OrderList;
