import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
    BackHandler,
} from 'react-native';
import {
    useFocusEffect
  } from '@react-navigation/native';
   

import appColors from '../../utils/appColors';
import images from '../../utils/sharedImages';
import LinearGradient from 'react-native-linear-gradient';
import { AppButton } from '../../components/button/AppButton';

import MiddleContentWrapper from '../../components/contentWrapper/MiddleContentWrapper';
import CalendarCardView from '../../components/calendar/CalendarCardView';
import OrderStatusLabels from '../../components/OrderStatusLabels';
import AmountAdjustment from '../../components/AmountAdjustment';
import HorizontalLine from '../../components/HorizontalLine';
import ProductCard from './ProductCard';
import DashboardHeader from '../../components/shared/DashboardHeader';
import PrimaryButton from '../../components/button/PrimaryButton';
import LinearGradientView from '../../components/LinearGradientView';

const productData = [
    {
        "key": 112,
        "value": [
            {
                productName: 'Anik Pure Milk',
                qty: '200 ml',
                planType: "Daily",
                amount: 114,
                date: "23 Mon 2022",
                order_status: 'Order Delivered',
                image: images.productImg1,
                order_status_code: '1'
            },
            {
                productName: 'Anik Pure Milk',
                qty: '6 Pcs',
                planType: "Daily",
                amount: 114,
                date: "23 Mon 2022",
                order_status: 'Active Order',
                image: images.productImg2,
                order_status_code: '-1'
            },


        ]
    },
    {
        "key": 114,
        "value": [
            {
                productName: 'Anik Pure Milk',
                qty: '250 grm',
                planType: "One Time",
                amount: 55,
                date: "23 Mon 2022",
                order_status: 'Active Order',
                image: images.productImg3,
                order_status_code: '-1'
            },
            {
                productName: 'Anik Pure Milk',
                qty: '250 grm',
                planType: "One Time",
                amount: 55,
                date: "23 Mon 2022",
                order_status: 'Order is on Hold',
                image: images.productImg3,
                order_status_code: '-2'
            }
        ]
    },

];



const NoOrder = (props) => {
   // console.log(props)
    useFocusEffect(
        React.useCallback(() => {
          const onBackPress = () => {
            props.navigation.navigate('Dashboard') 
            // Return true to stop default back navigaton
            // Return false to keep default back navigaton
            return true;
          };
     
          // Add Event Listener for hardwareBackPress
          BackHandler.addEventListener(
            'hardwareBackPress',
            onBackPress
          );
     
          return () => {
            // Once the Screen gets blur Remove Event Listener
            BackHandler.removeEventListener(
              'hardwareBackPress',
              onBackPress
            );
          };
        }, []),
      );

    return (
        <React.Fragment>
            <DashboardHeader
                showBackArrow={true}
                headerTitle={"Sunday"+"\n"+"23 Februray"}
                navScreen={props.navigation}
            />
            <MiddleContentWrapper>
                <View style={{ padding: 10 }}>
                    <CalendarCardView />
                    <OrderStatusLabels />

                </View>

                <View style={[styles.showAllContainer, {}]}>
                    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', marginTop: 50 }}>
                        <Text style={{
                            fontFamily: "Montserrat-Bold",
                            fontSize: 19,
                            fontWeight: "bold",
                            fontStyle: "normal",
                            lineHeight: 24.9,
                            letterSpacing: 0,
                            textAlign: "left",
                            color: "#09051c"
                        }}>No Orders Found!</Text>
                        <Text style={{
                            opacity: 0.8,
                            fontFamily: "Montserrat-SemiBold",
                            fontSize: 14,
                            fontWeight: "600",
                            fontStyle: "normal",
                            lineHeight: 18.3,
                            letterSpacing: 0,
                            textAlign: "left",
                            color: "#09051c"
                        }}>No Orders for the day</Text>


                        <Image source={images.noOrderFound} style={{ marginTop: 12 }} />
                    </View>

                    <View style={{ marginTop: 45, marginBottom: 30, justifyContent: 'center', alignItems: 'center' }}>
                        <PrimaryButton
                            buttonText={"Add Products"}
                            imageIcon={images.AddButton}
                            showImage={true}
                        />
                    </View>

                </View>

            </MiddleContentWrapper>
        </React.Fragment>


    );
};

export const styles = StyleSheet.create({

    showAllContainer: {
        paddingLeft: 15,
        paddingRight: 15,
    },


    headingContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    boldTextStyle: {
        fontFamily: "Montserrat-ExtraBold",
        fontSize: 15,
        fontWeight: "800",
        fontStyle: "normal",
        lineHeight: 19.7,
        letterSpacing: 0,
        color: "#09051c"
    },


});

export default NoOrder;