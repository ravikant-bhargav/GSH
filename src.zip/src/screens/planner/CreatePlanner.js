import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  Modal,
  Dimensions,
} from "react-native";

import images from "../../utils/sharedImages";

import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import DashboardHeader from "../../components/shared/DashboardHeader";
import PrimaryButtonResize from "../../components/button/PrimaryButtonResize";
import AppCalendar from "../../components/calendar/AppCalendar";
import HorizontalLine from "../../components/HorizontalLine";
import CalendarStripView from "../../components/calendar/CalendarStrip";
import PaymentFooter from "../../components/PaymentFooter";
import AddToCartFooter from "../product/AddToCartFooter";
import ActionSheetDialog from "../../components/ActionSheetDialog";
import ActionSheet, { SheetManager } from "react-native-actions-sheet";
import PlannerSheet from "./PlannerSheet";
import moment from "moment";
import { calenderApiForSubscription } from "../mycalendar/CalenderApiServices";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";

const windowHeight = Dimensions.get("window").height;

const CreatePlanner = (props) => {
  const [modalVisible, setModalVisible] = React.useState(false);
  const [datesRange, setDatesRange] = React.useState({
    startDate: moment(new Date()).format("YYYY-MM-DD"),
    endDate: moment(new Date()).add(6, "days").format("YYYY-MM-DD"),
  });
  const [dateArray, setDateArray] = React.useState([]);
  const [dateList, setDateList] = React.useState([]);

  const navigateToScreen = () => {
    props.navigation.goBack();
  };
  const actionSheetRef = useRef(null);
  const openActionSheet = () => {
    SheetManager.show("test_sheet_id", { text: "Hello World" });
  };

  const getDate = (value, mMarkedDates) => {
    setDatesRange(value);
    setDateArray(Object.keys(mMarkedDates));

    getCalenderData(
      Object.keys(mMarkedDates),
      Object.keys(mMarkedDates)[0],
      Object.keys(mMarkedDates)[6]
    );
  };

  useEffect(() => {
    setDateArray(getInitialDays(moment(new Date()).format("YYYY-MM-DD")));

    //let firstDay = moment(new Date(year, month, 1)).format('YYYY/MM/DD');
    getCalenderData(
      getInitialDays(moment(new Date()).format("YYYY-MM-DD")),
      moment(new Date()).format("YYYY-MM-DD"),
      moment(new Date()).add(6, "days").format("YYYY-MM-DD")
    );
  }, []);

  const getInitialDays = (dateString) => {
    let markedDates = {
      [dateString]: {
        startingDay: true,
        customStyles: {
          container: {
            backgroundColor: "#3d3cb3",
          },
          text: {
            color: "#ffffff",
            fontWeight: "bold",
          },
        },
      },
    };

    let endDate = null;

    for (var i = 0; i <= 6; i++) {
      endDate = moment(dateString).add(i, "days").format("YYYY-MM-DD");
      markedDates[moment(dateString).add(i, "days").format("YYYY-MM-DD")] = {
        endingDay: true,
        customStyles: {
          container: {
            backgroundColor: "#3d3cb3",
          },
          text: {
            color: "#ffffff",
            fontWeight: "bold",
          },
        },
      };
    }

    return Object.keys(markedDates);
  };

  const getCalenderData = async (dateArray, firstDay, lastday) => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    // setIsLoading(true);
    const reasData = await calenderApiForSubscription(
      token,
      1,
      firstDay,
      lastday
    );
    if (reasData && reasData.status === 200) {
      //  setIsLoading(false);
      let data =
        reasData &&
        reasData.data &&
        reasData.data.data &&
        reasData.data.data.rows;

      emptyCalendar(dateArray, data);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      // setIsLoading(false);
      console.log("getCalenderData err >>", reasData);
    }
  };

  const emptyCalendar = (dateArray, data) => {
    console.log("data ==> ", JSON.stringify(data));
    console.log("dateArray ==> ", JSON.stringify(dateArray));

    let newDta = [];
    let theOriginalData = [];

    dateArray.map((item1) => {
      let dateObject = {
        itemDetails: [],
        id: "",
        day: "",
        delivery_date: "",
      };

      let newFilteredData = data.filter((item) => {
        let deliveryDate = moment(item.delivery_date).format("YYYY-MM-DD");
        let calendarDate = moment(item1).format("YYYY-MM-DD");

        return moment(deliveryDate).isSame(calendarDate);
      });

      console.log("newFilteredData ==> ", JSON.stringify(newFilteredData));

      dateObject.itemDetails = newFilteredData;
      dateObject.id = moment(item1)
        .format("DD/MM/YYYY")
        .split("/")[0]
        .toString();
      dateObject.day = moment(item1).format("ddd");
      dateObject.delivery_date = moment(item1).format("DD/MM/YYYY");

      newDta.push(dateObject);
    });

    console.log("new ate==> ", JSON.stringify(newDta));

    theOriginalData.push(...newDta);

    setDateList(theOriginalData);
  };

  const getCallback = (somedata) => {
    console.log(
      "getCallback ========================>>>>>>>>>>>>>>> ",
      somedata
    );
  };

  return (
    <React.Fragment>
      <DashboardHeader
        showBackArrow={true}
        headerTitle={"Weekly Planner"}
        navScreen={props.navigation}
        headerContainerStyle={{
          borderBottomColor: "rgba(0, 0, 0, 0.14)",
          borderBottomWidth: 1,
        }}
        onPress={() => navigateToScreen()}
      />
      <MiddleContentWrapper navigation={props.navigation} {...props}>
        <View style={[styles.showAllContainer, { flex: 1 }]}>
          <View style={styles.inputContainer}>
            <View style={styles.startDateContainer}>
              <TouchableOpacity
                onPress={() => {
                  setModalVisible(true);
                }}
                style={styles.startInnerConatiner}
              >
                <View
                  style={[
                    styles.serachBoxContainer,
                    { flexDirection: "column" },
                  ]}
                >
                  <Text style={[styles.dateText, { marginBottom: 3 }]}>
                    Start Date
                  </Text>
                  <Text style={styles.serachInputContainer}>
                    {datesRange && datesRange.startDate}
                  </Text>
                </View>
                <Image
                  source={images.pencilEditIcon}
                  style={styles.searchButton}
                />
              </TouchableOpacity>
            </View>

            <View style={styles.endDateContainer}>
              <TouchableOpacity
                onPress={() => {
                  setModalVisible(true);
                }}
                style={styles.endInnerConatiner}
              >
                <View
                  style={[
                    styles.serachBoxContainer,
                    { flexDirection: "column" },
                  ]}
                >
                  <Text style={[styles.dateText, { marginBottom: 3 }]}>
                    End Date
                  </Text>
                  <Text style={styles.serachInputContainer}>
                    {datesRange && datesRange.endDate}
                  </Text>
                </View>
                <Image
                  source={images.pencilEditIcon}
                  style={styles.searchButton}
                />
              </TouchableOpacity>
            </View>

            <View
              style={{
                width: "20%",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <PrimaryButtonResize
                btnText={"Select"}
                btnCustomStyle={{
                  width: 74,
                  borderRadius: 5,
                  borderStyle: "solid",
                  borderWidth: 2,
                  borderColor: "#3d3cb3",
                  backgroundColor: "transparent",
                }}
                btnTextStyle={{
                  fontFamily: "Montserrat-Bold",
                  fontSize: 14,
                  fontWeight: "bold",
                  fontStyle: "normal",
                  lineHeight: 15.3,
                  letterSpacing: 0,
                  textAlign: "right",
                  color: "#3d3cb3",
                }}
              />
            </View>
          </View>

          <HorizontalLine />

          {/*<View style={{}}>
                        <CalendarStripView datesRange={datesRange} />
                    </View>*/}

          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-around",
              width: "100%",
              marginVertical: 10,
            }}
          >
            {dateArray &&
              dateArray.length > 0 &&
              dateArray.map((item, index) => {
                console.log("dateArray && dateArray ==> ", item.toString());
                return (
                  <View
                    key={index}
                    style={{ justifyContent: "center", alignItems: "center" }}
                  >
                    <Text
                      style={{
                        fontFamily: "Montserrat-SemiBold",
                        fontSize: 12,
                        fontWeight: "600",
                        fontStyle: "normal",
                        lineHeight: 13.1,
                        letterSpacing: 0,
                        textAlign: "left",
                        color: "#000000",
                      }}
                    >
                      {moment(item).format("ddd").toUpperCase().charAt(0) +
                        moment(item).format("ddd").slice(1)}
                    </Text>

                    <View
                      style={{
                        width: 33,
                        height: 33,
                        // backgroundColor: seletedDate === true ? "#3d3cb3" : "#ffffff",
                        backgroundColor: "#ffffff",
                        shadowColor: "rgba(0, 0, 0, 0.25)",
                        shadowOffset: {
                          width: 0,
                          height: 0,
                        },
                        shadowRadius: 4,
                        shadowOpacity: 1,
                        borderRadius: 20,
                        alignItems: "center",
                        justifyContent: "center",
                        marginTop: 3,
                        elevation: 20,
                      }}
                    >
                      <Text
                        style={{
                          fontFamily: "Montserrat-Bold",
                          fontSize: 12,
                          fontWeight: "bold",
                          fontStyle: "normal",
                          lineHeight: 14,
                          letterSpacing: 0,
                          textAlign: "left",
                          //color: seletedDate === true ? "#fefeff" : "#3d3cb3"
                          color: "#3d3cb3",
                        }}
                      >
                        {item.toString().split("-")[2] + ""}
                      </Text>
                    </View>
                  </View>
                );
              })}
          </View>

          <HorizontalLine />

          <View
            style={{
              flex: 1,
              flexDirection: "row",
              height: windowHeight,
              width: "100%",
            }}
          >
            {dateList.map((item, index) => {
              return (
                <View
                  key={index}
                  style={[styles.itemLayout, { paddingTop: 8 }]}
                >
                  {item && item.itemDetails && item.itemDetails.length > 0
                    ? item &&
                      item.itemDetails &&
                      item.itemDetails.map((itemm, index) => {
                        return (
                          <TouchableOpacity
                            key={index}
                            style={{
                              width: "90%",
                              padding: 5,
                              borderRadius: 4,
                              backgroundColor: "#447ED2",
                              marginBottom: 5,
                            }}
                            onPress={() => {
                              let id = itemm.order_id;
                              props.navigation.navigate("OrderDetailspage", id);
                            }}
                          >
                            <Text
                              style={{
                                fontFamily: "Montserrat-SemiBold",
                                fontSize: 8,
                                color: "#ffffff",
                              }}
                            >
                              {itemm && itemm.product_name}
                            </Text>
                          </TouchableOpacity>
                        );
                      })
                    : null}

                  <TouchableOpacity
                    onPress={() =>
                      props.navigation.navigate("CategoryProduct", {
                        fromScreen: "CreatePlanner",
                        getCallback: (e) => getCallback(e),
                      })
                    }
                    style={[styles.btnItem, { margin: 8 }]}
                  >
                    <Text style={styles.btnText}>Add Item</Text>
                  </TouchableOpacity>
                </View>
              );
            })}
          </View>
        </View>

        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            setModalVisible(!modalVisible);
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <AppCalendar
                screenName={"CreatePlanner"}
                getDate={getDate}
                onClose={setModalVisible}
              />

              <PrimaryButtonResize
                onPress={() => {
                  setModalVisible(false);
                }}
                btnText={"Select"}
                btnCustomStyle={{
                  width: "70%",
                  borderRadius: 5,
                  borderStyle: "solid",
                  borderWidth: 2,
                  borderColor: "#3d3cb3",
                  backgroundColor: "transparent",
                }}
                btnTextStyle={{
                  fontFamily: "Montserrat-Bold",
                  fontSize: 14,
                  fontWeight: "bold",
                  fontStyle: "normal",
                  lineHeight: 15.3,
                  letterSpacing: 0,
                  textAlign: "right",
                  color: "#3d3cb3",
                }}
              />
            </View>
          </View>
        </Modal>
      </MiddleContentWrapper>
      <ActionSheetDialog
        actionSheetRef={actionSheetRef}
        sheetId={"test_sheet_id"}
      >
        <PlannerSheet actionSheetRef={actionSheetRef} />
      </ActionSheetDialog>

      {/* <PaymentFooter isShowFAB={false}
                text={"Total Order Amount"}
                amount={200}
                customStyleAmount={{
                    fontFamily: "Montserrat-ExtraBold",
                    fontSize: 16,
                    fontWeight: "800",
                    fontStyle: "normal",
                    lineHeight: 21,
                    letterSpacing: 0,
                    textAlign: "left",
                    color: "#201f9b"
                }}
                showButton={true}
                btnText={"Save and Pay"}
                btnStyle={{ backgroundColor: "#14b661" }}
                onPress={() => { openActionSheet() }}
            />
*/}
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  showAllContainer: {
    flex: 1,
  },
  inputContainer: {
    padding: 15,
    flex: 1,
    width: "100%",
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    alignItems: "center",
  },
  startDateContainer: {
    width: "40%",
  },
  startInnerConatiner: {
    width: "80%",
    flexDirection: "row",
    borderBottomColor: "#3d3cb3",
    borderBottomWidth: 1,
  },
  endDateContainer: {
    width: "40%",
  },
  endInnerConatiner: {
    width: "70%",
    flexDirection: "row",
    borderBottomColor: "#3d3cb3",
    borderBottomWidth: 1,
  },
  dateText: {
    fontFamily: "Montserrat-Medium",
    fontSize: 12,
    fontWeight: "500",
    fontStyle: "normal",
    lineHeight: 13.1,
    letterSpacing: 0,
    textAlign: "left",
    color: "#000000",
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0,0.4)",
    height: "50%",
  },

  modalView: {
    borderRadius: 20,
    padding: 10,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    backgroundColor: "#fff",
    width: "92%",
  },
  serachInputContainer: {
    paddingRight: 3,
    paddingLeft: 0,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 15.3,
    letterSpacing: 0,
    color: "#000000",
  },
  itemLayout: {
    height: "100%",
    width: "14.28%",
    borderRightColor: "rgba(0, 0, 0, 0.14)",
    borderRightWidth: 1,
    alignItems: "center",
  },
  btnItem: {
    width: 44,
    height: 20,
    borderRadius: 4,
    borderStyle: "solid",
    borderWidth: 1,
    borderColor: "#716e6e",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
  },
  btnText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 8,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 9.2,
    letterSpacing: 0,
    textAlign: "center",
    color: "#585656",
  },
  btnItemValue: {
    borderRadius: 4,
    borderStyle: "solid",
    borderWidth: 1,
    borderColor: "#716e6e",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
    backgroundColor: "#457dd2",
    padding: 1,
  },
  btnTextValue: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 10,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 11.8,
    letterSpacing: 0,
    textAlign: "left",
    color: "#ffffff",
  },
});

export default CreatePlanner;
