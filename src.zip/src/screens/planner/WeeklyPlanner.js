import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
} from 'react-native';

import appColors from '../../utils/appColors';
import images from '../../utils/sharedImages';
import LinearGradient from 'react-native-linear-gradient';


import MiddleContentWrapper from '../../components/contentWrapper/MiddleContentWrapper';
import DashboardHeader from '../../components/shared/DashboardHeader';
import PrimaryButtonResize from '../../components/button/PrimaryButtonResize';


const plannerData = [
    {
        id: 1,
        planner_id: "00233",
        order_list: "Anik pure milk x3 , Amul butter x1, Pure Ghee x1 , Harvest Bread x2 "
    },
    {
        id: 2,
        planner_id: "00233",
        order_list: "Anik pure milk x3 , Amul butter x1 "
    },
    {
        id: 3,
        planner_id: "00233",
        order_list: "Anik pure milk x3 , Amul butter x1, Pure Ghee x1 , Harvest Bread x2 "
    },
    {
        id: 4,
        planner_id: "00233",
        order_list: "Anik pure milk x3 , Amul butter x1, Harvest Bread x2 "
    },
    {
        id: 4,
        planner_id: "00233",
        order_list: "Anik pure milk x3 , Amul butter x1, Harvest Bread x2 "
    },
    {
        id: 4,
        planner_id: "00233",
        order_list: "Anik pure milk x3 , Amul butter x1, Harvest Bread x2 "
    },
    {
        id: 4,
        planner_id: "00233",
        order_list: "Anik pure milk x3 , Amul butter x1, Harvest Bread x2,Anik pure milk x3 , Amul butter x1, Harvest Bread x2 "
    },
];







const WeeklyPlanner = (props) => {


    const navigateToScreen = () => {
        props.navigation.goBack();
    }



    return (
        <React.Fragment>
            <DashboardHeader
                showBackArrow={true}
                headerTitle={""}
                headerTitle={"Weekly Planner"}
                navScreen={props.navigation}
                headerContainerStyle={{
                    borderBottomColor: "rgba(0, 0, 0, 0.14)",
                    borderBottomWidth: 1,
                }}
                onPress={() => navigateToScreen()}
            />
            <MiddleContentWrapper navigation={props.navigation} {...props} style={{ paddingBottom: 0 }} >


                <View style={[styles.showAllContainer, {}]}>
                    <View style={{ justifyContent: 'center', alignItems: 'center', marginTop: 20 }}>
                        <PrimaryButtonResize
                            showImage={false}
                            btnText={"Create new Planner"}
                            btnCustomStyle={{
                                width: "100%",
                                borderRadius: 8,
                                borderStyle: "solid",
                                borderWidth: 2.5,
                                borderColor: "#3d3cb3",
                                backgroundColor: "transparent",
                                height: 45
                            }}

                            btnTextStyle={{
                                fontFamily: "Montserrat-Bold",
                                fontSize: 15,
                                fontWeight: "bold",
                                fontStyle: "normal",
                                letterSpacing: 0.5,
                                color: "#3d3cb3"
                            }}
                            onPress={() => props.navigation.navigate("CreatePlanner")}
                        />
                    </View>


                    {plannerData && plannerData.length > 0 && plannerData.map((item, index) => {
                        return (
                            <View style={styles.productSubContainer} key={index}>
                                <View style={[styles.productInnerContainer, {}]}>
                                    <View style={[styles.productDetailContainer, { flexDirection: 'row', padding: 5 }]}>
                                        {/* <Image source={images.productImg1} style={{ resizeMode: 'cover' }} /> */}
                                        <View style={{ marginLeft: 5, flex: 1, marginTop: 8 }}>
                                            <Text style={styles.productNameText}>Planner ID- <Text style={{ color: 'rgb(61, 60, 179)' }}>#{item.planner_id}</Text></Text>
                                            <Text style={[styles.productPlanTypeText, { marginTop: 4, color: "#332b55" }]}>
                                                {item.order_list}
                                            </Text>

                                        </View>
                                    </View>
                                    <View style={styles.productAmountContainer}>
                                        <View style={{ flex: 1, marginTop: 3, justifyContent: 'center', alignItems: 'center' }}>
                                            <View style={[styles.productAmountButton, { marginTop: 4 }]}>
                                                <Text style={[styles.productButtonText, {}]}>View</Text>
                                            </View>
                                        </View>
                                    </View>
                                </View>

                            </View>
                        )

                    }) || (<View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', marginTop: 70 }}>
                        <View style={{ marginLeft: 57, marginRight: 57, }}>
                            <Text style={styles.headingContainer}>No Planned Orders</Text>
                        </View>
                        <View style={{ marginLeft: 50, marginRight: 56, }}>
                            <Text style={styles.headingContainer1}>You can plan weekly orders here
                                add products for a week</Text>
                        </View>
                        <Image source={images.NoPlanIcon} style={{
                            marginTop: 30, width: 224,
                            height: 148.4
                        }} />
                    </View>)}





                </View>

            </MiddleContentWrapper>



        </React.Fragment>


    );
};

export const styles = StyleSheet.create({

    showAllContainer: {
        padding: 15
    },
    headingContainer: {
        fontFamily: "Montserrat-Bold",
        fontSize: 19,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 24.9,
        letterSpacing: 0,
        textAlign: "left",
        color: "#09051c"
    },
    headingContainer1: {
        opacity: 0.8,
        fontFamily: "Montserrat-SemiBold",
        fontSize: 14,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 18.3,
        letterSpacing: 0,
        textAlign: "center",
        color: "#09051c"
    },
    productSubContainer: {
        borderRadius: 13,
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        marginTop: 10,
        backgroundColor: "#fff",
        paddingLeft: 10,
        paddingRight: 10
    },
    productInnerContainer: {
        flexDirection: 'row',
        marginBottom: 5,

    },
    productDetailContainer: {
        width: "70%",
        height: "100%",
        //padding: 10
    },
    productAmountContainer: {
        width: "30%",

    },
    productNameText: {
        fontFamily: "Montserrat-SemiBold",

        fontSize: 15,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 19.7,
        letterSpacing: 0,
        textAlign: "left",
        color: "#09051c"
    },

    productPlanTypeText: {
        fontFamily: "Montserrat-Bold",
        fontSize: 10,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 13.1,
        letterSpacing: 0,
        textAlign: "left",
        color: "#3d3cb3"
    },


    productAmountButton: {
        width: 98,
        height: 31.3,
        borderRadius: 6,
        backgroundColor: "#3d3cb3",
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 12,
            height: 26
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        justifyContent: 'center',
        alignItems: 'center'

    },
    productButtonText: {
        alignSelf: 'center',
        fontFamily: "Montserrat-Bold",
        fontSize: 12,
        fontWeight: "bold",
        fontStyle: "normal",
        letterSpacing: 0.5,
        // textAlign: "left",
        color: "#f5f5f6"

    }



});

export default WeeklyPlanner;