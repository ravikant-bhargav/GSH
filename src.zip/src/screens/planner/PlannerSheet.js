import React, { Children, useRef } from "react";
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import PrimaryButtonResize from "../../components/button/PrimaryButtonResize";
import HorizontalLine from "../../components/HorizontalLine";

const PlannerSheet = (props) => {
  console.log(">>>>>>>>>>>PLANNERSHEET", props.navigation);
  const cart_details = props.cartDetails;
  return (
    <>
      <View style={{}}>
        <Text
          style={{
            fontFamily: "Montserrat",
            fontSize: 13,
            fontWeight: "bold",
            fontStyle: "normal",
            lineHeight: 17.6,
            letterSpacing: 0,
            textAlign: "left",
            color: "#332b55",
          }}
        >
          Discount Coupon
        </Text>

        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            width: "100%",
            marginTop: 8,
            marginBottom: 15,
          }}
        >
          <View style={{ width: "70%" }}>
            <TextInput
              style={styles.input}
              multiline={false}
              placeholder="Write your text here"
              onFocus={() => {
                props.actionSheetRef.current?.snapToOffset(600);
              }}
            />
          </View>
          <View style={{ width: "30%" }}>
            <PrimaryButtonResize
              btnText={"Apply"}
              btnCustomStyle={{
                width: 94,
                height: 35,
                borderRadius: 7,
                backgroundColor: "#3d3cb3",
                borderStyle: "solid",
                borderWidth: 2,
                borderColor: "#3d3cb3",
              }}
            />
          </View>
        </View>
        <View style={{ marginTop: 10 }}>
          <Text
            style={{
              fontFamily: "Montserrat-Bold",
              fontSize: 13,
              fontWeight: "bold",
              fontStyle: "normal",
              lineHeight: 17.6,
              letterSpacing: 0,
              textAlign: "left",
              color: "#332b55",
            }}
          >
            Bill Details
          </Text>
          <View style={styles.billDetailElement}>
            <View style={{ width: "70%" }}>
              <Text style={styles.billDetailTitle}>Sub total</Text>
            </View>
            <View style={{ width: "30%" }}>
              <Text style={styles.billDetailValue}>
                ₹ {cart_details.cart_details?.bill_details?.sub_total}
              </Text>
            </View>
          </View>
          {/* <View style={styles.billDetailElement}>
            <View style={{ width: "70%" }}>
              <Text style={styles.billDetailTitle}>Item Discount</Text>
            </View>
            <View style={{ width: "30%" }}>
              <Text style={[styles.billDetailValue, { color: "#3d3cb3" }]}>
                -₹{" "}
                {cart_details.cart_details.bill_details.delivery_fees_discount}
              </Text>
            </View>
          </View> */}
          <View style={styles.billDetailElement}>
            <View style={{ width: "70%" }}>
              <Text style={styles.billDetailTitle}>Delivery fees</Text>
            </View>
            <View style={{ width: "30%" }}>
              <Text style={styles.billDetailValue}>
                ₹ {cart_details.cart_details.bill_details.delivery_fees}
              </Text>
            </View>
          </View>
          <View style={styles.billDetailElement}>
            <View style={{ width: "70%" }}>
              <Text style={styles.billDetailTitle}>Delivery fees discount</Text>
            </View>
            <View style={{ width: "30%" }}>
              <Text style={[styles.billDetailValue, { color: "#2dad89" }]}>
                -₹{" "}
                {cart_details.cart_details.bill_details.delivery_fees_discount}
              </Text>
            </View>
          </View>
          <View style={styles.billDetailElement}>
            <View style={{ width: "70%" }}>
              <Text style={styles.billDetailTitle}>Item Total</Text>
            </View>
            <View style={{ width: "30%" }}>
              <Text style={styles.billDetailValue}>
                ₹ {cart_details.cart_details.bill_details.item_total}
              </Text>
            </View>
          </View>
        </View>
        <HorizontalLine />
        <View style={{ marginTop: 10 }}>
          <Text
            style={{
              fontFamily: "Montserrat-Bold",
              fontSize: 13,
              fontWeight: "bold",
              fontStyle: "normal",
              lineHeight: 17.6,
              letterSpacing: 0,
              textAlign: "left",
              color: "#332b55",
            }}
          >
            To Pay
          </Text>

          <View style={[styles.billDetailElement, { marginBottom: 2 }]}>
            <View style={{ width: "70%" }}>
              <Text style={styles.billDetailTitle}>Sub total</Text>
            </View>
            <View style={{ width: "30%" }}>
              <Text style={styles.billDetailValue}>
                ₹ {cart_details.cart_details.bill_details.sub_total}
              </Text>
            </View>
          </View>

          <View style={[styles.billDetailElement, { marginTop: 0 }]}>
            <View style={{ width: "70%" }}>
              <Text style={styles.billDetailTitle}>Advance Payment</Text>
            </View>
            <View style={{ width: "30%" }}>
              <Text style={[styles.billDetailValue, { color: "#2dad89" }]}>
                -₹ {cart_details.cart_details.bill_details.advance_payment}
              </Text>
            </View>
          </View>
        </View>

        <HorizontalLine />
        <View style={{ marginTop: 10 }}>
          <View style={[styles.billDetailElement, { marginBottom: 2 }]}>
            <View
              style={{
                width: "58%",
                flexDirection: "column",
                alignItems: "flex-start",
                justifyContent: "flex-start",
              }}
            >
              <Text
                style={[
                  styles.billDetailTitle,
                  {
                    fontFamily: "Montserrat-SemiBold",
                    fontSize: 13,
                  },
                ]}
              >
                Grand Total
              </Text>
              <Text
                style={[
                  styles.billDetailTitle,
                  {
                    fontFamily: "Montserrat-Bold",
                    fontSize: 16,
                    marginTop: 5,
                    fontWeight: "bold",
                    fontStyle: "normal",
                    lineHeight: 21.7,
                  },
                ]}
              >
                 ₹ {cart_details.cart_details.bill_details.grand_total}
              </Text>
            </View>
            <View style={{ width: "42%" }}>
              <PrimaryButtonResize
                btnText={"Make Payment"}
                btnCustomStyle={{
                  width: 146,
                  height: 47,
                  borderRadius: 7,
                  backgroundColor: "#14b661",
                  borderStyle: "solid",
                  borderWidth: 1,
                  borderColor: "#14b661",
                }}
                btnTextStyle={{
                  fontSize: 14,
                  fontWeight: "bold",
                }}
                onPress={() => {
                  props.navigation.navigate(
                    "PaymentMethod",
                    (paymentData = { cart_details })
                  );
                }}
              />
            </View>
          </View>
        </View>
      </View>
    </>
  );
};

export default PlannerSheet;

const styles = StyleSheet.create({
  placeholder: {
    height: 15,
    backgroundColor: "#f0f0f0",
    marginVertical: 15,
    borderRadius: 5,
  },

  input: {
    width: "100%",
    height: 35,
    opacity: 0.79,
    borderRadius: 6,
    borderStyle: "solid",
    borderWidth: 1.5,
    borderColor: "#2e2e2e",
    paddingLeft: 10,
    paddingRight: 10,
    opacity: 0.79,
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 13,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 17.6,
    letterSpacing: 0,
    textAlign: "left",
    color: "#141414",
  },

  billDetailTitle: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 11,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 14.9,
    letterSpacing: 0,
    textAlign: "left",
    color: "#332b55",
  },
  billDetailValue: {
    fontFamily: "Montserrat-Bold",
    fontSize: 11,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 14.9,
    letterSpacing: 0,
    textAlign: "right",
    color: "#332b55",
  },
  billDetailElement: {
    flexDirection: "row",
    width: "100%",
    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
  },
});
