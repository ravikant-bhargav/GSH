import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
} from 'react-native';

import appColors from '../../utils/appColors';
import images from '../../utils/sharedImages';

import PrimaryButton from '../../components/button/PrimaryButton';

const UnderMaintenenance = (props) => {

    return (
        <React.Fragment>

            <View style={[styles.showAllContainer, { flex: 1 }]}>
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <View style={{ marginLeft: 57, marginRight: 57, }}>
                        <Text style={styles.headingContainer}>Under Maintenance</Text>
                    </View>
                    <View style={{ marginLeft: 50,marginRight: 56,}}>
                        <Text style={styles.headingContainer1}>This page under maintenance and will be back soon</Text>
                    </View>
                    <Image source={images.underMaintenance} style={{ marginTop: 30 }} />
                    <PrimaryButton
                        buttonText={"Go Home"}
                        imageIcon={images.AddButton}
                        showImage={false}
                        btnStyleMain={styles.btnMainStyle}
                        btnStyle={styles.btnStyle}
                        btnTextStyle={styles.btnTextStyle}
                    />
                </View>
            </View>

        </React.Fragment>
    );
};

export const styles = StyleSheet.create({

    showAllContainer: {
        paddingLeft: 15,
        paddingRight: 15,
    },
    headingContainer: {
        fontFamily: "Montserrat-Bold",
        fontSize: 19,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 24.9,
        letterSpacing: 0,
        color: "#09051c",
        textAlign: 'center'
    },
    headingContainer1: {
        opacity: 0.8,
        fontFamily: "Montserrat-SemiBold",
        fontSize: 14,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 18.3,
        letterSpacing: 0,
        color: "#09051c",
        textAlign: 'center'
    },
    btnMainStyle: { flex: 1/4, marginTop: 40 },
    btnStyle: {
        width: 111,
        height: 45,
        borderRadius: 10,
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 12,
            height: 26
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        borderStyle: "solid",
        borderWidth: 2.5,
        borderColor: "#3d3cb3",
        backgroundColor: "#fff",
    },
    btnTextStyle: {
        fontFamily: "Montserrat-Bold",
        fontSize: 15,
        fontWeight: "bold",
        fontStyle: "normal",
        letterSpacing: 0.5,
        textAlign: "left",
        color: "#3d3cb3"
    }


});

export default UnderMaintenenance;