import { createAction, createReducer } from '@reduxjs/toolkit'

export const setAppLanguage = createAction('signup/setAppLanguage');

export const appLanguageList = createAction('signup/appLanguageList');

import { getApi, putApi,getwithTokenApi } from '../../utils/apiServices';


const initialState = {
    appLanguage:[],

};

const languageAPiUrl = "language/languages";
const changelaguageApiUrl='user/change-language';
const VerifyuserApiUrl='user/verify-token';

export const getLanguageApi = async () => {

    let headers = {
        'Accept': 'application/json',
        "Content-Type": "application/json"
    };
    let resdata = await getApi(languageAPiUrl, headers,'')
        .then((response) => {
            return response;

        }).catch(function (error) {
            return error;
        });
  
    return resdata;

}
export const putLanguageApi = async (LanguageId,token) => {
    let putData = {
        "language_id": LanguageId
    };
    const config = {
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
            Authorization : `Bearer ${token}`}
    };

    let resdata = await putApi(changelaguageApiUrl, putData, config)
        .then((response) => {
            return response;

        }).catch(function (error) {
            return error;
        });
    return resdata;

}

export const getVerifyuserApi = async (mtoken) => {
    console.log("VerifyuserApiUrlToken>>",mtoken);
    const config = {
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
            Authorization : `Bearer ${mtoken}`}
    };

    let resdata = await getApi(VerifyuserApiUrl, config,'')
        .then((response) => {
            return response;

        }).catch(function (error) {
            return error;
        });
    return resdata;

}






export const onBoardingReducer = createReducer(initialState, (builder) => {
    //getLanguageApi();

    builder.addCase(appLanguageList, (state, action) => {
        state.appLanguage=action.payload.data;
         
     })
    builder.addCase(setAppLanguage, (state, action) => {
        return { ...state, ...action.payload };
    })

        .addDefaultCase((state, action) => {
            console.log('initialState=>', state, action)
            return state;
        })
})