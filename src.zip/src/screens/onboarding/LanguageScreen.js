import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from "react-native";
import { useDispatch } from "react-redux";
import OnBoardingHeader from "../../components/shared/OnBoardingHeader";
import { useSelector } from "react-redux";
import appColors from "./../../utils/appColors";
import images from "./../../utils/sharedImages";
import {
  getLanguageApi,
  setAppLanguage,
  appLanguageList,
} from "./OnBoardingReducer";
//import Loader from '../../components/Loader';

const languageData = [
  {
    id: 1,
    name: "Hindi",
    value: "hindi",
    icon: images.indiaFlag,
    code: "HI",
  },
  {
    id: 2,
    name: "English",
    value: "english",
    icon: images.englishFlag,
    code: "EN",
  },
];

const LanguageScreen = (props) => {
  let mSelect = null;
  const udata = useSelector((state) => state.applanguage);

  mSelect = udata.id;
  const [isLoading, setIsLoading] = React.useState(false);
  const [seconds, setSeconds] = React.useState(30);
  const [nextToScreen, setNextToScreen] = React.useState(false);
  const [language, setLanguage] = useState(props?.route?.params?.name);

  const dispatch = useDispatch();

  const Checklanguage = async () => {
    // setIsLoading(true);
    const reasData = await getLanguageApi();
    if (reasData && reasData.status === 200) {
      //  setIsLoading(false);

      const english = reasData.data.data.filter((item) => item.id === 1);

      dispatch(setAppLanguage(english[0]));
      await dispatch(appLanguageList(reasData.data));
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      // setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  useEffect(() => {
    dispatch(setAppLanguage(language));
    Checklanguage();
  }, [language]);

  const selectLanguage = (seletedLanguage) => {
    setLanguage(seletedLanguage);
    setNextToScreen(true);
    return;
  };

  moveToNextScreen = () => {
    if (language && Object.keys(language).length <= 0) {
      Alert.alert("Please Select Language");
    } else if (nextToScreen === false) {
      Alert.alert("Please Select Language");
    } else if (mSelect == 1 || mSelect == 2) {
      props.navigation.navigate("IntroScreenOne");
    } else {
      Alert.alert("Please Select Language");
    }
  };
  return (
    <View style={styles.container}>
      <OnBoardingHeader
        navScreen={props.navigation}
        ID={2}

        // skipInactive={true}
      />
      <View style={styles.imageContainer}>
        <Image source={images.languageGlobe} style={styles.image} />
      </View>
      <View style={styles.imageTextContainer}>
        <Text style={styles.imageTextHeading}>
          Choose Your Preferred Language{" "}
        </Text>
      </View>
      <View style={styles.imageTextContainer}>
        <Text style={styles.imageTextSubHeading}>
          Please Select Your Languge
        </Text>
      </View>
      <View style={styles.underLine} />

      {udata &&
        udata.appLanguage &&
        udata.appLanguage.length > 0 &&
        udata.appLanguage.map((item, index) => {
          let checkCode = item.code;
          if (checkCode == "hi") {
            icon = images.indiaFlag;
          } else {
            icon = images.englishFlag;
          }

          return (
            <React.Fragment key={index}>
              <TouchableOpacity onPress={() => selectLanguage(item)}>
                <View style={styles.lanuageContainer}>
                  <View style={styles.flagContainer}>
                    <Image source={icon} style={styles.imageFlag} />
                  </View>
                  <Text style={styles.flagTextContainer}>{item.name}</Text>
                  {(language && language.code === item.code && (
                    <View style={styles.outerContainer}>
                      <Image
                        source={images.OKAYFlag}
                        style={styles.imageRightFlag}
                      />
                    </View>
                  )) || <View style={styles.inActiveContainer} />}
                </View>
              </TouchableOpacity>

              <View style={styles.underLine} />
            </React.Fragment>
          );
        })}

      <View style={styles.buttonContainer}>
        <TouchableOpacity
          onPress={() => {
            moveToNextScreen();
          }}
        >
          <View style={styles.buttonAlignment}>
            <Text style={styles.buttonText}>Next</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: appColors.WHITE,
  },
  imageContainer: {
    justifyContent: "center",
    alignItems: "center",
    marginTop: 83,
    padding: 5,
  },
  image: {
    width: 72,
    height: 72,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 7,
    shadowOpacity: 1,
  },
  imageTextContainer: {
    marginLeft: 15,
    marginRight: 15,
    alignItems: "flex-start",
  },
  imageTextHeading: {
    fontFamily: "Montserrat-Bold",
    fontSize: 19,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 24.9,
    letterSpacing: 0,
    textAlign: "center",
    color: "#09051c",
  },
  imageTextSubHeading: {
    fontFamily: "Montserrat-Regular",
    fontSize: 16,
    fontWeight: "normal",
    fontStyle: "normal",
    lineHeight: 28.9,
    letterSpacing: 0,
    textAlign: "center",
    color: "#09051c",
  },
  underLine: {
    height: 1,
    opacity: 0.2,
    backgroundColor: "#000000",
    marginTop: 15,
    marginBottom: 15,
  },
  lanuageContainer: {
    alignItems: "center",
    flexDirection: "row",
    marginLeft: 15,
    marginRight: 15,
  },
  flagContainer: {
    justifyContent: "center",
    alignItems: "center",
    width: 48,
    height: 48,
    backgroundColor: "#f0f0f9",
    borderRadius: 20,
  },
  imageFlag: {
    width: 31,
    height: 31,
  },
  flagTextContainer: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 17,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 30.7,
    letterSpacing: 0,
    color: "#000000",
    width: "70%",
    marginLeft: 15,
  },
  outerContainer: {
    width: 29,
    height: 29,
    alignItems: "center",
    justifyContent: "center",
  },

  imageRightFlag: {
    width: 29,
    height: 29,
  },
  inActiveContainer: {
    width: 29,
    height: 29,
    backgroundColor: "rgba(111, 111, 111, 0.45)",
    borderRadius: 20,
  },
  buttonContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonAlignment: {
    width: 157,
    height: 57,
    borderRadius: 15,
    backgroundColor: "#3e3db4",
    alignItems: "center",
    justifyContent: "center",
  },
  buttonText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 16,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 21,
    letterSpacing: 0,
    color: "#ffffff",
  },
});

export { LanguageScreen };
