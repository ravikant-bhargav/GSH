import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    ScrollView,
} from 'react-native';
import OnBoardingHeader from '../../components/shared/OnBoardingHeader';

import appColors from './../../utils/appColors';
import images from './../../utils/sharedImages';



const IntroScreenOne = (props) => {



    return (

        <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
            <View style={styles.container}>
                <OnBoardingHeader navScreen={props.navigation} />

                <View style={styles.imageContainer}>
                    <Image
                        source={images.onBoardingScreen1}
                        style={styles.image}
                    />
                </View>
                <View style={styles.imageTextContainer}>
                    <Text style={styles.imageTextHeading}>Best app for your daily dairy products </Text>
                </View>
                <View style={styles.imageTextContainerSubHeading}>
                    <Text style={styles.imageTextSubHeading}>Here You Can find fresh milk and dairy products Enjoy!</Text>
                </View>

                <View style={styles.buttonContainer}>
                    <TouchableOpacity onPress={() => props.navigation.navigate('IntroScreenTwo')}>
                        <View style={styles.buttonAlignment}>
                            <Text style={styles.buttonText}>Next</Text>
                        </View>
                    </TouchableOpacity>
                </View>



            </View>
        </ScrollView>


    );
};

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: appColors.WHITE,
    },
    imageContainer: {
        justifyContent: 'center',
        alignItems: 'center',

    },
    image: {
        height: 396,
        resizeMode: 'cover'
    },
    imageTextContainer: {
        marginLeft: 57,
        marginRight: 57,
    },
    imageTextHeading: {
        fontFamily: "Montserrat-Bold",
        fontSize: 22,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 28.8,
        letterSpacing: 0,
        textAlign: "center",
        color: "#09051c"
    },
    imageTextContainerSubHeading: {
        marginLeft: 66,
        marginRight: 65,
        padding: 20
    },
    imageTextSubHeading: {
        fontFamily: "Montserrat-Regular",
        fontSize: 12,
        fontWeight: "normal",
        fontStyle: "normal",
        lineHeight: 21.7,
        letterSpacing: 0,
        textAlign: "center",
        color: "#09051c"
    },
    buttonContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        padding: 10

    },
    buttonAlignment: {
        width: 157,
        height: 57,
        borderRadius: 15,
        backgroundColor: "#3e3db4",
        alignItems: 'center',
        justifyContent: 'center',

    },
    buttonText: {

        fontFamily: "Montserrat-SemiBold",
        fontSize: 16,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 21,
        letterSpacing: 0,
        color: "#ffffff",


    }


});

export { IntroScreenOne };