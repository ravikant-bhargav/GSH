import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from "react-native";
import { useDispatch } from "react-redux";
import OnBoardingHeader from "../../components/shared/OnBoardingHeader";
import { useSelector } from "react-redux";
import appColors from "./../../utils/appColors";
import images from "./../../utils/sharedImages";
import {
  getLanguageApi,
  setAppLanguage,
  appLanguageList,
  putLanguageApi,
  getVerifyuserApi,
} from "../onboarding/OnBoardingReducer";
import DashboardHeader from "../../components/shared/DashboardHeader";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import Loader from "../../components/Loader";
import Dashboard from "./../dashboard/index";

export const ChangeLanguage = (props) => {
  // const [isLoading, setIsLoading] = React.useState(false);
  const [seconds, setSeconds] = React.useState(30);

  const [language, setLanguage] = useState(props?.route?.params?.name);
  const [Id, setId] = useState("");

  const dispatch = useDispatch();
  // const [token,setToken] =useState (async()=>{

  //     return await AsyncStorage.getItem(appConstant.APP_TOKEN)

  //     });
  //     console.log('Token>>',token)
  const udata = useSelector((state) => state.applanguage);

  const getuserverifyApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    //  setIsLoading(true);
    const reasData = await getVerifyuserApi(token);
    if (reasData && reasData.status === 200) {
      //  setIsLoading(false);
      // let msg = reasData?.data?.status?.message || "";
      // Alert.alert("", msg);
      setLanguage(reasData.data.data.user_language);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      //  setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  const Checklanguage = async () => {
    // setIsLoading(true);
    const reasData = await getLanguageApi();
    if (reasData && reasData.status === 200) {
      ///   setIsLoading(false);
      await dispatch(appLanguageList(reasData.data));
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      //  setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  const putLanguageChangeApi = async () => {
    //  setIsLoading(true);
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    const reasData = await putLanguageApi(Id, token);
    if (reasData && reasData.status === 200) {
      // setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      props.navigation.navigate("Dashboard");
      Alert.alert("", msg);
      await dispatch(setAppLanguage(reasData.data.data.user_language));
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      // setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  useEffect(() => {
    // loadtoken()
    Checklanguage();
    getuserverifyApi();
    // dispatch(setAppLanguage(language));
  }, []);

  const selectLanguage = (seletedLanguage) => {
    setLanguage(seletedLanguage);
    let Id = seletedLanguage.id;
    setId(Id);

    return;
  };
  moveToNextScreen = () => {
    if (Id == 1 || Id == 2) {
      putLanguageChangeApi();
    } else {
      Alert.alert("Please Select Language");
    }
  };

  return (
    <React.Fragment>
      <DashboardHeader
        showBackArrow={true}
        headerTitle={"Change Language"}
        navScreen={props.navigation}
        headerContainerStyle={{
          borderBottomColor: "rgba(0, 0, 0, 0.14)",
          borderBottomWidth: 1,
        }}
        onPress={() => {
          props.navigation.goBack();
        }}
      />
      <View>
        <View style={styles.imageTextContainer}>
          <Text style={styles.headerTextSubHeading}>
            Please Select Your Languge{" "}
          </Text>
        </View>
      </View>

      <View>
        {udata &&
          udata.appLanguage &&
          udata.appLanguage.length > 0 &&
          udata.appLanguage.map((item, index) => {
            let checkCode = item.code;
            if (checkCode == "hi") {
              icon = images.indiaFlag;
            } else {
              icon = images.englishFlag;
            }

            return (
              <React.Fragment key={index}>
                <TouchableOpacity onPress={() => selectLanguage(item)}>
                  <View style={styles.lanuageContainer}>
                    <View style={styles.flagContainer}>
                      <Image source={icon} style={styles.imageFlag} />
                    </View>
                    <Text style={styles.flagTextContainer}>{item.name}</Text>
                    {(language && language.code === item.code && (
                      <View style={styles.outerContainer}>
                        <Image
                          source={images.OKAYFlag}
                          style={styles.imageRightFlag}
                        />
                      </View>
                    )) || <View style={styles.inActiveContainer} />}
                  </View>
                </TouchableOpacity>

                <View style={styles.underLine} />
              </React.Fragment>
            );
          })}

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            onPress={() => {
              moveToNextScreen();
            }}
          >
            <View style={styles.buttonAlignment}>
              <Text style={styles.buttonText}>Change</Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: appColors.WHITE,
  },
  imageContainer: {
    justifyContent: "center",
    alignItems: "center",
    marginTop: 83,
    padding: 5,
  },
  image: {
    width: 72,
    height: 72,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 7,
    shadowOpacity: 1,
  },
  imageTextContainer: {
    marginLeft: 15,
    marginRight: 15,
    alignItems: "flex-start",
  },
  imageTextHeading: {
    fontFamily: "Montserrat-Bold",
    fontSize: 19,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 24.9,
    letterSpacing: 0,
    textAlign: "center",
    color: "#09051c",
  },
  headerTextSubHeading: {
    fontFamily: "Montserrat-Regular",
    fontSize: 16,
    fontWeight: "normal",
    fontStyle: "normal",
    letterSpacing: 0,
    marginTop: 8,
    marginLeft: 10,
    color: "#09051c",
  },
  imageTextSubHeading: {
    fontFamily: "Montserrat-Regular",
    fontSize: 16,
    fontWeight: "normal",
    fontStyle: "normal",
    lineHeight: 28.9,
    letterSpacing: 0,
    textAlign: "center",
    color: "#09051c",
  },
  underLine: {
    height: 1,
    opacity: 0.2,
    backgroundColor: "#000000",
    marginTop: 15,
    marginBottom: 15,
  },
  lanuageContainer: {
    alignItems: "center",
    flexDirection: "row",
    marginLeft: 15,
    marginRight: 15,
    marginTop: 20,
  },
  flagContainer: {
    justifyContent: "center",
    alignItems: "center",
    width: 48,
    height: 48,
    backgroundColor: "#f0f0f9",
    borderRadius: 20,
  },
  imageFlag: {
    width: 31,
    height: 31,
  },
  flagTextContainer: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 17,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 30.7,
    letterSpacing: 0,
    color: "#000000",
    width: "70%",
    marginLeft: 15,
  },
  TextContainer: {
    alignItems: "left",
    justifyContent: "left",
    marginTop: 15,
    marginBottom: 15,
    marginLeft: 10,
    marginRight: 10,
  },

  outerContainer: {
    width: 29,
    height: 29,
    alignItems: "center",
    justifyContent: "center",
  },

  imageRightFlag: {
    width: 29,
    height: 29,
  },
  inActiveContainer: {
    width: 29,
    height: 29,
    backgroundColor: "rgba(111, 111, 111, 0.45)",
    borderRadius: 20,
  },
  buttonContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonAlignment: {
    width: 157,
    height: 57,
    borderRadius: 15,
    backgroundColor: "#3e3db4",
    alignItems: "center",
    justifyContent: "center",
  },
  buttonText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 16,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 21,
    letterSpacing: 0,
    color: "#ffffff",
  },
});
