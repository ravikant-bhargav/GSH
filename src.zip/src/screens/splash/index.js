
import React, { useRef, useEffect } from 'react';

import {
    SafeAreaView,
    Image,
    Text,
    View,
    StyleSheet,
    Dimensions,
    Animated,
    ImageBackground
} from 'react-native';

import { CommonActions } from '@react-navigation/native';
import images from '../../utils/sharedImages';
import AsyncStorage from '@react-native-async-storage/async-storage';
import appConstant from '../../utils/appConstant';
import { useSelector } from 'react-redux';
import { getData } from '../../utils/AsyncStorage';


const SplashScreen = (props) => {

    const udata = useSelector(state => state.auth);

    console.log('udata', udata);

    const moveAnim = useRef(new Animated.Value(0)).current;
    const fadeAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.sequence([
            Animated.timing(moveAnim, {
                duration: 2000,
                toValue: Dimensions.get('window').width / 2,
                delay: 0,
                useNativeDriver: false,
            }),
            Animated.timing(moveAnim, {
                duration: 2000,
                toValue: 0,
                delay: 0,
                useNativeDriver: false,
            }),
        ]).start();
        Animated.timing(fadeAnim, {
            duration: 2000,
            toValue: 1,
            delay: 1500,
            useNativeDriver: false,
        }).start();


        setTimeout(async () => {
            let uTokne = await AsyncStorage.getItem(appConstant.APP_TOKEN);
          

            if (uTokne && uTokne !== null) {
                props.navigation.replace('CustomDrawer');
            } else {
                props.navigation.replace('OnBoardingStack');
            }


        }, 6000)

    }, [moveAnim, fadeAnim]);

    return (

        <ImageBackground source={images.SplashScreen} resizeMode="cover" style={styles.container}>
            <View style={styles.contentContainer}>
                {/* <Animated.Image
           style={[styles.image, { opacity: fadeAnim }]}
           source={require('./src/assets/images/logo.png')}
         /> */}

                <Animated.View style={[styles.logoContainer, { marginLeft: moveAnim }]}>
                    <Animated.Image
                        style={[styles.image, { opacity: fadeAnim }]}
                        source={require('../../assets/images/innerLogo.png')}
                    />



                    {/* <Animated.Image
             style={[styles.image, { opacity: fadeAnim}]}
             source={require('./src/assets/images/textLogo.png')}
           />   */}
                    {/* <Image
             style={[styles.image, { marginLeft: -100 }]}
             source={require('./src/assets/images/textLogo.png')}
           /> */}

                </Animated.View>

                <Animated.Image
                    style={[styles.image, { opacity: fadeAnim, marginTop: -94 }]}
                    source={require('./../../assets/images/textLogo.png')}
                />

            </View>
        </ImageBackground>

    );
};

export const styles = StyleSheet.create({
    container: {
        display: 'flex',
        flex: 1,
        justifyContent: "center",
        // backgroundColor: "transparent",
    },

    contentContainer: {
        // top: '40%',
        alignItems: 'center',
    },
    image: {
        width: 100,
        height: 100,
    },
    logoContainer: {
        flexDirection: 'row',

    },
});

export default SplashScreen;
