/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React from 'react';
import {

  StyleSheet,

  Text,
} from 'react-native';


import Animated, { Extrapolate } from 'react-native-reanimated';
import {
  DrawerItem,
  createDrawerNavigator,
  DrawerContentScrollView,
  useDrawerProgress
} from '@react-navigation/drawer';

const DrawerScreen1 = ({ drawerAnimationStyle }) => {
  

  const progress = useDrawerProgress();
console.log('progress',progress)
  const scale = Animated.interpolateNode(progress.value, {
    inputRange: [0, 1],
    outputRange: [1,0.8],
    //extrapolate: Extrapolate.CLAMP,
  });
  const borderRadius = Animated.interpolateNode(progress.value, {
    inputRange: [0, 1],
    outputRange: [0, 25],
   // extrapolate: Extrapolate.CLAMP,
  });

  const animatedStyle = {
    borderRadius,
    transform: [{ scale }],
    //overflow: 'hidden',
  };
  return (
    <Animated.View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
       // backgroundColor: "white",
       
      }}>

      <Text>Main Layout</Text>
    </Animated.View>
  );
};



export default DrawerScreen1;