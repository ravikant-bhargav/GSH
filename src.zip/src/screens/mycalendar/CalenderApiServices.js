// /v1/api/order/getCalenderOrderList/302016?startDate=2022-09-01&endDate=2022-09-10

import { getApi } from '../../utils/apiServices';
import {getData} from "../../utils/AsyncStorage";
import appConstant from "../../utils/appConstant";

const subscription = "order/getCalenderOrderList/";

export const calenderApiForSubscription = async (token, offset, startDate, endDate) => {
    let putData = {
        "page": offset,
        "per_page":10
    };
    const config = {
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
            Authorization : `Bearer ${token}`}
    };

    console.log(startDate)

    let urlIs = subscription + await getData(appConstant.Zip_code) + '?startDate=' + startDate + (endDate !== null ? '&endDate=' + endDate : '');

    console.log(urlIs)
    console.log(token)

    let resdata = await getApi(urlIs, config,putData)
        .then((response) => {
            return response;

        }).catch(function (error) {
            return error;
        });
    return resdata;

};
