import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  Modal,
  Dimensions,
} from "react-native";

import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";

import moment from "moment";

import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import DashboardHeader from "../../components/shared/DashboardHeader";
import PrimaryButtonResize from "../../components/button/PrimaryButtonResize";
import AppCalendar from "../../components/calendar/AppCalendar";
import HorizontalLine from "../../components/HorizontalLine";
import CalendarStripView from "../../components/calendar/CalendarStrip";
import PaymentFooter from "../../components/PaymentFooter";
import AddToCartFooter from "../product/AddToCartFooter";
import ActionSheetDialog from "../../components/ActionSheetDialog";
import ActionSheet, { SheetManager } from "react-native-actions-sheet";
import { BottomTabBar } from "@react-navigation/bottom-tabs";
import TabBarNavigation from "../../navigation/TabBarNavigation";

import {
  getAllDaysInMonth,
  getNumberOfDaysInTheMonth,
  monthDropDown,
  yearDropDown,
} from "../../utils/getNumberOfDays";

import RNPickerSelect from "react-native-picker-select";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { getsubssrcriptionOngoingApi } from "../mysubscription/SubscriptionApiService";
import appConstant from "../../utils/appConstant";
import { calenderApiForSubscription } from "./CalenderApiServices";

const windowHeight = Dimensions.get("window").height;

const placeholderMonth = {
  label: "Month",
  value: null,
  fontFamily: "Montserrat-Medium",
  fontSize: 12,
  fontWeight: "500",
  fontStyle: "normal",
  lineHeight: 13.1,
  letterSpacing: 0,
  textAlign: "left",
  color: "#000000",
};

const placeholderYear = {
  label: "Year",
  value: null,
  fontFamily: "Montserrat-Medium",
  fontSize: 12,
  fontWeight: "500",
  fontStyle: "normal",
  lineHeight: 13.1,
  letterSpacing: 0,
  textAlign: "left",
  color: "#000000",
};

const MyCalendar = (props) => {
  const [modalVisible, setModalVisible] = React.useState(false);
  const [modalDateVisible, setMoveDateModal] = React.useState(false);
  const [dateList, setDateList] = React.useState([]);

  const [isLoading, setIsLoading] = React.useState(false);

  // const [month, setMonth] = React.useState(moment().format("mmm"));
  const [rows, setRows] = React.useState([]);
  //
  const [month, setMonth] = React.useState(new Date().getMonth());
  const [year, setYear] = React.useState(new Date().getFullYear());

  const navigateToScreen = () => {
    props.navigation.goBack();
  };
  const actionSheetRef = useRef(null);
  const openActionSheet = () => {
    SheetManager.show("test_sheet_id", { text: "Hello World" });
  };

  useEffect(() => {
    let firstDay = moment(new Date()).format("YYYY/MM/DD");
    getCalenderData(firstDay);
    // emptyCalendar(DATA)
    // setupInitialRange()
  }, []);

  useEffect(() => {}, [month, year, dateList]);

  const setMonthAndYear = () => {
    setModalVisible(false);
    let firstDay = moment(new Date(year, month, 1)).format("YYYY/MM/DD");
    getCalenderData(firstDay);
  };

  const getCalenderData = async (firstDay) => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await calenderApiForSubscription(token, 1, "2022-11-03", null);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let data =
        reasData &&
        reasData.data &&
        reasData.data.data &&
        reasData.data.data.rows;
      console.log(">>>>>>>>>>", reasData.data);
      emptyCalendar(data);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
    }
  };

  const Item = (item) => {
    console.log("ITEM??????????", item);

    return (
      <View key={item.id} style={[styles.showAllContainer, { flex: 1 }]}>
        <View style={{ flexDirection: "row", padding: 10 }}>
          <View style={{ width: "20%", alignItems: "center" }}>
            <View style={styles.dayContainer}>
              <Text style={styles.dayNumber}>
                {item &&
                  item.delivery_date &&
                  item.delivery_date.split("-", 3)[2]}
              </Text>
              {item && item.day && (
                <Text style={styles.dayName}>{item.day}</Text>
              )}
            </View>
          </View>

          <View style={{ width: "80%", flexDirection: "column" }}>
            {item && item.itemDetails.length > 0 ? (
              item &&
              item.itemDetails &&
              item.itemDetails.map((itemm, index) => {
                return (
                  <View
                    key={index}
                    style={[
                      styles.subscriptionContainer,
                      {
                        backgroundColor:
                          itemm &&
                          itemm.order_type &&
                          itemm.order_type === "ONE_TIME_ORDERS"
                            ? "#eab50a"
                            : "#64a1fd",
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.subscriptionName,
                        {
                          color:
                            itemm &&
                            itemm.order_type &&
                            itemm.order_type === "ONE_TIME_ORDERS"
                              ? "#5d5959"
                              : "#ffffff",
                        },
                      ]}
                    >
                      {itemm.product_name +
                        (itemm &&
                        itemm.order_type &&
                        itemm.order_type === "ONE_TIME_ORDERS"
                          ? " (One-time)"
                          : " (Subscription)")}
                    </Text>
                    <TouchableOpacity
                      style={styles.subscriptionButton}
                      onPress={
                        //    () => setMoveDateModal(true)
                        () => {
                          let id = itemm.order_id;
                          props.navigation.navigate("OrderDetailspage", id);
                        }
                      }
                    >
                      <Text style={styles.subscriptionButtonText}>View </Text>
                    </TouchableOpacity>
                  </View>
                );
              })
            ) : (
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <View
                  style={{ width: 40, height: 1, backgroundColor: "#000000" }}
                />
                <Text> No Scheduled orders for this day </Text>
                <View
                  style={{ width: 40, height: 1, backgroundColor: "#000000" }}
                />
              </View>
            )}

            <View style={{ alignItems: "flex-end" }}>
              <PrimaryButtonResize
                onPress={() =>
                  props.navigation.navigate("CategoryProduct", {
                    screenCalendar: "calendarScreen",
                    delivery_date: item.delivery_date,
                  })
                }
                btnCustomStyle={styles.btnStyle}
                btnText={"Add"}
              />
            </View>
            <HorizontalLine />
          </View>
        </View>
      </View>
    );
  };

  const emptyCalendar = (data) => {
    let newDta = [];
    let theOriginalData = [];
    let getAllDays = getAllDaysInMonth(month, year);

    getAllDays.map((item1, idx) => {
      let dateObject = {
        itemDetails: [],
        id: "",
        day: "",
        delivery_date: "",
      };

      let newFilteredData = data.filter((item) => {
        let deliveryDate = moment(item.delivery_date).format("YYYY-MM-DD");
        let calendarDate = moment(item1).format("YYYY-MM-DD");

        return moment(deliveryDate).isSame(calendarDate);
      });

      dateObject.itemDetails = newFilteredData;
      dateObject.id = moment(item1)
        .format("DD/MM/YYYY")
        .split("/")[0]
        .toString();
      dateObject.day = moment(item1).format("ddd");
      dateObject.delivery_date = moment(item1).format("YYYY-MM-DD");

      newDta.push(dateObject);
    });

    theOriginalData.push(...newDta);

    setDateList(theOriginalData);
  };

  return (
    <React.Fragment>
      <DashboardHeader
        showBackArrow={true}
        headerTitle={"Calendar"}
        headerTitle1={moment(month + 1, "M").format("MMMM")}
        dropDownIcon={true}
        dropDownIconPress={() => {
          setModalVisible(true);
        }}
        navScreen={props.navigation}
        headerContainerStyle={{
          borderBottomColor: "rgba(0, 0, 0, 0.14)",
          borderBottomWidth: 1,
        }}
        onPress={() => navigateToScreen()}
      />
      <MiddleContentWrapper navigation={props.navigation} {...props}>
        <FlatList
          data={dateList}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => Item(item)}
          keyExtractor={(item) => item.id.toString()}
        />

        {/* Set Month Modal PopUp */}
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            setModalVisible(!modalVisible);
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <TouchableOpacity
                style={{ alignSelf: "flex-end", marginRight: 20 }}
                onPress={() => setModalVisible(false)}
              >
                <Text>Close</Text>
              </TouchableOpacity>

              <View style={{ flexDirection: "row" }}>
                <View
                  style={[styles.deliveryTimeCOntainer, { marginLeft: 10 }]}
                >
                  <Text style={[styles.deliveryHeading, { paddingBottom: 9 }]}>
                    Month
                  </Text>
                  <RNPickerSelect
                    placeholder={placeholderMonth}
                    items={monthDropDown}
                    onValueChange={(value) => setMonth(value)}
                    style={{
                      ...pickerSelectStyles,
                      iconContainer: {
                        alignItems: "center",
                        justifyContent: "center",
                        height: "100%",
                      },
                    }}
                    value={month}
                    useNativeAndroidPickerStyle={false}
                    textInputProps={{
                      fontFamily: "Montserrat-Medium",
                      fontWeight: "500",
                      fontStyle: "normal",
                      letterSpacing: 0,
                      textAlign: "left",
                      color: "#000000",
                      fontSize: 13,
                      lineHeight: 13.1,
                      paddingRight: 3,
                      paddingLeft: 5,
                    }}
                    Icon={() => {
                      return (
                        <Image
                          source={images.sortDownIcon}
                          style={{
                            width: 16,
                            height: 16,
                            alignSelf: "center",
                            marginRight: 4,
                          }}
                        />
                      );
                    }}
                  />
                </View>

                <View
                  style={[styles.deliveryTimeCOntainer, { marginLeft: 10 }]}
                >
                  <Text style={[styles.deliveryHeading, { paddingBottom: 9 }]}>
                    Year
                  </Text>
                  <RNPickerSelect
                    placeholder={placeholderYear}
                    items={yearDropDown}
                    onValueChange={(value) => setYear(value)}
                    style={{
                      ...pickerSelectStyles,
                      iconContainer: {
                        alignItems: "center",
                        justifyContent: "center",
                        height: "100%",
                      },
                    }}
                    value={year}
                    useNativeAndroidPickerStyle={false}
                    textInputProps={{
                      fontFamily: "Montserrat-Medium",
                      fontWeight: "500",
                      fontStyle: "normal",
                      letterSpacing: 0,
                      textAlign: "left",
                      color: "#000000",
                      fontSize: 13,
                      lineHeight: 13.1,
                      paddingRight: 3,
                      paddingLeft: 5,
                    }}
                    Icon={() => {
                      return (
                        <Image
                          source={images.sortDownIcon}
                          style={{
                            width: 16,
                            height: 16,
                            alignSelf: "center",
                            marginRight: 4,
                          }}
                        />
                      );
                    }}
                  />
                  {/* <View style={[styles.inputBoxContainer]}>
                                            <View style={{ flex: 1, justifyContent: 'center' }}>
                                                <Text style={[styles.dateText, {
                                                    fontSize: 12,
                                                    lineHeight: 13.1,
                                                    paddingRight: 3,
                                                    paddingLeft: 5,
                                                }]}>1 Liter</Text>
                                            </View>
                                            <Image source={images.sortDownIcon} style={{ width: 16, height: 16, alignSelf: 'center', marginRight: 4 }} />
                                        </View> */}
                </View>
              </View>

              <PrimaryButtonResize
                onPress={() => setMonthAndYear()}
                btnCustomStyle={[styles.btnStyle, { marginTop: 20 }]}
                btnText={"Submit"}
              />
            </View>
          </View>
        </Modal>

        {/* Move Order To Date */}
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalDateVisible}
          onRequestClose={() => {
            setMoveDateModal(!modalDateVisible);
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.setMovedateModal}>
              <TouchableOpacity onPress={() => setMoveDateModal(false)}>
                <Text style={{ textAlign: "right" }}>Close</Text>
              </TouchableOpacity>

              <Text
                style={{
                  fontFamily: "Montserrat-Bold",
                  fontSize: 14,
                  fontWeight: "bold",
                  fontStyle: "normal",
                  lineHeight: 15.3,
                  letterSpacing: 0,
                  textAlign: "left",
                  color: "#332a55",
                }}
              >
                Move to another date
              </Text>
            </View>
          </View>
        </Modal>
      </MiddleContentWrapper>

      <TabBarNavigation
        navigation={props.navigation}
        isRouteActive={true}
        routeIndex={0}
        {...props}
      />
    </React.Fragment>
  );
};

const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    width: "100%",
    height: 26,
    borderRadius: 3,
    borderStyle: "solid",
    borderWidth: 1.5,
    borderColor: "#3d3cb3",
  },
  inputAndroid: {
    width: "100%",
    height: 26,
    borderRadius: 3,
    borderStyle: "solid",
    borderWidth: 1.5,
    borderColor: "#3d3cb3",
    flexDirection: "row",
    justifyContent: "center",
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
});

export const styles = StyleSheet.create({
  showAllContainer: {
    flex: 1,
  },
  dayContainer: {
    flexDirection: "column",
    width: 44,
    height: 44,
    backgroundColor: "#ffffff",
    borderRadius: 100,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
    elevation: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  dayNumber: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 13,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 14,
    letterSpacing: 0,
    textAlign: "left",
    color: "#585858",
  },
  dayName: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 12,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 14,
    letterSpacing: 0,
    textAlign: "left",
    color: "#3d3cb3",
  },
  subscriptionContainer: {
    height: 27,
    borderRadius: 8,
    backgroundColor: "#64a1fd",
    shadowColor: "rgba(159, 159, 159, 0.25)",
    shadowOffset: {
      width: 0,
      height: 44,
    },
    shadowRadius: 92,
    shadowOpacity: 1,
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: 10,
    paddingRight: 10,
    width: "100%",
    marginBottom: 6,
  },
  subscriptionName: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 11,
    fontWeight: "600",
    fontStyle: "normal",
    letterSpacing: 0,
    textAlign: "left",
    color: "#ffffff",
    width: "80%",
  },
  subscriptionButton: {
    width: "20%",
  },
  subscriptionButtonText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 11,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0,
    textAlign: "right",
    color: "#3d3cb3",
  },
  btnStyle: {
    width: 87,
    height: 27,
    borderRadius: 8,
    backgroundColor: "#3d3cb3",
    shadowColor: "rgba(159, 159, 159, 0.25)",
    shadowOffset: {
      width: 0,
      height: 44,
    },
    shadowRadius: 92,
    shadowOpacity: 1,
    elevation: 10,
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0,0.4)",
    height: "50%",
  },

  modalView: {
    borderRadius: 20,
    padding: 10,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    backgroundColor: "#fff",
    width: "92%",
  },
  setMovedateModal: {
    height: 117,
    borderRadius: 9,
    backgroundColor: "#ffffff",
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 8,
    shadowOpacity: 1,
    width: "92%",
    padding: 10,
    elevation: 5,
  },

  deliveryTimeCOntainer: {
    width: "45%",
    flexDirection: "column",
  },
  deliveryHeading: {
    fontFamily: "Montserrat-Bold",
    fontSize: 13,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 14.2,
    letterSpacing: 0,
    textAlign: "left",
    color: "#000000",
  },
});

export default MyCalendar;
