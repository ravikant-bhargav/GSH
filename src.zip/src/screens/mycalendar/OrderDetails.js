import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
} from 'react-native';

import appColors from '../../utils/appColors';
import images from '../../utils/sharedImages';
import LinearGradient from 'react-native-linear-gradient';


import MiddleContentWrapper from '../../components/contentWrapper/MiddleContentWrapper';
import DashboardHeader from '../../components/shared/DashboardHeader';
import TabBarNavigation from '../../navigation/TabBarNavigation';
import PrimaryButtonResize from '../../components/button/PrimaryButtonResize';
import SubscriptionProductCard from '../../components/SubscriptionProductCard';
import HorizontalLine from '../../components/HorizontalLine';

import DashedLine from 'react-native-dashed-line';
import PaymentFooter from '../../components/PaymentFooter';








const OrderDetails = (props) => {


    const navigateToScreen = () => {
        props.navigation.goBack();
    }



    return (
        <React.Fragment>
            <DashboardHeader
                showBackArrow={true}
                headerTitle={"Order"}
                headerTitle1={"Details"}
                navScreen={props.navigation}
                headerContainerStyle={{
                    borderBottomColor: "rgba(0, 0, 0, 0.14)",
                    borderBottomWidth: 1,
                }}
                onPress={() => navigateToScreen()}
            />
            <MiddleContentWrapper navigation={props.navigation} {...props} style={{ paddingBottom: 75 }} >



                <View style={[styles.showAllContainer, {}]}>
                    <Text style={styles.headingTitle}>Order ID: #144</Text>
                    <View style={styles.orderStatusContainer}>

                        <View style={{ flexDirection: 'row', paddingLeft: 10, paddingRight: 10, paddingBottom: 10 }}>
                            <View style={{ flexDirection: 'column', alignItems: 'center', width: "18%", marginTop: 22 }}>
                                <Image source={images.CheckProductStatusIcon} style={{ width: 30, height: 30, resizeMode: 'cover' }} />
                                <Text style={[styles.statusText, {}]}>Order </Text>
                                <Text style={[styles.statusText, {}]}>confirmed</Text>
                            </View>
                            <View style={{ width: "23%", justifyContent: 'center' }}>
                                <DashedLine
                                    dashLength={8}
                                    dashThickness={3}
                                    dashGap={5}
                                    dashColor='#3d3cb3'
                                    dashStyle={{ borderRadius: 5 }}
                                />
                            </View>

                            <View style={{ flexDirection: 'column', alignItems: 'center', width: "18%", marginTop: 22 }}>
                                <View style={{ width: 28, height: 28, backgroundColor: "rgba(61, 60, 179, 0.2)", borderRadius: 20 }} />
                                <Text style={[styles.statusText1, {}]}>Order </Text>
                                <Text style={[styles.statusText1, {}]}>Picked up</Text>
                            </View>
                            <View style={{ width: "23%", justifyContent: 'center' }}>
                                <DashedLine
                                    dashLength={8}
                                    dashThickness={3}
                                    dashGap={5}
                                    dashColor='#3d3cb3'
                                    dashStyle={{ borderRadius: 5 }}
                                />
                            </View>
                            <View style={{ flexDirection: 'column', alignItems: 'center', width: "18%", marginTop: 22 }}>
                                <View style={{ width: 28, height: 28, backgroundColor: "rgba(61, 60, 179, 0.2)", borderRadius: 20 }} />
                                <Text style={[styles.statusText1, {}]}>Order </Text>
                                <Text style={[styles.statusText1, {}]}>Delivered</Text>
                            </View>
                        </View>
                        <View style={{ flexDirection: 'row', marginTop: 15, paddingLeft: 20, paddingRight: 20, alignItems: 'center' }}>
                            <Image source={images.locationIcon} style={{ width: 38, height: 38, resizeMode: 'cover' }} />
                            <View style={{ flexDirection: 'column', paddingLeft: 6, paddingRight: 20, }}>
                                <Text style={{
                                    opacity: 0.8,
                                    fontFamily: "Montserrat-ExtraBold",
                                    fontSize: 8,
                                    fontWeight: "800",
                                    fontStyle: "normal",
                                    letterSpacing: 0.5,
                                    color: "#3d3cb3",

                                }}>Delivery Location</Text>
                                <Text style={{
                                    opacity: 0.8,
                                    fontFamily: "Montserrat-SemiBold",
                                    fontSize: 12,
                                    fontWeight: "600",
                                    fontStyle: "normal",
                                    letterSpacing: 0.5,
                                    color: "#101010"
                                }}>25-B Civil Lines, New Delhi </Text>
                            </View>
                        </View>

                        <View style={{ flexDirection: 'row', marginTop: 15, paddingLeft: 20, paddingRight: 20, alignItems: 'center', width: "100%" }}>
                            <View style={{ flexDirection: 'row', width: "50%", padding: 6 }}>
                                <Image source={images.CalendarStatusIcon} style={{ width: 26, height: 26, resizeMode: 'cover' }} />
                                <View style={{ flexDirection: 'column', paddingLeft: 6, paddingRight: 20, }}>
                                    <Text style={{
                                        opacity: 0.8,
                                        fontFamily: "Montserrat-ExtraBold",
                                        fontSize: 8,
                                        fontWeight: "800",
                                        fontStyle: "normal",
                                        letterSpacing: 0.5,
                                        color: "#3d3cb3",

                                    }}>Order Date</Text>
                                    <Text style={{
                                        opacity: 0.8,
                                        fontFamily: "Montserrat-SemiBold",
                                        fontSize: 12,
                                        fontWeight: "600",
                                        fontStyle: "normal",
                                        letterSpacing: 0.5,
                                        color: "#101010"
                                    }}>Wednesday, <Text>6 March 2022</Text>  </Text>
                                </View>
                            </View>
                            <View style={{ flexDirection: 'row', width: "50%", padding: 6 }}>
                                <Image source={images.TimeStatusIcon} style={{ width: 26, height: 26, resizeMode: 'cover' }} />
                                <View style={{ flexDirection: 'column', paddingLeft: 6, paddingRight: 20, }}>
                                    <Text style={{
                                        opacity: 0.8,
                                        fontFamily: "Montserrat-ExtraBold",
                                        fontSize: 8,
                                        fontWeight: "800",
                                        fontStyle: "normal",
                                        letterSpacing: 0.5,
                                        color: "#3d3cb3",

                                    }}>Delivery Time</Text>
                                    <Text style={{
                                        opacity: 0.8,
                                        fontFamily: "Montserrat-SemiBold",
                                        fontSize: 12,
                                        fontWeight: "600",
                                        fontStyle: "normal",
                                        letterSpacing: 0.5,
                                        color: "#101010"
                                    }}>10 am - 11 am </Text>
                                </View>
                            </View>
                        </View>


                    </View>

                    <HorizontalLine />
                    <View style={styles.productContainer}>
                        <SubscriptionProductCard />
                        <SubscriptionProductCard />
                    </View>
                    <View style={{ justifyContent: 'center', alignItems: 'center', marginTop: 20 }}>
                        <PrimaryButtonResize
                            showImage={false}
                            btnText={"Re-Schedule"}
                            btnCustomStyle={{
                                width: 133,
                                borderRadius: 8,
                                borderStyle: "solid",
                                borderWidth: 2.5,
                                borderColor: "#3d3cb3",
                                backgroundColor: "transparent",
                            }}

                            btnTextStyle={{
                                fontFamily: "Montserrat-Bold",
                                fontSize: 14,
                                fontWeight: "bold",
                                fontStyle: "normal",
                                lineHeight: 15.3,
                                letterSpacing: 0,
                                color: "#3d3cb3"
                            }}
                            onPress={() => console.log('ho')}

                        />
                    </View>

                </View>

            </MiddleContentWrapper>

            <PaymentFooter
                text="Total Order Amount"
                amount="1500"
                customStyleAmount={{ color: "#201f9b" }}
            />

        </React.Fragment>


    );
};

export const styles = StyleSheet.create({

    showAllContainer: {
        padding: 15
    },
    headingTitle: {
        fontFamily: "Montserrat-Bold",
        fontSize: 12,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 15.7,
        letterSpacing: 0,
        textAlign: "left",
        color: "#09051c"
    },
    orderStatusContainer: {
        height: 218,
        backgroundColor: "#ffffff",
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        borderRadius: 20,
        marginTop: 10,
        marginBottom: 10

    },
    statusTextDiv: {
        width: "33.3%",
        borderColor: 'green',
        borderWidth: 1,


    },
    statusText: {
        opacity: 0.8,
        fontFamily: "Montserrat-ExtraBold",
        fontSize: 10,
        fontWeight: "800",
        fontStyle: "normal",
        letterSpacing: 0.5,
        //textAlign: "left",
        color: "#000000",

    },
    statusText1: {
        opacity: 0.8,
        fontFamily: "Montserrat-ExtraBold",
        fontSize: 10,
        fontWeight: "800",
        fontStyle: "normal",
        letterSpacing: 0.5,
        //textAlign: "left",
        color: "#56504f"
    },


    productContainer: {
        flex: 1,
        width: "100%",
        borderRadius: 13,
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        //marginTop: 5
    },



});

export default OrderDetails;