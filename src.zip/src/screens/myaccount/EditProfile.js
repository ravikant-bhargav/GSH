import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  Alert,
  PermissionsAndroid,
} from "react-native";
import { launchCamera, launchImageLibrary } from "react-native-image-picker";
import DashboardHeader from "../../components/shared/DashboardHeader";
import appColors from "./../../utils/appColors";
import images from "./../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";
import MiddleContent from "../signup/MiddleContent";
import Loader from "../../components/Loader";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import {
  putupdateProfile,
  getprofileApi,
} from "../myaccount/ProfileApiService";
import appConstants from "../../utils/appConstant";

const EditProfile = (props) => {
  const options = {
    title: "Select Avatar",
    storageOptions: true,
    path: "images",
    mediaType: "photo",
    waitUntilSaved: true,
  };

  const [name, onChangeName] = useState("");
  const [number, onChangeNumber] = useState("");
  const [email, onChangeEmail] = useState("");
  const [address, onChangeAddress] = useState(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const [profileInfo, setprofileInfo] = useState("");
  const [isPermitted, setIsPermitted] = useState(false);
  const [captureImages, setCaptureImages] = useState([]);
  const [avatar, setAvatar] = useState(null);
  const [url, seturl] = useState(null);
  const navigateToScreen = () => {
    props.navigation.goBack();
  };
  // validateEmail = (email) => {
  //     var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  //       return re.test(email);
  //   };
  const checkTextInput = () => {
    //Check for the Name TextInput
    if (!name.trim()) {
      Alert("Please Enter Name");
      return;
    }
    //Check for the Email TextInput
    if (!email.trim()) {
      Alert("Please Enter Email");
      return;
    }
    //Checked Successfully
    //Do whatever you want
    Alert("Success");
  };
  useEffect(() => {
    GetProfileApi();
  }, []);
  console.log("profileInfo>>", profileInfo);

  ////get Profile Info/////////////////////////////////////////////////
  const GetProfileApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getprofileApi(token);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      // Alert.alert("", msg);
      if (reasData.data.count <= 0) {
        Alert.alert("", "No data found");
      } else {
        ///  await AsyncStorage.setItem(appConstant.CARD_ID,reasData.data.cart_uuid );
        //   props.navigation.navigate("AddToCart")
      }
      setprofileInfo(reasData.data.data);
      onChangeName(reasData.data.data.name);
      onChangeEmail(reasData.data.data.email);
      if (reasData.data.data.profile_picture !== null) {
        setAvatar({ uri: reasData.data.data.profile_picture });
      }
      ///  console.log('Response>>>>',reasData)
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  console.log(">>>>>>>>>>>>>outside", avatar, url);
  //////// update profile Api/////////////////////////////////////////////////////
  const updateProfileApi = async (name, email) => {
    console.log(">>>>>", name, email);
    if (name === "" || null || undefined) {
      Alert.alert("Please enter name");
      return;
    } else if (email === "" || null || undefined) {
      Alert.alert("Please enter Email");
    } else {
      let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
      setIsLoading(true);
      let path;
      console.log(">>>>>>>>>>>>>inside", avatar, url);
      if (avatar !== null) {
        path = Platform.OS === "ios" ? `file://${url}` : url;
      }

      const formData = new FormData();
      formData.append("token", token);
      formData.append("name", name);
      formData.append("email", email);
      if (url !== null) {
        var getFileName1 = url.split("/");
        var fileName = getFileName1[getFileName1.length - 1];

        formData.append("profile_picture", {
          uri: path,
          type: "image/jpeg",
          name: fileName,
        });
      }
      // const reasData = await putupdateProfile(token, name, email);
      const reasData = await putupdateProfile(formData, token);
      if (reasData && reasData.status === 200) {
        setIsLoading(false);
        let msg = reasData?.data?.status?.message || "";
        console.log("????????RESPONSE", reasData.data);
        // await AsyncStorage.setItem(
        //   appConstants.PROFILEIMAGE,
        //   reasData.data.data.profile_picture
        // );
        await AsyncStorage.setItem(appConstant.NAME, name);
        await AsyncStorage.setItem(appConstant.EMAIL, email);
        Alert.alert("", msg);
        props.navigation.push("MyProfile");
      } else if (
        reasData &&
        (reasData.err_status === 400 || reasData.err_status === 404)
      ) {
        setIsLoading(false);
        Alert.alert("", reasData?.err_message?.status?.message);
      }
    }
  };

  // const avatarImageURL = avatar !== null

  const selectImage = () => {
    Alert.alert("GSH", "Profile Image", [
      {
        text: "Camera",
        onPress: () => requestCamera(),
      },
      {
        text: "Open Mobile Gallery",
        onPress: () =>
          launchImageLibrary(options, (res) => {
            if (!res.didCancel) {
              setAvatar({ uri: res.assets[0].uri });
              seturl(res.assets[0].uri);
            }
          }),
      },
    ]);
  };

  const requestCamera = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
        {
          title: "App Camera Permission",
          message: "App need to access your camera",
          buttonNeutral: "Ask me later",
          buttonPositive: "Ok",
          buttonNegative: "Cancel",
        }
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        console.log("Camera allowed");
        launchCamera(options, (res) => {
          console.log("Camera allowed>>>>", res);
          if (!res.didCancel) {
            console.log("CameraINSIDDE", res);
            setAvatar({ uri: res.assets[0].uri });
            seturl(res.assets[0].uri);
          }
        });
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <React.Fragment>
      <Loader isLoading={isLoading} />
      <View style={styles.container}>
        <LinearGradient
          colors={["#3d3cb3", "rgba(61, 60, 179, 0.73)"]}
          style={styles.containerHeader}
        >
          <View style={styles.mainContainer}>
            <View style={styles.leftIconContainer}>
              <TouchableOpacity
                onPress={() => {
                  props.navigation.goBack();
                }}
              >
                <Image
                  source={images.BackArrowWhite}
                  style={styles.leftIconImage}
                />
              </TouchableOpacity>
            </View>
            <Text style={styles.middleTextStyle}>Edit Profile</Text>
          </View>
        </LinearGradient>
        <View></View>
        <View style={styles.imageContainer}>
          <View style={styles.imageInnerContainer}>
            {avatar !== null ? (
              <Image source={avatar} style={styles.image} />
            ) : (
              <Image source={images.ProfileIcon} style={styles.image} />
            )}
          </View>
        </View>
        <View style={styles.middleContent}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={styles.middleContentWrapper}>
              <View
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: 20,
                  marginBottom: 0,
                }}
              >
                <View style={{ flexDirection: "row", marginTop: 10 }}>
                  <TouchableOpacity
                    style={{ flexDirection: "row", marginTop: 10 }}
                    onPress={selectImage}
                  >
                    <Image
                      source={images.pencilEditIcon}
                      style={{ width: 23, height: 23, resizeMode: "cover" }}
                    />
                    <Text
                      style={{
                        fontFamily: "Montserrat-SemiBold",
                        fontSize: 15,
                        fontWeight: "600",
                        fontStyle: "normal",
                        lineHeight: 20.6,
                        letterSpacing: 0,
                        color: "#3d3cb3",
                        paddingLeft: 8,
                      }}
                    >
                      Upload Image
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>

            <View style={{ flex: 1 }}>
              <View
                style={{
                  flexDirection: "column",
                  marginLeft: 8,
                  marginRight: 8,
                }}
              >
                <View>
                  <Text style={styles.formTextHeading}>Name</Text>
                  <View style={{ marginTop: 10 }}>
                    <TextInput
                      style={styles.formTextInput}
                      keyboardType="default"
                      onChangeText={onChangeName}
                      value={name}
                      // placeholder={profileInfo.name}
                      placeholderTextColor={"#2c2c2d"}
                    />
                  </View>
                </View>

                <View>
                  <Text style={styles.formTextHeading}>Email</Text>
                  <View style={{ marginTop: 10 }}>
                    <TextInput
                      style={styles.formTextInput}
                      keyboardType="email-address"
                      onChangeText={onChangeEmail}
                      value={email}
                      // placeholder={profileInfo.email}
                      placeholderTextColor={"#2c2c2d"}
                    />
                  </View>
                </View>

                <TouchableOpacity
                  style={{ marginTop: 15 }}
                  onPress={() => {
                    updateProfileApi(name, email);
                  }}
                >
                  <LinearGradient
                    colors={["#3d3cb3", "rgba(61, 60, 179, 0.73)"]}
                    style={styles.formButtonLinear}
                  >
                    <Text style={styles.linerButtonText}>Update</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </View>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  container: { flex: 1 },
  containerHeader: {
    height: 178,
  },
  mainContainer: {
    flexDirection: "row",
    height: 120,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  leftIconContainer: {
    left: 15,
    position: "absolute",
    width: "20%",
    height: 60,
    justifyContent: "center",
  },
  leftIconImage: {
    width: 43,
    height: 43,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
  },
  middleTextStyle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 22,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 24.1,
    letterSpacing: 0,
    textAlign: "right",
    color: "#ffffff",
    alignItems: "center",
  },
  imageContainer: {
    position: "absolute",
    zIndex: 1,
    alignSelf: "center",
    justifyContent: "center",
    flex: 1,
    top: 80,
    width: 120,
    height: 120,
    backgroundColor: "grey",
  },
  imageInnerContainer: {
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
  },
  image: {
    width: 110,
    height: 110,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 7,
    shadowOpacity: 1,
    resizeMode: "cover",
  },

  middleContent: {
    flex: 1,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor: appColors.WHITE,
    shadowColor: "rgba(0, 0, 0, 0.62)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
    marginTop: -20,
  },
  middleContentWrapper: {
    marginTop: 10,
    padding: 25,
    flex: 1,
  },
  header: {
    backgroundColor: "#3d3cb3",
    height: 170,
  },
  avatar: {
    width: 130,
    height: 130,
    borderRadius: 63,
    borderWidth: 4,
    borderColor: "white",
    marginBottom: 10,
    alignSelf: "center",
    position: "absolute",
    marginTop: 50,
  },

  formContainer: {
    marginLeft: 18,
    marginRight: 15,
  },
  formTextHeading: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 22,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 28.8,
    letterSpacing: 0,
    color: "#2c2c2d",
  },
  formTextInput: {
    height: 60,
    borderRadius: 12,
    borderStyle: "solid",
    borderWidth: 2.5,
    borderColor: "rgb(61, 60, 179)",
    padding: 18,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0.75,
    color: "#2c2c2d",
  },
  formButtonLinear: {
    height: 45,
    borderRadius: 10,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  linerButtonText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#ffffff",
  },

  lineContainer: {
    marginTop: 30,
    marginBottom: 30,
    flexDirection: "row",
    justifyContent: "center",
    alignContent: "center",
    alignItems: "center",
  },

  lineSeprator: {
    width: 129,
    height: 1.5,
    opacity: 0.5,
    backgroundColor: "#000000",
  },
  lineText: {
    opacity: 0.5,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 13,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 21.6,
    letterSpacing: 0,
    textAlign: "center",
    color: "rgba(9, 5, 28, 0.64)",
    marginLeft: 15,
    marginRight: 15,
  },

  buttonContainer: {
    // flex: 1,
    justifyContent: "center",
    height: 51,
    borderRadius: 12,
    borderStyle: "solid",
    borderWidth: 2,
    borderColor: "rgb(61, 60, 179)",
    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
  },

  buttonAlignment: {
    backgroundColor: "#ffffff",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    // padding:10
  },
  buttonText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    textAlign: "left",
    color: "rgb(61, 60, 179)",
  },
  buttonContainerWithColor: {
    // flex: 1,
    justifyContent: "center",
    height: 51,
    borderRadius: 12,
    borderStyle: "solid",

    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
    backgroundColor: "#1877f2",
  },
  buttonAlignmentWithColor: {
    backgroundColor: "#1877f2",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  buttonTextWithColor: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    //  textAlign: "left",
    color: "#ffffff",
  },
  imageButton: {
    width: 28.3,
    height: 29,
    borderRadius: 5,
    shadowColor: "rgba(0, 0, 0, 0.09)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
    marginRight: 15,
  },
});

export default EditProfile;
