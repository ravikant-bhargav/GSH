import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  Alert,
} from "react-native";

import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";
import MiddleContent from "../signup/MiddleContent";
import HorizontalLine from "../../components/HorizontalLine";
import Loader from "../../components/Loader";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import {
  putupdateProfile,
  getprofileApi,
} from "../myaccount/ProfileApiService";
import { EditAddress, getAddresslist } from "../myaddress/AddressService";
import { useDispatch } from "react-redux";
import { resetAuthUser } from "../../screens/signup/AuthReducer";

const STATUS_BAR_HEIGHT = Platform.OS === "ios" ? 20 : StatusBar.currentHeight;

const languageData = [
  {
    id: 1,
    name: "Hindi",
    value: "hindi",
    icon: images.indiaFlag,
  },
  {
    id: 2,
    name: "English",
    value: "english",
    icon: images.englishFlag,
  },
];

const MyProfile = (props) => {
  const dispatch = useDispatch();
  let userDetails = {};
  const [language, setLanguage] = useState("hindi");
  const [profileimage, setprofileimage] = useState();
  const [profileInfo, setprofileInfo] = useState("");
  const [isLoading, setIsLoading] = React.useState(false);
  const [avatar, setAvatar] = useState(null);
  const [url, seturl] = useState(null);
  const selectLanguage = (seletedLanguage) => {
    setLanguage(seletedLanguage);
    return;
  };
  ////get Profile Info/////////////////////////////////////////////////
  const GetProfileApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    ///  setIsLoading(true);
    const reasData = await getprofileApi(token);
    if (reasData && reasData.status === 200) {
      // setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      // Alert.alert("", msg);
      if (reasData.data.count <= 0) {
        Alert.alert("", "No data found");
      } else {
      }
      setprofileInfo(reasData.data.data);
      if (reasData.data.data.profile_picture !== null) {
        setAvatar({ uri: reasData.data.data.profile_picture });
      }
      if (reasData.data.data.profile_picture == null) {
        ///  console.log('variable is NOT null');
        // setprofileimage(images.ProfileAvatarIcon)
      } else {
        setprofileimage(reasData.data.data.profile_picture);
      }
      if (reasData.data.data.name == null || reasData.data.data.name == "") {
        await AsyncStorage.setItem(appConstant.NAME, "");
      } else {
        await AsyncStorage.setItem(
          appConstant.NAME,
          "" + reasData.data.data.name.toString()
        );
      }

      if (reasData.data.data.email == null || reasData.data.data.email == "") {
        await AsyncStorage.setItem(appConstant.EMAIL, "");
      } else {
        await AsyncStorage.setItem(
          appConstant.EMAIL,
          "" + reasData.data.data.email.toString()
        );
      }

      ///  console.log('Response>>>>',reasData)
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      // setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  const getaddrressValue = (value) => {
    let strshipping_address_id = value.id;
    let strbilling_address_id = value.id;

    let straddress_type = value.address_type;
    let strcity = value.city;
    let strlandmark = value.landmark;
    let strstate = value.state;
    let strstreet_address = value.street_address;
    let strzip_code = value.zip_code;
    var setdefault = true;
    let ID = value.id;
    editAddressApi(
      ID,
      straddress_type,
      strstreet_address,
      strcity,
      strlandmark,
      strstate,
      strzip_code,
      setdefault
    );
  };

  const editAddressApi = async (
    ID,
    straddress_type,
    strstreet_address,
    strcity,
    strlandmark,
    strstate,
    strzip_code,
    setdefault
  ) => {
    setIsLoading(true);
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    let phone = await AsyncStorage.getItem(appConstant.PHONENUMBER);
    const reasData = await EditAddress(
      token,
      ID,
      phone,
      straddress_type,
      strstreet_address,
      strcity,
      strlandmark,
      strstate,
      strzip_code,
      setdefault
    );
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      getsddresslistApi();
      // setLocalDB(strshipping_address_id,strbilling_address_id,
      //     straddress_type,strcity,strlandmark,strstate,strstreet_address,strzip_code);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  const getsddresslistApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getAddresslist(token, 1);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);

      for (i = 0; i < reasData.data.data.length; i++) {
        if (reasData.data.data[i].is_default == true) {
          await AsyncStorage.setItem(
            appConstant.Shipping_address_id,
            "" + reasData.data.data[i].id.toString()
          );
          await AsyncStorage.setItem(
            appConstant.Billing_address_id,
            "" + reasData.data.data[i].id.toString()
          );
          await AsyncStorage.setItem(
            appConstant.Address_type,
            reasData.data.data[i].address_type
          );

          await AsyncStorage.setItem(
            appConstant.City,
            reasData.data.data[i].city
          );
          await AsyncStorage.setItem(
            appConstant.Landmark,
            reasData.data.data[i].landmark
          );
          await AsyncStorage.setItem(
            appConstant.State,
            reasData.data.data[i].state
          );
          await AsyncStorage.setItem(
            appConstant.Street_address,
            reasData.data.data[i].street
          );
          await AsyncStorage.setItem(
            appConstant.Zip_code,
            "" + reasData.data.data[i].zipcode.toString()
          );
        }
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };

  const logOut = async () => {
    Alert.alert("Are you sure?", " You want to logout ?", [
      {
        text: "Cancel",
        onPress: () => console.log("Cancel Pressed"),
        style: "cancel",
      },
      {
        text: "OK",
        onPress: async () => {
          await AsyncStorage.removeItem(appConstant.APP_TOKEN);
          await AsyncStorage.removeItem(appConstant.EMAIL);
          await AsyncStorage.removeItem(appConstant.PHONENUMBER);
          await AsyncStorage.removeItem(appConstant.PROFILEIMAGE);
          await AsyncStorage.removeItem(appConstant.NAME);
          await AsyncStorage.removeItem(appConstant.Billing_address_id);
          await AsyncStorage.removeItem(appConstant.Shipping_address_id);
          await AsyncStorage.removeItem(appConstant.Address_type);
          await AsyncStorage.removeItem(appConstant.City);
          await AsyncStorage.removeItem(appConstant.Landmark);
          await AsyncStorage.removeItem(appConstant.State);
          await AsyncStorage.removeItem(appConstant.Street_address);
          await AsyncStorage.removeItem(appConstant.Zip_code);

          //  props.navigation.navigate("SplashScreen");
          dispatch(resetAuthUser());
          props.navigation.replace("OnBoardingStack");
        },
      },
    ]);
  };

  useEffect(() => {
    GetProfileApi();
  }, []);

  return (
    <React.Fragment>
      <View style={styles.container}>
        <LinearGradient
          colors={["#3d3cb3", "rgba(61, 60, 179, 0.73)"]}
          style={styles.containerHeader}
        >
          <View style={styles.mainContainer}>
            <View style={styles.leftIconContainer}>
              <TouchableOpacity
                onPress={() => {
                  props.navigation.goBack();
                }}
              >
                <Image
                  source={images.BackArrowWhite}
                  style={styles.leftIconImage}
                />
              </TouchableOpacity>
            </View>
            <Text style={styles.middleTextStyle}>My Profile</Text>
          </View>
        </LinearGradient>

        <View style={styles.imageContainer}>
          <View style={styles.imageInnerContainer}>
            {avatar !== null ? (
              <Image source={avatar} style={styles.image} />
            ) : (
              <Image source={images.ProfileIcon} style={styles.image} />
            )}
            {/* <Image source={images.ProfileAvatarIcon} style={styles.image} /> */}
          </View>
        </View>
        <View style={styles.middleContent}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={styles.middleContentWrapper}>
              <View
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: 20,
                  marginBottom: 0,
                }}
              >
                <Text
                  style={{
                    fontFamily: "Montserrat-Bold",
                    fontSize: 24,
                    fontWeight: "bold",
                    fontStyle: "normal",
                    lineHeight: 32.9,
                    letterSpacing: 0,
                    color: "#3b3b3b",
                  }}
                >
                  {profileInfo.name}
                </Text>
                <Text
                  style={{
                    fontFamily: "Montserrat-Medium",
                    fontSize: 17,
                    fontWeight: "500",
                    fontStyle: "normal",
                    lineHeight: 23.3,
                    letterSpacing: 0,
                    color: "#3b3b3b",
                  }}
                >
                  {profileInfo.phone_number}
                </Text>

                <View style={{ flexDirection: "row", marginTop: 10 }}>
                  <TouchableOpacity
                    style={{ flexDirection: "row", marginTop: 10 }}
                    onPress={() => {
                      props.navigation.navigate("EditProfile");
                    }}
                  >
                    <Image
                      source={images.pencilEditIcon}
                      style={{ width: 23, height: 23, resizeMode: "cover" }}
                    />
                    <Text
                      style={{
                        fontFamily: "Montserrat-SemiBold",
                        fontSize: 15,
                        fontWeight: "600",
                        fontStyle: "normal",
                        lineHeight: 20.6,
                        letterSpacing: 0,
                        color: "#3d3cb3",
                        paddingLeft: 8,
                      }}
                    >
                      Edit Profile
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>

            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: "column" }}>
                <View
                  style={{
                    width: "100%",
                    padding: 10,
                    alignItems: "center",
                    borderColor: "rgba(0, 0, 0, 0.14)",
                    borderWidth: 0.6,
                    borderLeftWidth: 0,
                    borderRightWidth: 0,
                  }}
                >
                  <TouchableOpacity
                    style={{
                      width: "100%",
                      height: 44,
                      borderRadius: 12,
                      flexDirection: "row",
                      alignItems: "center",
                      paddingLeft: 10,
                    }}
                    onPress={() => {
                      props.navigation.navigate("MySubscription");
                    }}
                  >
                    <View
                      style={{
                        width: "90%",
                        alignItems: "center",
                        flexDirection: "row",
                      }}
                    >
                      <Image
                        source={images.MypSubscriptionIcon}
                        style={{ width: 30, height: 30, resizeMode: "cover" }}
                      />
                      <Text
                        style={{
                          fontFamily: "Montserrat-Bold",
                          fontSize: 17,
                          fontWeight: "bold",
                          fontStyle: "normal",
                          lineHeight: 18.6,
                          letterSpacing: 0,
                          textAlign: "right",
                          color: "#3d3cb3",
                          marginLeft: 18,
                        }}
                      >
                        Subscriptions
                      </Text>
                    </View>
                    <View style={{ width: "10%" }}>
                      <Image
                        source={images.MypRightArrowIcon}
                        style={{
                          width: 14,
                          height: 14,
                          resizeMode: "cover",
                        }}
                      />
                    </View>
                  </TouchableOpacity>
                </View>
                <View
                  style={{
                    width: "100%",
                    padding: 10,
                    alignItems: "center",
                    borderColor: "rgba(0, 0, 0, 0.14)",
                    borderWidth: 0.6,
                    borderLeftWidth: 0,
                    borderRightWidth: 0,
                  }}
                >
                  <TouchableOpacity
                    style={{
                      width: "100%",
                      height: 44,
                      borderRadius: 12,
                      flexDirection: "row",
                      alignItems: "center",
                      paddingLeft: 10,
                    }}
                    onPress={() => {
                      props.navigation.navigate("MyOrders");
                    }}
                  >
                    <View
                      style={{
                        width: "90%",
                        alignItems: "center",
                        flexDirection: "row",
                      }}
                    >
                      <Image
                        source={images.MypOrderHistoryIcon}
                        style={{ width: 30, height: 30, resizeMode: "cover" }}
                      />
                      <Text
                        style={{
                          fontFamily: "Montserrat-Bold",
                          fontSize: 17,
                          fontWeight: "bold",
                          fontStyle: "normal",
                          lineHeight: 18.6,
                          letterSpacing: 0,
                          textAlign: "right",
                          color: "#3d3cb3",
                          marginLeft: 18,
                        }}
                      >
                        My Orders
                      </Text>
                    </View>
                    <View style={{ width: "10%" }}>
                      <Image
                        source={images.MypRightArrowIcon}
                        style={{
                          width: 14,
                          height: 14,
                          resizeMode: "cover",
                          textAlign: "right",
                        }}
                      />
                    </View>
                  </TouchableOpacity>
                </View>
                <View
                  style={{
                    width: "100%",
                    padding: 10,
                    alignItems: "center",
                    borderColor: "rgba(0, 0, 0, 0.14)",
                    borderWidth: 0.6,
                    borderLeftWidth: 0,
                    borderRightWidth: 0,
                  }}
                >
                  <TouchableOpacity
                    style={{
                      width: "100%",
                      height: 44,
                      borderRadius: 12,
                      flexDirection: "row",
                      alignItems: "center",
                      paddingLeft: 10,
                    }}
                    onPress={() => {
                      props.navigation.navigate("Wiselistpage");
                    }}
                  >
                    <View
                      style={{
                        width: "90%",
                        alignItems: "center",
                        flexDirection: "row",
                      }}
                    >
                      <Image
                        source={images.MypOrderHistoryIcon}
                        style={{ width: 30, height: 30, resizeMode: "cover" }}
                      />
                      <Text
                        style={{
                          fontFamily: "Montserrat-Bold",
                          fontSize: 17,
                          fontWeight: "bold",
                          fontStyle: "normal",
                          lineHeight: 18.6,
                          letterSpacing: 0,
                          textAlign: "right",
                          color: "#3d3cb3",
                          marginLeft: 18,
                        }}
                      >
                        List
                      </Text>
                    </View>
                    <View style={{ width: "10%" }}>
                      <Image
                        source={images.MypRightArrowIcon}
                        style={{
                          width: 14,
                          height: 14,
                          resizeMode: "cover",
                          textAlign: "right",
                        }}
                      />
                    </View>
                  </TouchableOpacity>
                </View>
                <View
                  style={{
                    width: "100%",
                    padding: 10,
                    alignItems: "center",
                    borderColor: "rgba(0, 0, 0, 0.14)",
                    borderWidth: 0.6,
                    borderLeftWidth: 0,
                    borderRightWidth: 0,
                  }}
                >
                  <TouchableOpacity
                    style={{
                      width: "100%",
                      height: 44,
                      borderRadius: 12,
                      flexDirection: "row",
                      alignItems: "center",
                      paddingLeft: 10,
                    }}
                    onPress={() => {
                      props.navigation.navigate("MyAddress", {
                        onGoBack: (e) => getaddrressValue(e),
                      });
                    }}
                  >
                    <View
                      style={{
                        width: "90%",
                        alignItems: "center",
                        flexDirection: "row",
                      }}
                    >
                      <Image
                        source={images.MypAddressIcon}
                        style={{ width: 30, height: 30, resizeMode: "cover" }}
                      />
                      <Text
                        style={{
                          fontFamily: "Montserrat-Bold",
                          fontSize: 17,
                          fontWeight: "bold",
                          fontStyle: "normal",
                          lineHeight: 18.6,
                          letterSpacing: 0,
                          textAlign: "right",
                          color: "#3d3cb3",
                          marginLeft: 18,
                        }}
                      >
                        Addresses
                      </Text>
                    </View>
                    <View style={{ width: "10%" }}>
                      <Image
                        source={images.MypRightArrowIcon}
                        style={{
                          width: 14,
                          height: 14,
                          resizeMode: "cover",
                          textAlign: "right",
                        }}
                      />
                    </View>
                  </TouchableOpacity>
                </View>
                <View
                  style={{
                    width: "100%",
                    padding: 10,
                    alignItems: "center",
                    borderColor: "rgba(0, 0, 0, 0.14)",
                    borderWidth: 0.6,
                    borderLeftWidth: 0,
                    borderRightWidth: 0,
                  }}
                >
                  <TouchableOpacity
                    style={{
                      width: "100%",
                      height: 44,
                      borderRadius: 12,
                      flexDirection: "row",
                      alignItems: "center",
                      paddingLeft: 10,
                    }}
                  >
                    <View
                      style={{
                        width: "90%",
                        alignItems: "center",
                        flexDirection: "row",
                      }}
                    >
                      <Image
                        source={images.MypInfoIcon}
                        style={{ width: 30, height: 30, resizeMode: "cover" }}
                      />
                      <Text
                        style={{
                          fontFamily: "Montserrat-Bold",
                          fontSize: 17,
                          fontWeight: "bold",
                          fontStyle: "normal",
                          lineHeight: 18.6,
                          letterSpacing: 0,
                          textAlign: "right",
                          color: "#3d3cb3",
                          marginLeft: 18,
                        }}
                      >
                        FAQ
                      </Text>
                    </View>
                    <View style={{ width: "10%" }}>
                      <Image
                        source={images.MypRightArrowIcon}
                        style={{
                          width: 14,
                          height: 14,
                          resizeMode: "cover",
                          textAlign: "right",
                        }}
                      />
                    </View>
                  </TouchableOpacity>
                </View>
                <View
                  style={{
                    width: "100%",
                    padding: 10,
                    alignItems: "center",
                    borderColor: "rgba(0, 0, 0, 0.14)",
                    borderWidth: 0.6,
                    borderLeftWidth: 0,
                    borderRightWidth: 0,
                  }}
                >
                  <TouchableOpacity
                    style={{
                      width: "100%",
                      height: 44,
                      borderRadius: 12,
                      flexDirection: "row",
                      alignItems: "center",
                      paddingLeft: 10,
                    }}
                    onPress={() => {
                      logOut();
                    }}
                  >
                    <View
                      style={{
                        width: "90%",
                        alignItems: "center",
                        flexDirection: "row",
                      }}
                    >
                      <Image
                        source={images.MypLogoutIcon}
                        style={{ width: 30, height: 30, resizeMode: "cover" }}
                      />
                      <Text
                        style={{
                          fontFamily: "Montserrat-Bold",
                          fontSize: 17,
                          fontWeight: "bold",
                          fontStyle: "normal",
                          lineHeight: 18.6,
                          letterSpacing: 0,
                          textAlign: "right",
                          color: "#3d3cb3",
                          marginLeft: 18,
                        }}
                      >
                        Logout
                      </Text>
                    </View>
                    <View style={{ width: "10%" }}>
                      <Image
                        source={images.MypRightArrowIcon}
                        style={{
                          width: 14,
                          height: 14,
                          resizeMode: "cover",
                          textAlign: "right",
                        }}
                      />
                    </View>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </ScrollView>
        </View>
      </View>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  container: { flex: 1 },
  containerHeader: {
    height: 178,
  },
  mainContainer: {
    flexDirection: "row",
    height: 120,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    // top: 5,
  },
  leftIconContainer: {
    left: 15,
    position: "absolute",
    width: "20%",
    height: 60,
    justifyContent: "center",
  },
  leftIconImage: {
    width: 43,
    height: 43,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
  },
  middleTextStyle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 22,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 24.1,
    letterSpacing: 0,
    textAlign: "right",
    color: "#ffffff",
    alignItems: "center",
  },
  imageContainer: {
    position: "absolute",
    zIndex: 1,
    alignSelf: "center",
    justifyContent: "center",
    flex: 1,
    top: 80,
    width: 150,
    height: 150,
  },
  imageInnerContainer: {
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
  },
  image: {
    width: 103,
    height: 103,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    backgroundColor: "grey",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 7,
    shadowOpacity: 1,
    resizeMode: "cover",
  },

  middleContent: {
    flex: 1,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor: appColors.WHITE,
    shadowColor: "rgba(0, 0, 0, 0.62)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    shadowOpacity: 1,
    marginTop: -20,
  },
  middleContentWrapper: {
    marginTop: 10,
    padding: 25,
    flex: 1,
  },
});

export default MyProfile;
