import { putApi, getApi } from "../../utils/apiServices";

const updateProfileUrl = "user/update-profile";
const ProfileDataUrl = "user/user-profile";

////////////GetProfile Info APi
export const getprofileApi = async (token) => {
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  };

  let resdata = await getApi(ProfileDataUrl, config, "", false)
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  //  console.log('get>>',resdata,ProfileDataUrl, config,'',false)
  return resdata;
};

/////Update Profile Api
///piUrl, postData,header
export const putupdateProfile = async (data, token) => {
  // let data = new FormData()
  // data.append('name',name)
  // data.append('email', email)
  //console.log(data)
  const config = {
    headers: {
      Accept: "application/json",
      "Content-Type": "multipart/form-data",
      Authorization: `Bearer ${token}`,
    },
  };

  let resdata = await putApi(updateProfileUrl, data, config, false)
    .then((response) => {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  // console.log('UpdateProfile>>',resdata,updateProfileUrl,data,config)
  return resdata;
};
