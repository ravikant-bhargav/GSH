import { getApi } from '../../utils/apiServices';

const subscriptionOngoingAPiUrl = "order/myOrders/SUBSCRIPTION/ONGOING?";
const subscriptionHistoryAPiUrl = "order/myOrders/SUBSCRIPTION/HISTORY?";
export const getsubssrcriptionOngoingApi = async (token,offset) => {
    let putData = {
        "page": offset,
        "per_page":10
    };
    const config = {
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
            Authorization : `Bearer ${token}`}
    };

        let resdata = await getApi(subscriptionOngoingAPiUrl, config,putData)
            .then((response) => {
                return response;
    
            }).catch(function (error) {
                return error;
            });
        // console.log('BillpaymentService>>>',resdata)
        return resdata;
    
    }
    export const getsubssrcriptionHistoryApi = async (token,offset) => {
        let putData = {
            "page": offset,
            "per_page":10
        };
        const config = {
            headers: {
                'Accept': 'application/json',
                "Content-Type": "application/json",
                Authorization : `Bearer ${token}`}
        };
    
            let resdata = await getApi(subscriptionHistoryAPiUrl, config,putData)
                .then((response) => {
                    return response;
        
                }).catch(function (error) {
                    return error;
                });
            // console.log('BillpaymentService>>>',resdata)
            return resdata;
        
        }
