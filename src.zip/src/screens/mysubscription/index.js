import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
    Alert,
} from 'react-native';

import appColors from '../../utils/appColors';
import images from '../../utils/sharedImages';
import LinearGradient from 'react-native-linear-gradient';
import { AppButton } from '../../components/button/AppButton';

import MiddleContentWrapper from '../../components/contentWrapper/MiddleContentWrapper';
import CalendarCardView from '../../components/calendar/CalendarCardView';
import OrderStatusLabels from '../../components/OrderStatusLabels';
import AmountAdjustment from '../../components/AmountAdjustment';
import HorizontalLine from '../../components/HorizontalLine';

import DashboardHeader from '../../components/shared/DashboardHeader';
import PrimaryButton from '../../components/button/PrimaryButton';
import LinearGradientView from '../../components/LinearGradientView';
import ProductCard from '../orderlist/ProductCard';
import TabBarNavigation from '../../navigation/TabBarNavigation';
import PrimaryButtonResize from '../../components/button/PrimaryButtonResize';
import OrderActive from './OrderActive';
import OrderHistory from './OrderHistory';
import AsyncStorage from '@react-native-async-storage/async-storage';
import appConstant from '../../utils/appConstant';
import { getsubssrcriptionOngoingApi,getsubssrcriptionHistoryApi} from './../mysubscription/SubscriptionApiService';
import Loader from '../../components/Loader';


const buttonList = [
    {
        name: 'Active',
        value: 'active',
        isActive: true
    },
    {
        name: 'History',
        value: 'history',
        isActive: false
    },
]




const MySubscription = (props) => {

    const [isLoading, setIsLoading] = React.useState(false);
    const [SubscriptionActive, setSubscriptionActive] = useState([])
    const [SubscriptionHistory, setSubscriptionHistory] = useState([])
    const [orderType, setOrderType] = useState('active')
    const [shouldShowNodata, setshouldShowNodata] = React.useState(false);
    const navigateToScreen = () => {
        props.navigation.goBack();
    }

    const getOrders = (order_type) => {
        console.log('order_type', order_type)
        buttonList.map((item, index) => {
            item.isActive = false;
            if (item.value === order_type) {
                item.isActive = true;
            }
            return item;
        })

        setOrderType(order_type)
    }
    const getsubcriptionactiveApi = async () => {
        let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
        setIsLoading(true);
        const reasData = await getsubssrcriptionOngoingApi(token,1);;
        if (reasData && reasData.status === 200) {
            setIsLoading(false);

            if(reasData.data.count==0){
                setshouldShowNodata(true)
            }else{
                setshouldShowNodata(false)
                setSubscriptionActive(reasData.data.data);
            }
      
         

            console.log('subscription>>',reasData)
         
        }else if (reasData && (reasData.err_status === 400 || reasData.err_status === 404)) {
           setIsLoading(false);
            Alert.alert("", reasData?.err_message?.status?.message);
        }

    }
    const getsubcriptionhistoryApi = async () => {
        let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
        setIsLoading(true);
        const reasData = await getsubssrcriptionOngoingApi(token,1);;
        if (reasData && reasData.status === 200) {
            setIsLoading(false);
            if(reasData.data.count==0){
                setshouldShowNodata(true)
            }else{
                setshouldShowNodata(false)
                
            setSubscriptionHistory(reasData.data.data);
            }
      
            console.log('subscriptionHIStory>>',reasData)
         
        }else if (reasData && (reasData.err_status === 400 || reasData.err_status === 404)) {
           setIsLoading(false);
            Alert.alert("", reasData?.err_message?.status?.message);
        }

    }

    useEffect(() => {
        getsubcriptionactiveApi()
        getsubcriptionhistoryApi()
    }, [])

    return (
        <React.Fragment>
            <DashboardHeader
                showBackArrow={true}
                headerTitle={"My Subscriptions"}
                navScreen={props.navigation}
                headerContainerStyle={{
                    borderBottomColor: "rgba(0, 0, 0, 0.14)",
                    borderBottomWidth: 1,
                }}
                onPress={() => navigateToScreen()}
            />
            <MiddleContentWrapper navigation={props.navigation} {...props} >


                <View style={[styles.showAllContainer, {}]}>
                    <View style={styles.buttonContainer}>

                        {buttonList && buttonList.length > 0 && buttonList.map((c_item, c_index) => {
                            let bgColor = c_item.isActive === true ? "#3d3cb3" : "#f6f6f6";
                            let txtColor = c_item.isActive === true ? "#ffffff" : "#3d3cb3";

                            return (
                                <React.Fragment key={c_index}>
                                    <PrimaryButtonResize
                                        btnText={c_item.name}
                                        btnCustomStyle={[styles.buttonCustomStyle, { backgroundColor: bgColor }]}
                                        btnTextStyle={[styles.buttonTextStyle, { color: txtColor }]}
                                        onPress={() => { getOrders(c_item.value) }}
                                    />
                                </React.Fragment>
                            )
                        })}

                    </View>

                    <View style={styles.productContainer}>
                        {orderType && orderType === 'history' ?
                            <OrderHistory
                            nav={SubscriptionHistory} /> :
                            <OrderActive
                            nav={SubscriptionActive} /> || null
                        }
                    </View>
                    {shouldShowNodata ? (
                        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                            <View style={{ marginLeft: 30, marginRight: 30, }}>
                                <Text style={styles.headingContainer1}>No Data found</Text>
                            </View>
                            <Image source={images.noOrderFound} style={{ marginTop: 30 }} />
                            
                        </View>
                        
                        
                    ) : null}

                </View>

            </MiddleContentWrapper>
            <TabBarNavigation
                navigation={props.navigation}
                {...props}
            />
        </React.Fragment>


    );
};

export const styles = StyleSheet.create({

    showAllContainer: {
        paddingLeft: 15,
        paddingRight: 15,

    },
    buttonContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: 15,
        paddingBottom: 21
    },
    buttonCustomStyle: {
        width: 109,
        height: 33,
        borderRadius: 58,
        borderStyle: "solid",
        borderWidth: 2,

    },
    buttonTextStyle: {
        fontFamily: "Montserrat-Bold",
        fontSize: 15,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 16.4,
        letterSpacing: 0,

    },


    productContainer: {
        flex: 1,
        width: "100%",
        borderRadius: 13,
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        //marginTop: 5
    },
    productSubContainer: {
        borderRadius: 13,
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        marginTop: 10,
        backgroundColor: "#fff",
        paddingLeft: 10,
        paddingRight: 10
    },
    productInnerContainer: {
        flexDirection: 'row',
        marginBottom: 5,

    },
    productDetailContainer: {
        width: "70%",
        height: "100%",
        //padding: 10
    },
    productAmountContainer: {
        width: "30%",

    },
    productNameText: {
        fontFamily: "Montserrat-SemiBold",

        fontSize: 15,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 19.7,
        letterSpacing: 0,
        textAlign: "left",
        color: "#09051c"
    },
    productStatus: {
        width: 83,
        height: 18,
        borderRadius: 16,
        backgroundColor: "#64a1fd",
        justifyContent: 'center',
        alignItems: 'center'
    },
    productStatusText: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 11,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 12,
        letterSpacing: 0,
        // textAlign: "left",
        color: "#413f3f"
    },
    productPlanTypeText: {
        fontFamily: "Montserrat-Bold",

        fontSize: 16,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 21,
        letterSpacing: 0,
        textAlign: "left",
        color: "#2b2b2b"
    },


    productAmountButton: {
        width: 98,
        height: 31.3,
        borderRadius: 6,
        backgroundColor: "#3d3cb3",
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 12,
            height: 26
        },
        shadowRadius: 50,
        shadowOpacity: 1,
        justifyContent: 'center',
        alignItems: 'center'

    },
    productButtonText: {
        alignSelf: 'center',
        fontFamily: "Montserrat-Bold",
        fontSize: 12,
        fontWeight: "bold",
        fontStyle: "normal",
        letterSpacing: 0.5,
        // textAlign: "left",
        color: "#f5f5f6"

    }


});

export default MySubscription;