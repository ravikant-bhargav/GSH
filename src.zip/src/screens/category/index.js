import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
    Alert,
} from 'react-native';

import appColors from '../../utils/appColors';
import images from '../../utils/sharedImages';
import LinearGradient from 'react-native-linear-gradient';
import { AppButton } from '../../components/button/AppButton';

import MiddleContentWrapper from '../../components/contentWrapper/MiddleContentWrapper';
import CalendarCardView from '../../components/calendar/CalendarCardView';
import OrderStatusLabels from '../../components/OrderStatusLabels';
import AmountAdjustment from '../../components/AmountAdjustment';
import HorizontalLine from '../../components/HorizontalLine';

import DashboardHeader from '../../components/shared/DashboardHeader';
import PrimaryButton from '../../components/button/PrimaryButton';
import LinearGradientView from '../../components/LinearGradientView';
import AsyncStorage from '@react-native-async-storage/async-storage';
import appConstant from '../../utils/appConstant';
import Loader from '../../components/Loader';
import { getCatagoryApi} from './catagoryApiCall';
// const categoryData = [
//     {
//         name: "Eggs",
//         image: images.EggCategory,
//         categoryColor: "rgba(255, 210, 28, 0.47)"
//     },
//     {
//         name: "Dairy",
//         image: images.DairyCategory,
//         categoryColor: "#457dd2"
//     },
//     {
//         name: "Milk",
//         image: images.MilkCategory,
//         categoryColor: "#cbb2fe"
//     },
//     {
//         name: "Oils",
//         image: images.Oil1Category,
//         categoryColor: "#fec89a"
//     },
//     {
//         name: "Pulses",
//         image: images.PulsesCategory,
//         categoryColor: "#5fdad8"
//     },
//     {
//         name: "Ghee",
//         image: images.GheeCategory,
//         categoryColor: "#44b3de"
//     },
//     {
//         name: "Spices",
//         image: images.SpicesCategory,
//         categoryColor: "#5d95ea"
//     },
//     {
//         name: "Breads",
//         image: images.BreadCategory,
//         categoryColor: "#58cffd"
//     },
// ];

const colours = ['#F5FFFA','#F5FFFA','#F5FFFA','#F5FFFA','#F5FFFA','#F5FFFA','#F5FFFA','#F5FFFA','#C4C4C4','#C4C4C4','#C4C4C4','#ffffff','#ffffff','#ffffff'];

const Category = (props) => {
    const [isLoading, setIsLoading] = React.useState(false);
   const [catagory, setcatagory] = useState([])
    const [offset, setOffset] = useState(1);

    
    const getCatagorymethodApi = async () => {
        let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
        setIsLoading(true);
        const reasData = await getCatagoryApi(token,offset);;
        if (reasData && reasData.status === 200) {
            setIsLoading(false);
            // let msg = reasData?.data?.status?.message || "";
            // Alert.alert("", msg);
            setcatagory(reasData.data.data);
            setOffset(offset + 1);
            //Increasing the offset for the next API call
          ///  setDataSource([...dataSource, ...responseJson.results]);

        }else if (reasData && (reasData.err_status === 400 || reasData.err_status === 404)) {
            setIsLoading(false);
            Alert.alert("", reasData?.err_message?.status?.message);
        }

    }
      
    useEffect(() => {
        getCatagorymethodApi()
    }, [])

   
    const navigateToScreen = () => {
        props.navigation.goBack();
    }
    return (
        <React.Fragment>
             <Loader isLoading={isLoading} />
            <DashboardHeader
                showBackArrow={true}
                headerTitle={"Categories"}
                navScreen={props.navigation}
                headerContainerStyle={{
                    borderBottomColor: "rgba(0, 0, 0, 0.14)",
                    borderBottomWidth: 1,
                }}
                onPress={() => navigateToScreen()}
            />
            <MiddleContentWrapper>
                <View style={[styles.showAllContainer, {}]}>
                    <View style={styles.categoryContainer}>

                        {catagory && catagory.length > 0 && catagory.map((item, index) => {
                      ///  console.log('Category>>>>',item)
                            return (
                                <TouchableOpacity 
                                style={[styles.categoryList, { backgroundColor:colours[index]}]} key={index}
                                onPress={()=>{
                                      
                                    if(item.sub_category.length>0){
                                       console.log('Sub Category------')
                                       let ItemID=item.id;
                                        props.navigation.navigate("SubCatagoryProduct",ItemID);
                                    }else{
                                        console.log('Category Product------')
                                      // props.navigation.navigate("CategoryProduct")
                                      let ItemID=item.id;
                                      console.log('catagory ID>>',ItemID)
                                      ////Category wise Products calling
                                      props.navigation.navigate("CategoryByProduct",ItemID)
                                    }
                                
                                
                                
                                
                                
                                
                                
                                }}
                                style={[styles.categoryList, { backgroundColor: '#ffffff' } ]} key={index}
                                >
                                    <Image source={{uri: item.image}}
                                    // source={
                                    //     require('https://gsh-dev.s3.ap-south-1.amazonaws.com/category_images/GSH-03a456c6-ff48-4239-b69d-b07fc02b5bce.jpg')
                                    //     } 
                                        style={{ width: "100%", height: "75%", resizeMode: 'cover', borderTopRightRadius: 10, borderTopLeftRadius: 10 }} />
                                    <View style={{ height: 5 }} />
                                    <Text style={styles.categoryText}>{item.name}</Text>
                                
                                </TouchableOpacity>
                            )
                        })}

                    </View>
                </View>

            </MiddleContentWrapper>
        </React.Fragment>


    );
};

export const styles = StyleSheet.create({

    showAllContainer: {
        paddingLeft: 30,
        paddingRight: 30,

    },
    categoryContainer: {
        flex: 1,
        flexWrap: 'wrap',
        flexDirection: 'row',
        marginTop: 20,
    },
    categoryList: {
        flexBasis: '45%',
        width: 140.7,
        height: 140.7,
        borderColor:'#000000',
        borderRadius: 10,
        shadowColor: "rgba(0, 0, 0, 0.15)",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowRadius: 4,
        shadowOpacity: 1,
        // justifyContent: 'center',
        alignItems: 'center',
        margin: 8,
    },
    categoryText: {
        fontFamily: "Montserrat-Black",
        fontSize: 16,
        fontWeight: "900",
        fontStyle: "normal",
        lineHeight: 22.2,
        letterSpacing: 0,
        textAlign: "center",
        color: "#000000"
    }



});

export default Category;