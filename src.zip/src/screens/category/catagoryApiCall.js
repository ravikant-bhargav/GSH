
import { getApi } from '../../utils/apiServices';

const catagoryAPiUrl = "category/categories";
const subcatagoryAPiUrl = "category/subcategories/";

const initialState = {
    appcatagory:[],

};
///https://api.gharsehaat.com/v1/api/category/categories?page=1&per_page=10

////////////// Catagory///////////////////////////////////////////////////////////////////////////////////////////////////
export const getCatagoryApi = async (token,offset) => {
    let putData = {
        "page": offset,
        "per_page":10
    };
    const config = {
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
            Authorization : `Bearer ${token}`}
    };

        let resdata = await getApi(catagoryAPiUrl, config,putData)
            .then((response) => {
                return response;
    
            }).catch(function (error) {
                return error;
            });
         
        return resdata;
    
    }
 ///api/category/subcategories/3?page=1&per_page=10
 /////SubCatagory///////////////////////////////////////////////////////////////////////////////////////////////
export const getsubCatagoryApi = async (token,offset,id) => {
    let putData = {
        "page": offset,
        "per_page":10
    };
    const config = {
        headers: {
            'Accept': 'application/json',
            "Content-Type": "application/json",
            Authorization : `Bearer ${token}`}
    };

        let resdata = await getApi(subcatagoryAPiUrl+id, config,putData)
            .then((response) => {
                return response;
    
            }).catch(function (error) {
                return error;
            });
         console.log('subCatagory>>',resdata,subcatagoryAPiUrl+id, config,putData)
        return resdata;
    
    }
 