import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
  Alert,
  BackHandler,
} from "react-native";

import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";
import LinearGradient from "react-native-linear-gradient";
import { AppButton } from "../../components/button/AppButton";

import MiddleContentWrapper from "../../components/contentWrapper/MiddleContentWrapper";
import CalendarCardView from "../../components/calendar/CalendarCardView";
import OrderStatusLabels from "../../components/OrderStatusLabels";
import AmountAdjustment from "../../components/AmountAdjustment";
import HorizontalLine from "../../components/HorizontalLine";

import DashboardHeader from "../../components/shared/DashboardHeader";
import PrimaryButton from "../../components/button/PrimaryButton";
import LinearGradientView from "../../components/LinearGradientView";
import PrimaryInputBox from "../../components/inputbox/PrimaryInputBox";
import PrimaryButtonResize from "../../components/button/PrimaryButtonResize";
import ProductCard from "../../components/product/ProductCard";
import TabBarNavigation from "../../navigation/TabBarNavigation";
import AsyncStorage from "@react-native-async-storage/async-storage";
import appConstant from "../../utils/appConstant";
import {
  getProductallApi,
  getProductSearchingApi,
  getCatagoryProductApi,
} from "./../product/ProductCallApi";
import { getCatagoryApi } from "./../category/catagoryApiCall";
import Loader from "../../components/Loader";


// const CatgeoryList = [
//     {
//         name: "All",
//         isActive: true
//     },
//     {
//         name: "Vegetables",
//         isActive: false
//     },
//     {
//         name: "Butter",
//         isActive: false
//     },
//     {
//         name: "Ghee",
//         isActive: false
//     },
//     {
//         name: "Paneer",
//         isActive: false
//     },
// const CatgeoryList = [
//     {
//         name: "All",
//         isActive: true
//     },
//     {
//         name: "Vegetables",
//         isActive: false
//     },
//     {
//         name: "Butter",
//         isActive: false
//     },
//     {
//         name: "Ghee",
//         isActive: false
//     },
//     {
//         name: "Paneer",
//         isActive: false
//     },

// ]

const CategoryByProduct = (props) => {
  var ItemID = props.route.params;

  ///setTempId(props.route.params);
  //      await AsyncStorage.setItem('id',ItemID);
  //    var loc=  await AsyncStorage.getItem('id')
  //    console.log('loc>>',loc);

  const [serachText, onChangeText] = useState("");

  const navigateToScreen = () => {
    props.navigation.goBack();
  };

  const [isLoading, setIsLoading] = React.useState(false);
  const [product, setproduct] = useState([]);
  const [offset, setOffset] = useState(1);
  const [ITEMIID, setITEMIID] = useState(0);
  const [defaultColor, setdefaultColor] = useState(false);
  const [tempId, setTempId] = useState("");
  const [CatgeoryList, setCatgeoryList] = useState([]);
  const [shouldShowAllbutton, setshouldShowAllbutton] = useState(false);
  const [shouldShowAllbutton2, setshouldShowAllbutton2] = useState(true);

  const [shouldShowproduct, setShouldShowproduct] = useState(true);
  const [shouldShowcatagoryproduct, setShouldShowcatagoryproduct] =
    useState(false);
  const [shouldShowsearchingproduct, setShouldShowsearchingproduct] =
    useState(false);
  const [searchproduct, setsearchproduct] = useState([]);

  const [shouldShowNodata, setshouldShowNodata] = React.useState(false);
  const [shouldShowNodata1, setshouldShowNodata1] = React.useState(false);
  const [shouldShowNodata2, setshouldShowNodata2] = React.useState(false);

  useEffect(() => {
    getcatagoryProductmethodApi();
    getCatagorygmethodApi();
    return () => {};
  }, []);
  const getcatagoryProductmethodApi = async () => {
    setproduct([]);
    setITEMIID(ItemID);
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getCatagoryProductApi(token, offset, ItemID);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      // let msg = reasData?.data?.status?.message || "";
      // Alert.alert("", msg);
      // console.log(reasData.data.count);
      setOffset(offset + 1);
      setShouldShowproduct(true);
      setShouldShowcatagoryproduct(false);
      setShouldShowsearchingproduct(false);
      if (reasData.data.count <= 0) {
        setshouldShowNodata1(false);
        setshouldShowNodata2(false);
        setshouldShowNodata(true);
      } else {
        setproduct(reasData.data);
        setshouldShowNodata1(false);
        setshouldShowNodata2(false);
        setshouldShowNodata(false);
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
      props.navigation.navigate("UnderMaintenenance");
    }
  };

  const getCatagorygmethodApi = async () => {
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getCatagoryApi(token, offset);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      setCatgeoryList(reasData.data.data);
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  const getcatagorywiseProductmethodApi = async (itemId) => {
    setproduct([]);
    setITEMIID(itemId);
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    setIsLoading(true);
    const reasData = await getCatagoryProductApi(token, offset, itemId);
    if (reasData && reasData.status === 200) {
      setIsLoading(false);
      // let msg = reasData?.data?.status?.message || "";
      // Alert.alert("", msg);
      // console.log(reasData.data.count);
      setOffset(offset + 1);
      console.log("valueGet==>>>", reasData.data.data);
      setShouldShowproduct(false);
      setShouldShowcatagoryproduct(true);
      setShouldShowsearchingproduct(false);
      if (reasData.data.count <= 0) {
        //  Alert.alert("",'No item found');
        //  props.navigation.navigate('NoOrder')
        setshouldShowNodata1(true);
        setshouldShowNodata2(false);
        setshouldShowNodata(false);
      } else {
        setproduct(reasData.data.data);
        setshouldShowNodata1(false);
        setshouldShowNodata2(false);
        setshouldShowNodata(false);
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      setIsLoading(false);
      Alert.alert("", reasData?.err_message?.status?.message);
      props.navigation.navigate("UnderMaintenenance");
    }
  };
  // const searchingFilter=(text)=>{
  //     if(text){
  //         const newData=product.filter((item)=>{
  //             const itemData=item.name?
  //             item.name.toUpperCase()
  //             :''.toUpperCase();
  //             const textData=text.toUpperCase();
  //             return itemData.indexOf(textData)>-1;
  //         })
  //         setFilterData(newData);
  //         setsearch(text);
  //     }else{
  //         setFilterData(product);
  //         setsearch(text);
  //     }
  // }

  const getProductsearchingmethodApi = async (serachText) => {
    console.log("serching==>", serachText);
    setproduct([]);
    let token = await AsyncStorage.getItem(appConstant.APP_TOKEN);
    //  setIsLoading(true);
    const reasData = await getProductSearchingApi(token, serachText);
    if (reasData && reasData.status === 200) {
      // setIsLoading(false);
      let msg = reasData?.data?.status?.message || "";
      /// Alert.alert("", msg);
      console.log(reasData.data);
      if (reasData.data.count <= 0) {
        //  Alert.alert("",'No item found');
        //  props.navigation.navigate('NoOrder')
        setshouldShowNodata1(false);
        setshouldShowNodata2(true);
        setshouldShowNodata(false);
      } else {
        setsearchproduct(reasData.data.data);
        setShouldShowproduct(false);
        setShouldShowcatagoryproduct(false);
        setShouldShowsearchingproduct(true);
        setshouldShowNodata1(false);
        setshouldShowNodata2(false);
        setshouldShowNodata(false);
      }
    } else if (
      reasData &&
      (reasData.err_status === 400 || reasData.err_status === 404)
    ) {
      //  setIsLoading(false);
      ///  Alert.alert("", reasData?.err_message?.status?.message);
    }
  };
  const getData = (text) => {
    onChangeText(text);

    getProductsearchingmethodApi(text);
  };

  //console.log('Product>>',product)

  return (
    <React.Fragment>
      <Loader isLoading={isLoading} />
      <DashboardHeader
        showBackArrow={true}
        headerTitle={"Category wise Products"}
        navScreen={props.navigation}
        headerContainerStyle={{
          borderBottomColor: "rgba(0, 0, 0, 0.14)",
          borderBottomWidth: 1,
        }}
        onPress={() => navigateToScreen()}
      />
      <MiddleContentWrapper navigation={props.navigation} {...props}>
        <View style={[styles.showAllContainer, {}]}>
          <View style={styles.serachBoxContainer}>
            <Image source={images.SearchIcon} style={styles.searchButton} />
            <TextInput
              style={styles.serachInputContainer}
              onChangeText={getData}
              //value={props.value}
              placeholder={"Find your favorites here" || ""}
              placeholderTextColor={"#000000"}
            />
          </View>
        </View>

        <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
          <View
            style={{
              paddingLeft: 15,
              flex: 1,
              flexDirection: "row",
              marginTop: 10,
              marginBottom: 4,
            }}
          >
            {/* {shouldShowAllbutton ? 
                    (
                    
                               <PrimaryButtonResize
                                        btnText={'All'}
                                        btnCustomStyle={{ backgroundColor: '#3d3cb3', width: 'auto' }}
                                        btnTextStyle={{ color: '#ffffff' }}
                                        onPress={() => {
                                            getcatagoryProductmethodApi();
                                            setITEMIID(0); 
                                            setshouldShowAllbutton(true)
                                            setshouldShowAllbutton2(false)
                                            ItemID=ItemID;

                                        }}
                                     />

                        ) : null}
                           {shouldShowAllbutton2 ? 
                     (
                    
                               <PrimaryButtonResize
                                        btnText={'All'}
                                        btnCustomStyle={{ backgroundColor: '#f6f6f6', width:'auto' }}
                                        btnTextStyle={{ color: '#000000' }}
                                        onPress={() => {
                                            getcatagoryProductmethodApi();
                                            setITEMIID(0); 
                                            setshouldShowAllbutton(true)
                                            setshouldShowAllbutton2(false)
                                            ItemID=ItemID;

                                        }}
                                     />

                        ) : null} */}
            {/* {CatgeoryList && CatgeoryList.length > 0 && CatgeoryList.map((c_item, c_index) => {
                            let bgColor = c_item.isActive === true ? "#3d3cb3" : "#f6f6f6";
                            let txtColor = c_item.isActive === true ? "#ffffff" : "#3d3cb3";
                            console.log('ItemID==>',c_item.isActive);

                            return (
                                <React.Fragment key={c_index}>
                                    <PrimaryButtonResize
                                        btnText={c_item.name}
                                        btnCustomStyle={{ backgroundColor: bgColor, width: c_index === 0 && 65 || 'auto' }}
                                        btnTextStyle={{ color: txtColor }}
                                        onPress={() => {
                                          //  bgColor(true);
                                          //  txtColor(true);
                                            let itemId=c_item.id;
                                            console.log('ItemID==>',itemId);
                                            getcatagorywiseProductmethodApi(itemId);

                                        }}
                                    />
                                </React.Fragment>
                            )
                        })} */}

            {CatgeoryList &&
              CatgeoryList.length > 0 &&
              CatgeoryList.map((c_item, c_index) => {
                let bgColor = c_item.isActive === true ? "#3d3cb3" : "#f6f6f6";
                let txtColor = c_item.isActive === true ? "#ffffff" : "#3d3cb3";

                let id = c_item.id;
                let name = c_item.name;
                if (parseInt(ITEMIID) == parseInt(c_item.id)) {
                  return (
                    <React.Fragment key={c_index}>
                      <PrimaryButtonResize
                        btnText={name}
                        btnCustomStyle={{
                          backgroundColor: "#3d3cb3",
                          width: (c_index === 0 && 65) || "auto",
                        }}
                        btnTextStyle={{ color: "#ffffff" }}
                        onPress={() => {
                          let itemId = c_item.id;

                          getcatagorywiseProductmethodApi(itemId);
                          setdefaultColor(true);
                          setITEMIID(itemId);

                          setshouldShowAllbutton(false);
                          setshouldShowAllbutton2(true);
                        }}
                      />
                    </React.Fragment>
                  );
                } else {
                  return (
                    <React.Fragment key={c_index}>
                      <PrimaryButtonResize
                        btnText={c_item.name}
                        btnCustomStyle={{
                          backgroundColor: bgColor,
                          width: (c_index === 0 && 65) || "auto",
                        }}
                        btnTextStyle={{ color: txtColor }}
                        onPress={() => {
                          let itemId = c_item.id;

                          getcatagorywiseProductmethodApi(itemId);
                          setdefaultColor(true);
                          setITEMIID(c_item.id);

                          setshouldShowAllbutton(false);
                          setshouldShowAllbutton2(true);
                        }}
                      />
                    </React.Fragment>
                  );
                }
              })}
          </View>
        </ScrollView>
        <HorizontalLine />
        {shouldShowproduct ? (
          <View style={[styles.showAllContainer, {}]}>
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              {shouldShowNodata ? (
                <View
                  style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <View style={{ marginLeft: 30, marginRight: 30 }}>
                    <Text style={styles.headingContainer1}>No Data found</Text>
                  </View>
                  <Image
                    source={images.noOrderFound}
                    style={{ marginTop: 30 }}
                  />
                </View>
              ) : null}
            </View>

            <View style={styles.productWrapper}>
              {product.data &&
                product.data.length > 0 &&
                product.data.map((item, p_index) => {
                  // console.log('item>>',item)
                  let price;
                  if (item.category_product[0].is_on_sale == true) {
                    price = item.category_product[0].special_sale_price;
                  } else {
                    price = item.category_product[0].max_retail_price;
                  }
                  return (
                    <React.Fragment key={p_index}>
                      <ProductCard
                        name={item.category_product[0].name}
                        quantity={""}
                        amount={"₹" + price}
                        image={item.category_product[0].product_images[0].url}
                        onPress={() => {
                          let itemId = item.category_product[0].id;
                          console.log("ItemID==>", itemId);
                          props.navigation.navigate("ProductDetails", {
                            itemId: itemId,
                            fromScreen: "CategoryByProduct",
                          });
                        }}
                      />
                    </React.Fragment>
                  );
                })}
            </View>
          </View>
        ) : null}
        {shouldShowcatagoryproduct ? (
          <View style={[styles.showAllContainer, {}]}>
            <View
              style={{
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              {shouldShowNodata1 ? (
                <View
                  style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <View style={{ marginLeft: 30, marginRight: 30 }}>
                    <Text style={styles.headingContainer1}>No Data found</Text>
                  </View>
                  <Image
                    source={images.noOrderFound}
                    style={{ marginTop: 30 }}
                  />
                </View>
              ) : null}
            </View>
            <View style={styles.productWrapper}>
              {product &&
                product.length > 0 &&
                product.map((item, p_index) => {
                  //  console.log('product item>>',item.category_product[0])
                  let price;
                  if (item.category_product[0].is_on_sale == true) {
                    price = item.category_product[0].special_sale_price;
                  } else {
                    price = item.category_product[0].max_retail_price;
                  }

                  return (
                    <React.Fragment key={p_index}>
                      <ProductCard
                        name={item.category_product[0].name}
                        quantity={item.category_product[0].stock_quantity}
                        amount={"₹" + price}
                        image={item.category_product[0].product_images[0].url}
                        onPress={() => {
                          let itemId = item.category_product[0].id;
                          console.log("ItemID==>", itemId);
                          props.navigation.navigate("ProductDetails", itemId);
                        }}
                      />
                    </React.Fragment>
                  );
                })}
            </View>
          </View>
        ) : null}

        {shouldShowsearchingproduct ? (
          <View style={[styles.showAllContainer, {}]}>
            {shouldShowNodata2 ? (
              <View
                style={{
                  flex: 1,
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <View style={{ marginLeft: 30, marginRight: 30 }}>
                  <Text style={styles.headingContainer1}>No Data found</Text>
                </View>
                <Image source={images.noOrderFound} style={{ marginTop: 30 }} />
              </View>
            ) : null}
            <View style={styles.productWrapper}>
              {searchproduct &&
                searchproduct.length > 0 &&
                searchproduct.map((item, p_index) => {
                  ///console.log('product item>>',item)
                  let price;
                  if (item.is_on_sale == true) {
                    price = item.special_sale_price;
                  } else {
                    price = item.max_retail_price;
                  }

                  return (
                    <React.Fragment key={p_index}>
                      <ProductCard
                        name={item.name}
                        quantity={item.description}
                        amount={price}
                        image={item.product_images[0].url}
                        onPress={() => {
                          let itemId = item.id;
                          console.log("ItemID==>", itemId);
                          props.navigation.navigate("ProductDetails", itemId);
                        }}
                      />
                    </React.Fragment>
                  );
                })}
            </View>
          </View>
        ) : null}
      </MiddleContentWrapper>
      <TabBarNavigation navigation={props.navigation} {...props} />
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  showAllContainer: {
    paddingLeft: 15,
    paddingRight: 15,
  },

  headingContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 12,
    marginLeft: 10,
  },
  boldTextStyle: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 15,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    color: "#09051c",
  },

  productWrapper: {
    flex: 1,
    flexWrap: "wrap",
    flexDirection: "row",
    marginTop: 5,
  },

  searchSection: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 5,
    borderRadius: 10,
    borderColor: "#000000",
    backgroundColor: "#C4C4C4",
  },
  searchIcon: {
    width: 20,
    height: 20,
    size: 10,
  },
  input: {
    flex: 1,
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 0,
    backgroundColor: "#C4C4C4",
    color: "#424242",
  },
  showAllContainer: {
    paddingLeft: 15,
    paddingRight: 15,
  },
  headingContainer: {
    fontFamily: "Montserrat-Bold",
    fontSize: 19,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 24.9,
    letterSpacing: 0,
    color: "#09051c",
    textAlign: "center",
  },
  headingContainer1: {
    opacity: 0.8,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    color: "#09051c",
    textAlign: "center",
  },
  btnMainStyle: { flex: 1 / 4, marginTop: 40 },
  btnStyle: {
    width: 111,
    height: 45,
    borderRadius: 10,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    borderStyle: "solid",
    borderWidth: 2.5,
    borderColor: "#3d3cb3",
    backgroundColor: "#fff",
  },
  btnTextStyle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#3d3cb3",
  },
  serachInputContainer: {
    flex: 1,
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 0,
    fontFamily: "Montserrat-Medium",
    fontSize: 14,
    fontWeight: "500",
    fontStyle: "normal",
    lineHeight: 15.3,
    letterSpacing: 0,
    color: "#000000",
  },

  serachBoxContainer: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(194,194,194,0.27)",
    marginTop: 20,
    height: 45,
    borderRadius: 10,
  },
  searchButton: {
    width: 25,
    height: 25,
    margin: 10,
  },
});

export default CategoryByProduct;
