const images = {
  logoImage: require("./../assets/images/logo.png"),
  innerLogoImage: require("./../assets/images/innerLogo.png"),
  textLogoImage: require("./../assets/images/textLogo.png"),
  LogoFull: require("./../assets/images/icons/gsh_logo_full.png"),

  SplashScreen: require("./../assets/images/icons/splash_screen.png"),
  /** OnBoarding Screens Icons */
  chevronRight: require("./../assets/images/icons/chevron_right.png"),
  chevronLeft: require("./../assets/images/icons/chevron_left.png"),
  chevronDown: require("./../assets/images/icons/chevron_down.png"),
  languageGlobe: require("./../assets/images/icons/languages_g.png"),
  indiaFlag: require("./../assets/images/icons/india.png"),
  englishFlag: require("./../assets/images/icons/english.png"),
  okFlag: require("./../assets/images/icons/Ok.png"),
  OKAYFlag: require("./../assets/images/icons/OKAY.png"),

  BackArrow: require("./../assets/images/icons/back_arrow.png"),
  BackArrowWhite: require("./../assets/images/icons/back_arrow_white.png"),

  onBoardingScreen1: require("./../assets/images/icons/onboardingscreen1.png"),
  onBoardingScreen2: require("./../assets/images/icons/onboardingscreen2.png"),
  googleIcon: require("./../assets/images/icons/google.png"),
  facebookIcon: require("./../assets/images/icons/facebook.png"),

  menuIcon: require("./../assets/images/icons/menu_ic.png"),
  bellIcon: require("./../assets/images/icons/bell_icon.png"),
  milkBanner: require("./../assets/images/icons/banner.png"),
  AddButton: require("./../assets/images/icons/Add.png"),
  SearchIcon: require("./../assets/images/icons/Search.png"),
  CrossIcon: require("./../assets/images/icons/cross_ic.png"),
  GoldIcon: require("./../assets/images/icons/coin.png"),
  ProfileAvatarIcon: require("./../assets/images/icons/profile.png"),
  ProfileIcon: require("./../assets/images/icons/Profile_ic.png"),

  CalendarIcon: require("./../assets/images/icons/d_calendar.png"),
  CategoryIcon: require("./../assets/images/icons/d_category.png"),
  WeeklyPlannerIcon: require("./../assets/images/icons/d_weekly_planner.png"),

  LanguageIcIcon: require("./../assets/images/icons/language_ic.png"),
  SpeechIcIcon: require("./../assets/images/icons/Speech_ic.png"),
  SupportIcIcon: require("./../assets/images/icons/Support_ic.png"),
  LogoutIcIcon: require("./../assets/images/icons/Logout_ic.png"),

  EggCategory: require("./../assets/images/icons/egg.png"),
  OilCategory: require("./../assets/images/icons/oil.png"),
  BreadCategory: require("./../assets/images/icons/g_bread.png"),
  DairyCategory: require("./../assets/images/icons/g_dairy.png"),
  GheeCategory: require("./../assets/images/icons/g_ghee.png"),
  MilkCategory: require("./../assets/images/icons/g_milk.png"),
  Oil1Category: require("./../assets/images/icons/g_oil.png"),
  PulsesCategory: require("./../assets/images/icons/g_pulses.png"),
  SpicesCategory: require("./../assets/images/icons/g_spices.png"),

  product1: require("./../assets/images/icons/product1.png"),
  product2: require("./../assets/images/icons/product2.png"),
  product3: require("./../assets/images/icons/product3.png"),

  P1Icon: require("./../assets/images/icons/p_1.png"),
  P2Icon: require("./../assets/images/icons/p_2.png"),
  P3Icon: require("./../assets/images/icons/p_3.png"),
  P4Icon: require("./../assets/images/icons/p_4.png"),
  P5Icon: require("./../assets/images/icons/p_5.png"),
  P6Icon: require("./../assets/images/icons/p_6.png"),
  p_4removebgpreview: require("./../assets/images/icons/p_4-removebg-preview.png"),

  productImg1: require("./../assets/images/icons/productImg1.png"),
  productImg2: require("./../assets/images/icons/productImg2.png"),
  productImg3: require("./../assets/images/icons/productImg3.png"),

  plusIcon: require("./../assets/images/icons/plusicon.png"),
  plusIconMath: require("./../assets/images/icons/plus_math.png"),

  minusIcon: require("./../assets/images/icons/minus.png"),

  noOrderFound: require("./../assets/images/icons/no_order_found.png"),
  underMaintenance: require("./../assets/images/icons/under_maintenance.png"),
  noInternet: require("./../assets/images/icons/no_internet.png"),
  orderConfirmedIcon: require("./../assets/images/icons/order-confirmed.png"),

  likeIcon: require("./../assets/images/icons/Love.png"),
  disLike: require("./../assets/images/icons/disLike.png"),
  pencilEditIcon: require("./../assets/images/icons/Pencil_Edit.png"),
  sortDownIcon: require("./../assets/images/icons/Sort_Down.png"),
  locationIcon: require("./../assets/images/icons/location.png"),
  razorPayIcon: require("./../assets/images/icons/paytm-pay.png"),
  codIcon: require("./../assets/images/icons/cod.png"),
  deleteIcon: require("./../assets/images/icons/delete.png"),
  checkIcon: require("./../assets/images/icons/checkbox.png"),
  uncheckIcon: require("./../assets/images/icons/unchecked.png"),

  // Footer Icon

  homeIcon: require("./../assets/images/icons/F_Home.png"),
  billsIcon: require("./../assets/images/icons/F_Bills.png"),
  cartIcon: require("./../assets/images/icons/F_Cart.png"),
  productIcon: require("./../assets/images/icons/F_Products.png"),

  // Profile Screen Icon
  MypAddressIcon: require("./../assets/images/icons/myp_address_ic.png"),
  MypInfoIcon: require("./../assets/images/icons/myp_Info_ic.png"),
  MypLogoutIcon: require("./../assets/images/icons/myp_logout_ic.png"),
  MypOrderHistoryIcon: require("./../assets/images/icons/myp_order_history_ic.png"),
  MypSubscriptionIcon: require("./../assets/images/icons/myp_subscription_ic.png"),
  MypRightArrowIcon: require("./../assets/images/icons/myp_right_arrow.png"),

  CheckProductStatusIcon: require("./../assets/images/icons/check_order.png"),
  CalendarStatusIcon: require("./../assets/images/icons/calendar_ic.png"),
  TimeStatusIcon: require("./../assets/images/icons/time_ic.png"),

  NoPlanIcon: require("./../assets/images/icons/noplan.png"),
};

export default images;
