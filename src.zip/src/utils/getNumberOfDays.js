export const getNumberOfDaysInTheMonth = (month, year) => {
  return new Date(year, month, 0).getDate();
};

export const getAllDaysInMonth = (month, year) => {
  const date = new Date(year, month, 1);

  const dates = [];

  while (date.getMonth() === month) {
    dates.push(new Date(date));
    date.setDate(date.getDate() + 1);
  }

  return dates;
};

export const monthDropDown = [
  {
    label: "Jan",
    value: 0,
  },
  {
    label: "Feb",
    value: 1,
  },
  {
    label: "Mar",
    value: 2,
  },
  {
    label: "Apr",
    value: 3,
  },
  {
    label: "May",
    value: 4,
  },
  {
    label: "Jun",
    value: 5,
  },
  {
    label: "Jul",
    value: 6,
  },
  {
    label: "Aug",
    value: 7,
  },
  {
    label: "Sep",
    value: 8,
  },
  {
    label: "Oct",
    value: 9,
  },
  {
    label: "Nov",
    value: 10,
  },
  {
    label: "Dec",
    value: 11,
  },
];

export const yearDropDown = [
  {
    label: "2022",
    value: 2022,
  },
  {
    label: "2023",
    value: 2023,
  },
  {
    label: "2024",
    value: 2024,
  },
  {
    label: "2025",
    value: 2025,
  },
  {
    label: "2026",
    value: 2026,
  },
  {
    label: "2027",
    value: 2027,
  },
  {
    label: "2028",
    value: 2028,
  },
  {
    label: "2029",
    value: 2029,
  },
  {
    label: "2030",
    value: 2030,
  },
];
