import { Dimensions, PixelRatio } from "react-native";

const WINDOW_WIDTH = Dimensions.get("window").width;
const guidelineBaseWidth = 375;

const { width, height } = Dimensions.get("window");
export const deviceWidth = Dimensions.get("screen").width;
export const deviceHeight = Dimensions.get("screen").height;

export const API_KEY = "AIzaSyAg7HTmUqhU5MWT8V2VOu8JBQC62LKPZy4";
