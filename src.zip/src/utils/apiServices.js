import axios from "axios";

const BASE_URL = 'https://api.gharsehaat.com';
const BASE_URL_V1 = '/v1/api/';
const API_URL = BASE_URL + BASE_URL_V1;

const HEADER_SETUP = {
    'Accept': 'application/json',
    "Content-Type": "application/json"
};

var instance = axios.create({
    baseURL: API_URL,
    timeout: 1000,
    headers: HEADER_SETUP
});


export const getApi = async (apiUrl,header,gdata) => {
    const resData = await instance.get(apiUrl,header,gdata)
        .then(function (response) {
            let resData = {
                data: response.data,
                status: parseInt(response.status)
            }
            return resData;
        })
        .catch(function (error) {
            let errData = error;
            if (error.response) {
                errData = {
                    err_message: error.response.data,
                    err_status: parseInt(error.response.status)
                }
            }

            return errData;
        });
    return resData;
}

export const postApi = async (apiUrl,pdata,header) => {

    const resData = await instance.post(apiUrl,pdata,header)
        .then((response) => {

            let resData = {
                data: response.data,
                status: parseInt(response.status)
                
            }
            return resData;
        })
        .catch((error) => {
          //  console.log("error", error);
            let errData = error;
            if (error.response) {
                errData = {
                    err_message: error.response.data,
                    err_status: parseInt(error.response.status)
                }
            }

            return errData;
        });
       // console.log("Post calling....", resData,apiUrl,header,pdata);
    return resData;
}

export const putApi = async (apiUrl, postData,header) => {
    const resData = await instance.put(apiUrl, postData,header)
        .then((response) => {
            let resData = {
                data: response.data,
                status: parseInt(response.status)
            }
            return resData;
        })
        .catch((error) => {
            let errData = error;
            if (error.response) {
                errData = {
                    err_message: error.response.data,
                    err_status: parseInt(error.response.status)
                }
            }

            return errData;
        });

    return resData;
}
export const deleteApi = async (apiUrl,header) => {
    const resData = await instance.delete(apiUrl,header)
        .then((response) => {
            let resData = {
                data: response.data,
                status: parseInt(response.status)
            }
            return resData;
        })
        .catch((error) => {
            let errData = error;
            if (error.response) {
                errData = {
                    err_message: error.response.data,
                    err_status: parseInt(error.response.status)
                }
            }

            return errData;
        });

    return resData;
}
// export const getwithTokenApi = async (apiUrl,header) => {
//     console.log('apiUrl,header>>>',apiUrl,header)
//     const resData = await instance.get(apiUrl,header)
//         .then(function (response) {
//             let resData = {
//                 data: response.data,
//                 status: parseInt(response.status)
//             }
//             return resData;
//         })
//         .catch(function (error) {
//             let errData = error;
//             if (error.response) {
//                 errData = {
//                     err_message: error.response.data,
//                     err_status: parseInt(error.response.status)
//                 }
//             }

//             return errData;
//         });
//     return resData;
// }
