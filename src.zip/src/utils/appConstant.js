const appConstants = {
    APP_TOKEN: "app_token",
    USER_DATA: "user_data",
    CARD_ID: "cart_uuid",
    PAYTM_MID: 'xtukWb94013386870513', // my account
    NAME:"name",
    EMAIL: "email",
    PHONENUMBER:'phone_number',
    PROFILEIMAGE:'profile_picture',
    Billing_address_id:"billing_address_id",
    Shipping_address_id:"shipping_address_id",
    Address_type:"address_type",
     City:"city",
     Landmark:"landmark",
     State:"state",
     Street_address:"street",
     Zip_code:"zip_code"
};


export default appConstants;