const appColors = {
    WHITE:'#fff',
    BLACK:'#000',
    HEADER_TEXT_COLOR:'#434343',
    PRIMARY_COLOR:'#3e3db4'

};


export default appColors;