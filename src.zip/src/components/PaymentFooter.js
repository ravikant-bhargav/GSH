import React, { useRef, useEffect } from "react";

import {
  SafeAreaView,
  Image,
  Text,
  View,
  StyleSheet,
  Dimensions,
  Animated,
  StatusBar,
  TouchableOpacity,
  FlatList,
  Platform,
} from "react-native";
import images from "../utils/sharedImages";
import PrimaryButton from "./button/PrimaryButton";

const PaymentFooter = (props) => {
  return (
    <React.Fragment>
      <View style={[styles.footer, props.fooetrStyle]}>
        <View
          style={[
            ,
            props.fType && props.fType === "payment-method"
              ? styles.footerInnerPayment
              : styles.footerInner,
            Platform.OS === "ios"
              ? styles.iosOpticity
              : styles.androidOptiocity,
            {},
          ]}
        >
          {props.fType && props.fType === "payment-method" ? (
            <React.Fragment>
              <View
                style={{
                  width: "100%",
                  flexDirection: "column",
                  height: "100%",
                  paddingLeft: 15,
                  paddingRight: 15,
                }}
              >
                <View
                  style={[
                    ,
                    { flexDirection: "row", width: "100%", padding: 10 },
                  ]}
                >
                  <Text style={[styles.cartHeading, { width: "80%" }]}>
                    {(props.text && props.text) || "Total"}
                  </Text>
                  <Text
                    style={[
                      styles.cartSubHeading,
                      { width: "20%", color: "#201f9b" },
                    ]}
                  >
                    ₹ {(props.amount && props.amount) || "0"}{" "}
                  </Text>
                </View>
                <View style={{ width: "100%" }}>
                  <PrimaryButton
                    buttonText={
                      (props.btnText && props.btnText) || "Add to cart"
                    }
                    overRideNewCss={true}
                    btnStyle={{
                      width: "100%",
                      height: 49,
                      borderRadius: 7,
                    }}
                    btnTextStyle={{
                      fontFamily: "Montserrat-Bold",
                      fontSize: 16,
                      fontWeight: "bold",
                      fontStyle: "normal",
                      lineHeight: 17.5,
                      letterSpacing: 0,

                      color: "#ffffff",
                    }}
                    showRightImage={
                      true
                      //   props.showImage && props.showImage === true ? true : false
                    }
                    onPress={props.onPress}
                  />
                </View>
              </View>
            </React.Fragment>
          ) : (
            <React.Fragment>
              <View style={styles.totalAMount}>
                <Text style={styles.cartHeading}>
                  {(props.text && props.text) || "Total"}
                </Text>
                <Text
                  style={[
                    styles.cartSubHeading,
                    { ...props.customStyleAmount },
                  ]}
                >
                  ₹ {(props.amount && props.amount) || "0"}{" "}
                </Text>
              </View>
              <View style={styles.addToCartButton}>
                {(props.showButton && props.showButton === true && (
                  <PrimaryButton
                    buttonText={
                      (props.btnText && props.btnText) || "Add to cart"
                    }
                    btnStyle={{
                      width: 142,
                      borderRadius: 7,
                      ...props.btnStyle,
                    }}
                    btnTextStyle={styles.cartButtonText}
                    btnImgStyle={styles.cartIconSTyle}
                    showRightImage={
                      true
                      //   props.showImage && props.showImage === true ? true : false
                    }
                    onPress={props.onPress}
                  />
                )) || (
                  <React.Fragment>
                    <Text style={styles.cartPaymentHeading}>Payment Mode:</Text>
                    <Image
                      source={images.razorPayIcon}
                      style={{ width: 96, height: 25 }}
                    />
                  </React.Fragment>
                )}
              </View>
            </React.Fragment>
          )}
        </View>
      </View>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  footer: {
    flex: 1,
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    height: 71,
  },
  floatingIconContainer: {
    flex: 1,
    position: "absolute",
    bottom: 90,
    alignSelf: "flex-end",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  floatingIconButton: {
    width: 52,
    height: 52,
    borderRadius: 100,
    backgroundColor: "#3d3cb3",
    shadowColor: "rgba(0, 0, 0, 0.19)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 6,
    shadowOpacity: 1,
    marginRight: 20,
    elevation: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  floatingButtonText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 16,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    color: "#09051c",
    marginRight: 20,
  },
  footerInner: {
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
    backgroundColor: "#f6f6f6",
    width: "100%",
    height: "100%",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingLeft: 20,
    paddingRight: 0,
  },
  footerInnerPayment: {
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
    backgroundColor: "#f6f6f6",
    width: "100%",
    height: "100%",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingLeft: 5,
    paddingRight: 5,
  },

  totalAMount: {
    width: "50%",
    flexDirection: "column",
  },
  addToCartButton: {
    width: "50%",
    justifyContent: "center",
    alignItems: "center",
  },
  cartHeading: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 15,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 16.4,
    letterSpacing: 0,
    textAlign: "left",
    color: "#000000",
  },
  cartSubHeading: {
    fontFamily: "Montserrat-Bold",
    fontSize: 16,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 17.5,
    letterSpacing: 0,
    textAlign: "left",
    color: "#000000",
    marginTop: 3,
  },
  cartButtonText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 14,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 17.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#ffffff",
  },
  cartIconSTyle: {
    width: 21.3,
    height: 21.3,
    marginLeft: 10,
  },
  iosOpticity: {
    shadowColor: "rgba(0, 0, 0, 0.1)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 22,
    shadowOpacity: 1,
  },
  androidOptiocity: {
    elevation: 10,
  },
  cartPaymentHeading: {
    opacity: 0.8,
    fontFamily: "Montserrat-Bold",
    fontSize: 10,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#09051c",
  },
});

export default PaymentFooter;
