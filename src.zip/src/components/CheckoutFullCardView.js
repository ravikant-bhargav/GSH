import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Pressable,
  Alert,
  Modal,
  Button,
  Dimensions,
} from "react-native";

//import HorizontalLine from '../../components/HorizontalLine';
import images from "../utils/sharedImages";
const rupeyCode = "&#8377";
const { width } = Dimensions.get("window");
const CheckoutFullCardView = (props) => {
  console.log("propsFullCardView", props.card);
  // This is to manage Modal State
  const [showWarning, SetshowWarning] = useState(false);
  const [shouldShow, setShouldShow] = useState(false);

  /////Delete item call////////////////////////////////

  const deleteItem = (
    productid,
    quantity,
    is_active,
    product_delivery_type,
    product_variation_type,
    product_variation_value,
    product_coupon_code,
    delivery_start_date,
    delivery_end_date,
    delivery_time_slot,
    auto_renew_subscription,
    milk_delivery_type,
    milk_delivery_slot,
    additional_rule_json
  ) => {
    let data = {
      PID: productid,
      quantity: quantity,
      is_active: is_active,
      delivery_type: product_delivery_type,
      variation_type: product_variation_type,
      variation_value: product_variation_value,
      coupon_code: product_coupon_code,
      start_date: delivery_start_date,
      end_date: delivery_end_date,
      time_slot: delivery_time_slot,
      renew_subscription: auto_renew_subscription,
      milk_delivery_Type: milk_delivery_type,
      delivery_slot: milk_delivery_slot,
      rule_json: additional_rule_json,
    };
    ///  console.log('data>>>',data)
    props.getDate(data);
  };
  /////////////Edit item///////////////////

  const EditItem = (
    productid,
    quantity,
    is_active,
    product_delivery_type,
    product_variation_type,
    product_variation_value,
    product_coupon_code,
    delivery_start_date,
    delivery_end_date,
    delivery_time_slot,
    auto_renew_subscription,
    milk_delivery_type,
    milk_delivery_slot,
    additional_rule_json
  ) => {
    let editdata = {
      PID: productid,
      quantity: quantity,
      is_active: is_active,
      delivery_type: product_delivery_type,
      variation_type: product_variation_type,
      variation_value: product_variation_value,
      coupon_code: product_coupon_code,
      start_date: delivery_start_date,
      end_date: delivery_end_date,
      time_slot: delivery_time_slot,
      renew_subscription: auto_renew_subscription,
      milk_delivery_Type: milk_delivery_type,
      delivery_slot: milk_delivery_slot,
      rule_json: additional_rule_json,
    };
    // console.log('data>>>',editdata)
    props.getEditData(editdata);
    SetshowWarning(false);
  };

  return (
    <React.Fragment>
      <Modal
        visible={showWarning}
        transparent
        onRequestClose={() => SetshowWarning(false)}
        animationType="slide"
        hardwareAccelerated
      >
        <View style={styles.centered_view}>
          <View style={styles.warning_modal}>
            <View style={styles.warning_title}>
              <Text style={styles.text}>Edit quantity</Text>
            </View>
            <View style={styles.warning_body}></View>
            <Pressable
              onPress={() => {
                // let productid=item.product_id;
                // let quantity=Counter;
                // var  is_active =true;
                // let product_delivery_type=item.product_delivery_type;
                // let product_variation_type=item.product_variation_type;
                // let product_variation_value=item.product_variation_value;
                // let product_coupon_code= item.product_coupon_code;
                // let delivery_start_date= item.delivery_start_date;
                // let delivery_end_date=item.delivery_end_date;
                // let delivery_time_slot=item.delivery_time_slot;
                // var auto_renew_subscription=item.auto_renew_subscription;
                // let milk_delivery_type= item.milk_delivery_type;
                // let milk_delivery_slot= item.milk_delivery_slot;
                // let additional_rule_json= item.additional_rule_json;
                // EditItem(productid,quantity,is_active,product_delivery_type,product_variation_type,
                //     product_variation_value,product_coupon_code,delivery_start_date,delivery_end_date,
                //     delivery_time_slot,auto_renew_subscription,milk_delivery_type,milk_delivery_slot,additional_rule_json);
              }}
              style={styles.warning_button}
              android_ripple={{ color: "#fff" }}
            >
              <Text style={styles.text}>{"Ok"}</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      {props.card &&
        props.card.length > 0 &&
        props.card.map((item, index) => {
          console.log("item>>", item);

          return (
            <React.Fragment key={index}>
              <View style={styles.productContainer}>
                <View style={styles.productSubContainer}>
                  <View
                    style={[styles.productInnerContainer, { height: "100%" }]}
                  >
                    <View
                      style={[
                        styles.productDetailContainer,
                        { flexDirection: "row" },
                      ]}
                    >
                      <View
                        style={{
                          width: "25%",
                          borderEndColor: "rgba(0, 0, 0, 0.14)",
                          borderEndWidth: 1,
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                      >
                        <Image
                          source={{ uri: item.image }}
                          style={{
                            resizeMode: "cover",
                            width: 72,
                            height: 47,
                          }}
                        />
                      </View>

                      <View
                        style={{
                          paddingLeft: 8,
                          paddingTop: 8,
                          paddingBottom: 8,
                          width: "55%",
                        }}
                      >
                        <Text style={styles.productNameText}>
                          {item.product_name}
                        </Text>
                        {/* {exixtingitemShow ?
                                ( */}
                        <Text style={[styles.productQtyText, { marginTop: 1 }]}>
                          {item.quantity + " kg"}
                        </Text>
                        {/* ) : null} */}
                        <Text
                          style={[styles.productPlanTypeText, { marginTop: 1 }]}
                        >
                          Type:{" "}
                          <Text
                            style={{
                              fontFamily: "Montserrat-SemiBold",
                              color: "rgb(9, 5, 28)",
                            }}
                          ></Text>
                          {item.product_delivery_type}
                        </Text>
                        <Text
                          style={[styles.productAmountText, { marginTop: 10 }]}
                        >
                          {"₹ " + item.price}
                        </Text>
                        {shouldShow ? (
                          <View
                            style={{
                              width: "100%",
                              flexDirection: "row",
                              marginTop: 20,
                              alignItems: "center",
                            }}
                            key={index}
                          >
                            <Text
                              style={{
                                fontFamily: "Montserrat-Bold",
                                fontSize: 15,
                                fontWeight: "bold",
                                fontStyle: "normal",
                                lineHeight: 14.2,
                                letterSpacing: 0,
                                textAlign: "left",
                                color: "#000000",
                              }}
                            >
                              Quantitiy
                            </Text>
                            <View
                              style={{ flexDirection: "row", marginLeft: 18 }}
                            >
                              <TouchableOpacity
                                onPress={() => {
                                  props.OnDecrement();
                                }}
                              >
                                <Image
                                  source={images.minusIcon}
                                  style={{
                                    width: 20,
                                    height: 20,
                                    marginRight: 8,
                                  }}
                                />
                              </TouchableOpacity>

                              <Text
                                style={{
                                  fontFamily: "Montserrat-SemiBold",
                                  fontSize: 15,
                                  fontWeight: "600",
                                  fontStyle: "normal",
                                  lineHeight: 14.2,
                                  letterSpacing: 0,
                                  textAlign: "left",
                                  color: "#000000",
                                  marginRight: 8,
                                  justifyContent: "center",
                                  alignSelf: "center",
                                  alignItems: "center",
                                  marginTop: 3,
                                }}
                              >
                                {props.OnCounvalue + " kg"}
                              </Text>
                              <TouchableOpacity
                                onPress={() => {
                                  props.onIncrement();
                                }}
                              >
                                <Image
                                  source={images.plusIcon}
                                  style={{ width: 20, height: 20 }}
                                />
                              </TouchableOpacity>
                            </View>
                          </View>
                        ) : null}
                      </View>
                      <View style={styles.productAmountContainer}>
                        {/* <TouchableOpacity 
                             onPress={()=> {
                                console.log('Position CLick>>',item.product_id)
                                
                              ///  SetshowWarning(true);
                                //setShouldShow(true)
                            //    setexixtingitemShow(!exixtingitemShow)
                                }}>
                           <Text style={styles.productEditText}>Edit</Text>
                         </TouchableOpacity> */}
                        {/* <TouchableOpacity 
                             onPress={()=> {
                                  let productid=item.product_id;
                                   let quantity=item.quantity;
                                   var  is_active =false;
                                   let product_delivery_type=item.product_delivery_type;
                                   let product_variation_type=item.product_variation_type;
                                   let product_variation_value=item.product_variation_value;
                                   let product_coupon_code= item.product_coupon_code;
                                   let delivery_start_date= item.delivery_start_date;
                                   let delivery_end_date=item.delivery_end_date;
                                   let delivery_time_slot=item.delivery_time_slot;
                                   var auto_renew_subscription=item.auto_renew_subscription;
                                   let milk_delivery_type= item.milk_delivery_type;
                                   let milk_delivery_slot= item.milk_delivery_slot;
                                   let additional_rule_json= item.additional_rule_json;
                                   deleteItem(productid,quantity,is_active,product_delivery_type,product_variation_type,
                                    product_variation_value,product_coupon_code,delivery_start_date,delivery_end_date,
                                    delivery_time_slot,auto_renew_subscription,milk_delivery_type,milk_delivery_slot,additional_rule_json);
                                        }}>
                            <Image source={images.deleteIcon} style={{
                                    resizeMode: 'cover',
                                    width: 20,
                                    height: 20,
                                    justifyContent: 'flex-end',
                                    marginTop: 40,
                                }} />
                         </TouchableOpacity> */}
                      </View>
                    </View>
                  </View>
                </View>
              </View>
            </React.Fragment>
          );
        })}

      {/*  */}
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  productContainer: {
    flex: 1,
    width: "100%",
    minHeight: 93,
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    marginTop: 5,
    flexWrap: "wrap",
  },
  productSubContainer: {
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    marginTop: 5,
    backgroundColor: "#fff",
    flexWrap: "wrap",
  },
  productInnerContainer: {
    flexDirection: "row",
    width: "100%",
    flexWrap: "wrap",
  },
  productDetailContainer: {
    width: "100%",
    height: "100%",
    // padding: 5,
    flexWrap: "wrap",
  },
  productAmountContainer: {
    width: "20%",
    height: "100%",
    paddingTop: 11,
    alignItems: "center",
  },
  productEditText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 14,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 15.3,
    letterSpacing: 0,
    textAlign: "right",
    color: "#3d3cb3",
  },
  productNameText: {
    fontFamily: "Montserrat-ExtraBold",
    fontSize: 12,
    fontWeight: "800",
    fontStyle: "normal",
    lineHeight: 16.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#332b55",
  },
  productQtyText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 12,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 16.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "rgb(51, 43, 85)",
  },
  productPlanTypeText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 12,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 16.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "rgb(51, 43, 85)",
  },
  productAmountText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 14,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 15.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#5a5862",
  },
  productAmountDateText: {
    opacity: 0.6,
    fontFamily: "Montserrat-Regular",
    fontSize: 9,
    fontWeight: "normal",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "center",
    color: "#3b3b3b",
  },
  productAmountDateText1: {
    //opacity: 0.6,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 9,
    fontWeight: "normal",
    fontStyle: "normal",
    letterSpacing: 0.5,
    //textAlign: "center",
    color: "#3b3b3b",
  },
  productAmountButton: {
    width: 81,
    // height: 14,
    borderRadius: 4,
    backgroundColor: "#52b69a",
    justifyContent: "center",
    alignItems: "center",
    padding: 2,
  },
  productStatusText: {
    alignSelf: "center",
    fontFamily: "Montserrat-SemiBold",
    fontSize: 9,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 11.8,
    letterSpacing: 0,
    // textAlign: "left",
    color: "#ffffff",
  },
  body: {
    flex: 1,
    backgroundColor: "#ffffff",
    alignItems: "center",
  },
  text: {
    color: "#ffffff",
    fontSize: 20,
    margin: 10,
    textAlign: "center",
  },
  input: {
    width: 200,
    borderWidth: 1,
    borderColor: "#555",
    borderRadius: 5,
    textAlign: "center",
    fontSize: 20,
    marginBottom: 10,
  },
  button: {
    width: 150,
    height: 50,
    alignItems: "center",
  },
  centered_view: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#00000099",
  },
  warning_modal: {
    width: 300,
    height: 300,
    backgroundColor: "#ffffff",
    borderWidth: 1,
    borderColor: "#000",
    borderRadius: 20,
  },
  warning_title: {
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#3d3cb3",
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
  },
  warning_body: {
    height: 200,
    justifyContent: "center",
    alignItems: "center",
  },
  warning_button: {
    backgroundColor: "#3d3cb3",
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
});

export default CheckoutFullCardView;
