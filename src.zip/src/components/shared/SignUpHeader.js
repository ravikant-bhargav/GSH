import React, { useRef, useEffect } from 'react';


import {
    SafeAreaView,
    Image,
    Text,
    View,
    StyleSheet,
    Dimensions,
    Animated,
    StatusBar,
    TouchableOpacity
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

import appColors from './../../utils/appColors';
import images from './../../utils/sharedImages';


const SignUpHeader = ({ showBackArrow, navScreen }) => {

    const goBack = () => {
        navScreen.goBack();
    }
    return (
        <React.Fragment>
            <LinearGradient
                colors={['#3d3cb3', 'rgba(61, 60, 179, 0.73)']}
                style={styles.containerHeader}
            >
                <View style={styles.mainContainer}>
                    {showBackArrow && (

                        <View style={styles.leftIconContainer}>
                            <TouchableOpacity onPress={() => { goBack() }} >
                                <Image source={images.BackArrowWhite} style={styles.leftIconImage} />
                            </TouchableOpacity>
                        </View>


                    )}
                    
                </View>

            </LinearGradient>

            <View style={styles.imageContainer}>
                <View style={styles.imageInnerContainer}>
                    <Image
                        source={images.LogoFull}
                        style={styles.image}
                    />
                </View>
            </View>
        </React.Fragment>


    );
};

export const styles = StyleSheet.create({
    containerHeader: {
        height: 178,
    },
    mainContainer: {
        flexDirection: 'row',
        height: 120,
        width: "100%",
        alignItems: 'center',
        justifyContent: 'center',
        top: 10

    },
    leftIconContainer: {
        left: 15,
        position: 'absolute',
        width: '20%',
        height: 60

    },
    leftIconImage: {
        width: 43,
        height: 43,
        shadowColor: "rgba(0, 0, 0, 0.25)",
        shadowOffset: {
            width: 0,
            height: 4
        },
        shadowRadius: 4,
        shadowOpacity: 1,

    },
    imageContainer: {
        position: "absolute",
        zIndex: 1,
        alignSelf: 'center',
        justifyContent: 'center',
        flex: 1,
        top: 80,
        width: 150,
        height: 150,
    },
    imageInnerContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        alignSelf: 'center'
    },
    image: {
        width: 250,
        height: 250,
        shadowColor: "rgba(0, 0, 0, 0.25)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 7,
        shadowOpacity: 1,
        resizeMode: 'cover'

    },

});

export default (SignUpHeader);