import { useDrawerProgress } from "@react-navigation/drawer";
import React, { useRef, useEffect } from "react";

import {
  SafeAreaView,
  Image,
  Text,
  View,
  StyleSheet,
  Dimensions,
  Animated,
  StatusBar,
  TouchableOpacity,
} from "react-native";
import HorizontalLine from "../HorizontalLine";
import Icon from "react-native-vector-icons/AntDesign";
import appColors from "./../../utils/appColors";
import images from "./../../utils/sharedImages";

const DashboardHeader = (props) => {
  return (
    <React.Fragment>
      <View style={[styles.container, props.headerContainerStyle]}>
        <View
          style={[
            styles.leftSpace,
            {
              width:
                props.headerTitle &&
                props.headerTitle !== "" &&
                props.headerTitle.length >= 20
                  ? "20%"
                  : "30%",
            },
          ]}
        >
          {(props.showBackArrow && props.showBackArrow === true && (
            <TouchableOpacity onPress={props.onPress}>
              <View style={styles.backArrowContainer}>
                <Image
                  source={images.BackArrow}
                  style={[
                    styles.leftIconImage,
                    { width: 43, height: 43, marginLeft: 5 },
                  ]}
                />
              </View>
            </TouchableOpacity>
          )) || (
            <React.Fragment>
              {props.drawerStatus === 1 ? (
                <TouchableOpacity
                  onPress={props.onPressToggle}
                  style={styles.leftIconContainer}
                >
                  <Image
                    source={images.CrossIcon}
                    style={styles.leftIconImage}
                  />
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  onPress={props.onPressToggle}
                  style={styles.leftIconContainer}
                >
                  <Image
                    source={images.menuIcon}
                    style={styles.leftIconImage}
                  />
                </TouchableOpacity>
              )}

              <View style={styles.leftIconContainer}>
                <Image
                  source={images.bellIcon}
                  style={styles.leftIconBellImage}
                />
              </View>
            </React.Fragment>
          )}
        </View>
        <View style={styles.pageTitle} />
        <View
          style={[
            styles.rightIconContainer,
            {
              width:
                props.headerTitle &&
                props.headerTitle !== "" &&
                props.headerTitle.length >= 20
                  ? "80%"
                  : "70%",
            },
          ]}
        >
          {(props.headerTitle && props.headerTitle !== "" && (
            <React.Fragment>
              <Text style={styles.headerText}>
                {props.headerTitle &&
                  props.headerTitle !== "" &&
                  props.headerTitle}
              </Text>
            </React.Fragment>
          )) ||
            null}
          {(props.headerTitle1 &&
            props.headerTitle1 !== "" &&
            props.dropDownIcon &&
            props.dropDownIcon === true && (
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "flex-end",
                  alignItems: "center",
                }}
              >
                <Text style={styles.headerText1}>
                  {(props.headerTitle1 &&
                    props.headerTitle1 !== "" &&
                    props.headerTitle1) ||
                    " "}
                </Text>
                <TouchableOpacity
                  style={styles.dropDownIconContainer}
                  onPress={props.dropDownIconPress}
                >
                  <Image
                    source={images.chevronDown}
                    style={{
                      width: 10,
                      height: 8,
                      tintColor: "#ffffff",
                    }}
                  />
                </TouchableOpacity>
              </View>
            )) ||
            null}

          {(props.headerTitle1 &&
            props.headerTitle1 !== "" &&
            props.pencilEditIcon &&
            props.pencilEditIcon === true && (
              <React.Fragment>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "flex-end",
                    alignItems: "center",
                  }}
                >
                  <Text style={styles.headerText2} numberOfLines={1}>
                    {(props.headerTitle1 &&
                      props.headerTitle1 !== "" &&
                      props.headerTitle1) ||
                      " "}
                  </Text>
                  <TouchableOpacity
                    onPress={props.onEditclick}
                    style={{
                      width: 20,
                      height: 20,
                      backgroundColor: "grey",
                      borderRadius: 14,
                      alignContent: "center",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Image
                      source={images.chevronDown}
                      style={{
                        width: 10,
                        height: 10,
                        resizeMode: "cover",
                      }}
                    />
                  </TouchableOpacity>
                </View>
              </React.Fragment>
            )) ||
            null}

          {props.likeIcon &&
            props.likeIcon === true &&
            props.likeiconhallow === true && (
              <TouchableOpacity
                onPress={props.onPressLike}
                style={{
                  alignItems: "flex-end",
                  marginRight: 10,
                }}
              >
                <Image
                  source={images.likeIcon}
                  style={[styles.leftIconImage, { width: 27, height: 27 }]}
                />
              </TouchableOpacity>
            )}
          {props.likeIcon &&
            props.likeIcon === true &&
            props.likeiconhallow === false && (
              <TouchableOpacity
                onPress={props.onPressLike}
                style={{
                  alignItems: "flex-end",
                  marginRight: 10,
                }}
              >
                <Image
                  source={images.disLike}
                  style={[styles.leftIconImage, { width: 27, height: 27 }]}
                />
              </TouchableOpacity>
            )}
        </View>
      </View>
      {/* <HorizontalLine /> */}
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: 70,
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    backgroundColor: "#f6f6f6",
  },
  leftSpace: {
    // justifyContent: 'space-around',
    flexDirection: "row",
    width: "30%",
  },
  backArrowContainer: {
    // borderColor: 'green',
    // borderWidth: 2
  },
  leftIconContainer: {
    justifyContent: "center",
    alignItems: "center",
    //marginRight:18,
    width: "40%",
  },
  leftIconImage: {
    width: 35,
    height: 35,
  },
  leftIconBellImage: {
    width: 19.5,
    height: 22,
  },
  pageTitle: {
    // width: "5%",
  },

  rightIconContainer: {
    width: "70%",
    justifyContent: "flex-end",
  },

  headerText: {
    fontFamily: "Montserrat-Medium",
    fontSize: 23,
    fontStyle: "normal",
    lineHeight: 25.2,
    letterSpacing: 0,
    textAlign: "right",
    color: "rgb(61, 60, 179)",
  },
  headerText1: {
    fontFamily: "Montserrat-Bold",
    fontSize: 20,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 25.2,
    letterSpacing: 0,
    textAlign: "right",
    color: "rgb(61, 60, 179)",
  },
  headerText2: {
    fontFamily: "Montserrat-Bold",
    fontSize: 14,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 25.2,
    letterSpacing: 0,
    textAlign: "right",
    color: "rgb(61, 60, 179)",
    flexWrap: "wrap",
    width: 140,
  },
  dropDownIconContainer: {
    width: 20,
    height: 20,
    backgroundColor: "#3d3cb3",
    borderRadius: 20,
    marginLeft: 10,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default DashboardHeader;
