import React, { useRef, useEffect } from "react";

import {
  SafeAreaView,
  Image,
  Text,
  View,
  StyleSheet,
  Dimensions,
  Animated,
  StatusBar,
  TouchableOpacity,
} from "react-native";
import { useDispatch } from "react-redux";
import { setAppLanguage } from "../../screens/onboarding/OnBoardingReducer";

import appColors from "./../../utils/appColors";
import images from "./../../utils/sharedImages";

const OnBoardingHeader = ({ navScreen, skipInactive, ID, uData }) => {
  return (
    <View style={styles.container}>
      <View style={styles.leftIconContainer}>
        {/* <Text style={styles.headerText}>Skip > </Text> */}
      </View>
      <View style={styles.pageTitle}>
        {/* <Text style={styles.headerText}>Language </Text> */}
      </View>
      <TouchableOpacity
        style={styles.rightIconContainer}
        onPress={() =>
          // skipInactive === true
          //   ? alert("Select your preferred language.")
          // :
          {
            navScreen.navigate("SignUpStack");
          }
        }
      >
        <Text style={styles.headerText}>Skip </Text>
        <Image source={images.chevronRight} style={styles.righticonImage} />
      </TouchableOpacity>
    </View>
  );
};

export const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: 60,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: appColors.WHITE,
  },
  headerText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 14,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 25.3,
    letterSpacing: 0,
    textAlign: "center",
    color: appColors.HEADER_TEXT_COLOR,
  },
  pageTitle: {
    width: "50%",
  },

  leftIconContainer: {
    width: "20%",
    justifyContent: "flex-start",
  },
  rightIconContainer: {
    // width: "20%",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    justifyContent: "flex-end",
  },

  righticonImage: {
    width: 11,
    height: 11,
    tintColor: "#000",
  },
});

export default OnBoardingHeader;
