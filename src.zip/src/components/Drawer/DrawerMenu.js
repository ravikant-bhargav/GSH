/* eslint-disable react-native/sort-styles */
/* eslint-disable import/order */
import React from 'react';
import { Image, StyleSheet, Block, Button, Text, View } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import {
  DrawerItem,
  createDrawerNavigator,
  DrawerContentScrollView,
  useDrawerProgress
} from '@react-navigation/drawer';
// import Animated,{
//   interpolate,
//   interpolateNode,
// }  from 'react-native-reanimated';

import Animated, {
  useAnimatedStyle,
  interpolate,
  interpolateNode,
  Extrapolate
} from 'react-native-reanimated';

import LinearGradient from 'react-native-linear-gradient';

// screens
import Dashboard from '../../screens/dashboard';
import Category from '../../screens/category/';
import CategoryByProduct from '../../screens/category/CategoryByProduct';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

const Screens = ({ navigation, style }) => {
  const progress = useDrawerProgress();
  const scale = Animated.interpolateNode(progress.value, {
    inputRange: [0, 10],
    outputRange: [0.8, 0],
    extrapolate: Extrapolate.CLAMP,
  });
  const borderRadius = Animated.interpolateNode(progress.value, {
    inputRange: [0, 1],
    outputRange: [1, 20],
    extrapolate: Extrapolate.CLAMP,
  });
  const animatedStyle = {
    borderRadius,
    transform: [{ scale }],
  };
  return (
    <Animated.View style={[{ flex: 1 }, animatedStyle]}>
      <Stack.Navigator
        screenOptions={{
          headerTransparent: true,
          headerTitle: null,
          // headerLeft: () => (
          //   <View transparent onPress={() => navigation.openDrawer()}>
          //     <Text>Menu</Text>
          //   </View>
          // ),
        }}
      >
        <Stack.Screen name="Category" component={Category} />
        <Stack.Screen name="CategoryByProduct" component={CategoryByProduct} />
      </Stack.Navigator>
    </Animated.View>
  );
};

const DrawerContent = props => {

  const progress = useDrawerProgress();

  const translateX = Animated.interpolateNode(progress.value, {
    inputRange: [0, 1],
    outputRange: [-100, 0],
  });
  // setProgress(progress);
  // console.log('progress', progress)
  return (
    
      <DrawerContentScrollView {...props} scrollEnabled={false} contentContainerStyle={{}}>
        <Animated.View style={{ transform: [{ translateX }] }}>
        <View>

          <View>
            <DrawerItem
              label="Dashboard"
              labelStyle={styles.drawerLabel}
              // style={styles.drawerItem}
              onPress={() => props.navigation.navigate('Home')}
            // icon={() => <AntDesign name="dashboard" color="white" size={16} />}
            />
            <DrawerItem
              label="Messages"
              labelStyle={{ color: 'white', }}
              style={{}}
              onPress={() => props.navigation.navigate('Messages')}
            // icon={() => <AntDesign name="message1" color="white" size={16} />}
            />
            <DrawerItem
              label="Contact us"
              labelStyle={{ color: 'white', }}
              style={{}}
              onPress={() => props.navigation.navigate('Contact')}
            // icon={() => <AntDesign name="phone" color="white" size={16} />}
            />
          </View>
        </View>

        <View >
          <DrawerItem
            label="Logout"
            labelStyle={{ color: 'white' }}
            //icon={() => <AntDesign name="logout" color="white" size={16} />}
            onPress={() => alert('Are your sure to logout?')}
          />
        </View>
        </Animated.View>
      </DrawerContentScrollView>
    
  )


};

export default DrawerMenu = () => {
  const [progress, setProgress] = React.useState(new Animated.Value(0));



  // const scale = Animated.interpolateNode(progress, {
  //   inputRange: [0, 1],
  //   outputRange: [1, 10],
  // });
  // const borderRadius = interpolateNode(progress, {
  //   inputRange: [0, 1],
  //   outputRange: [0, 16],
  // });

  console.log('progress', progress)

  const animatedStyle = useAnimatedStyle(() => {
    // const progress = useDrawerProgress();
    const scale = interpolate(0, [0, 1], [0.9, 10]);

    const borderRadius = interpolate(0, [0, 1], [0, 12]);

    return {
      borderRadius,
      transform: [{ scale }],
    };
  }, []);



  return (
    <LinearGradient style={{ flex: 1 }} colors={['#E94057', '#4A00E0']}>
      <Drawer.Navigator
        hideStatusBar
        initialRouteName={"Dashboard"}
        drawerType="slide"
        overlayColor="transparent"
        drawerStyle={styles.drawerStyles}
        contentContainerStyle={{}}
        drawerContentOptions={{
          activeBackgroundColor: 'transparent',
          activeTintColor: 'green',
          inactiveTintColor: 'green',
        }}
        screenOptions={{
          headerShown: false,
          drawerStyle: {
            flex: 1,
            width: '60%',
            backgroundColor: 'red',
          },
          drawerType: 'slide',
          overlayColor: 'transparent',
          sceneContainerStyle: {
            backgroundColor: 'red',
          },
        }}
        //sceneContainerStyle={{ backgroundColor: 'green' }}
        drawerContent={props => {
          setProgress(props.progress);
          return <DrawerContent {...props} />;
        }}

      // drawerContent={(props) => <DrawerContent {...props} />}
      >
        <Drawer.Screen name="Screens">
          {props => <Screens {...props} style={animatedStyle} />}
        </Drawer.Screen>
      </Drawer.Navigator>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  stack: {
    flex: 1,
    shadowColor: '#FFF',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.44,
    shadowRadius: 10.32,
    elevation: 5,
    overflow: 'scroll',
    // borderWidth: 1,
  },
  drawerStyles: { flex: 1, width: '20%', backgroundColor: 'blue' },
  drawerItem: { alignItems: 'flex-start', marginVertical: 0 },
  drawerLabel: { color: 'white', marginLeft: -16 },
  avatar: {
    borderRadius: 60,
    marginBottom: 16,
    borderColor: 'white',
    borderWidth: StyleSheet.hairlineWidth,
  },
});