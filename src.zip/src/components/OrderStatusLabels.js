import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
} from "react-native";

const OrderStatusLabels = (props) => {
  return (
    <React.Fragment>
      <View style={styles.orderStatusContainer}>
        <View style={styles.orderStatusElement}>
          <View
            style={[
              styles.orderStatusIndicator,
              { backgroundColor: "#14b661" },
            ]}
          />
          <Text style={styles.orderStatusText}>Delivered</Text>
        </View>
        <View style={styles.orderStatusElement}>
          <View
            style={[
              styles.orderStatusIndicator,
              { backgroundColor: "rgb(255, 126, 112)" },
            ]}
          />
          <Text style={styles.orderStatusText}>Cancelled</Text>
        </View>
        <View style={styles.orderStatusElement}>
          <View
            style={[
              styles.orderStatusIndicator,
              { backgroundColor: "rgb(69, 125, 210)" },
            ]}
          />
          <Text style={styles.orderStatusText}>Upcoming</Text>
        </View>
        <View style={styles.orderStatusElement}>
          <View
            style={[
              styles.orderStatusIndicator,
              { backgroundColor: "rgb(234, 181, 10)" },
            ]}
          />
          <Text style={styles.orderStatusText}>On hold</Text>
        </View>
      </View>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  orderStatusContainer: {
    width: "100%",
    marginTop: 7,
    flexDirection: "row",
    justifyContent: "center",
  },

  orderStatusElement: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    width: "25%",
  },
  orderStatusIndicator: {
    width: 22,
    height: 5,
    borderRadius: 22,
  },
  orderStatusText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 11,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 12,
    letterSpacing: 0,
    color: "rgb( 105, 105, 105)",
  },
});

export default OrderStatusLabels;
