import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
} from 'react-native';


const HorizontalLine = (props) => {

    return (
        <React.Fragment>
            <View style={[styles.horzontalLine,props.customStyle]} />
        </React.Fragment>


    );
};

export const styles = StyleSheet.create({
    horzontalLine: {
        height: 1,
        marginTop: 6,
        backgroundColor: "rgba(0, 0, 0, 0.14)"
    },




});

export default HorizontalLine;