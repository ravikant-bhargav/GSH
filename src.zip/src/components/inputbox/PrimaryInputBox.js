import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
} from 'react-native';
import images from '../../utils/sharedImages';

const rupeyCode = "&#8377";
const PrimaryInputBox = (props) => {

    return (
        <React.Fragment>
            <View style={styles.serachBoxContainer}>
                <Image source={images.SearchIcon} style={styles.searchButton} />
                <TextInput
                    style={styles.serachInputContainer}
                    onChangeText={props.onChangeNumber}
                    value={props.value}
                    placeholder={props.placeholderText || ''}
                    placeholderTextColor={"#000000"}
                />
            </View>

        </React.Fragment>


    );
};

export const styles = StyleSheet.create({
    serachBoxContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: "rgba(194,194,194,0.27)",
        marginTop: 20,
        height: 45,
        borderRadius: 10,
    },
    searchButton: { 
        width: 25, 
        height: 25, 
        margin: 10, 
    },
    serachInputContainer: {
        flex: 1,
        paddingTop: 10,
        paddingRight: 10,
        paddingBottom: 10,
        paddingLeft: 0,
        fontFamily: "Montserrat-Medium",
        fontSize: 14,
        fontWeight: "500",
        fontStyle: "normal",
        lineHeight: 15.3,
        letterSpacing: 0,
        color: "#000000",
    },



});

export default PrimaryInputBox;