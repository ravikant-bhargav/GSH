import React, { useRef, useEffect } from 'react';


import {
    SafeAreaView,
    Image,
    Text,
    View,
    StyleSheet,
    Dimensions,
    Animated,
    StatusBar,
    TouchableOpacity
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';




const LinearGradientView = (props) => {

   
    return (
        <React.Fragment>
            <LinearGradient
                colors={props.colors}
                style={props.wrapperStyle}
            >
                {props.children}
            </LinearGradient>
        </React.Fragment>


    );
};

export const styles = StyleSheet.create({

});

export default (LinearGradientView);