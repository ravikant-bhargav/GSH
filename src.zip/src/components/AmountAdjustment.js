import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
} from "react-native";

const rupeyCode = "&#8377";
const AmountAdjustment = (props) => {
  return (
    <React.Fragment>
      <View style={[styles.amountContainer, {}]}>
        <View style={styles.amountInnerContainerLeft}>
          <Text style={styles.amountText}>Adjustment amount:</Text>
          <Text style={styles.amountValue}>
            <Text style={{ width: 12, height: 12 }}>&#8377;</Text>{" "}
            {props.adjustment_Amount}
          </Text>
        </View>
        <View style={styles.amountInnerContainerRight}>
          <Text style={styles.buttonText}>View Calendar</Text>
        </View>
      </View>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  amountContainer: {
    marginTop: 10,
    flexDirection: "row",
  },
  amountInnerContainerLeft: {
    width: "50%",
    paddingLeft: 5,
    paddingtop: 5,
  },
  amountInnerContainerRight: {
    width: "50%",
    justifyContent: "flex-start",
    alignItems: "flex-end",
    paddingTop: 10,
  },
  amountText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 13,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 15.7,
    letterSpacing: 0,
    color: "#09051c",
  },
  amountValue: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 19.7,
    letterSpacing: 0,
    color: "#3d3cb3",
  },
  buttonText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 12,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 15.7,
    letterSpacing: 0,
    color: "#3d3cb3",
    marginRight: 3,
  },
});

export default AmountAdjustment;
