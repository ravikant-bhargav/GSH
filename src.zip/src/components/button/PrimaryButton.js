import React, { useRef, useEffect } from "react";

import {
  SafeAreaView,
  Image,
  Text,
  View,
  StyleSheet,
  Dimensions,
  Animated,
  StatusBar,
  TouchableOpacity,
} from "react-native";

import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";

const PrimaryButton = (props) => {
  return (
    <View
      style={[
        props.overRideNewCss && props.overRideNewCss === true
          ? [styles.buttonContainerOverRide, props.buttonContainerOverRide]
          : [styles.buttonContainer, props.btnStyleMain],
      ]}
    >
      <TouchableOpacity onPress={props.onPress}>
        <View style={[styles.buttonAlignment, props.btnStyle]}>
          {(props.showImage && (
            <Image
              source={props.imageIcon || images.plusIcon}
              style={[styles.imageButton, props.btnImgStyle]}
            />
          )) ||
            null}

          <Text style={[styles.buttonText, props.btnTextStyle]}>
            {props.buttonText || "Dashboard"}
          </Text>
          {(props.showRightImage && (
            <Image
              source={props.imageIcon || images.plusIcon}
              style={[styles.imageButton, props.btnImgStyle]}
            />
          )) ||
            null}
        </View>
      </TouchableOpacity>
    </View>
  );
};

export const styles = StyleSheet.create({
  buttonContainer: {
    // flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10,
    marginBottom: 10,
  },
  buttonContainerOverRide: {
    // flex: 1,
    justifyContent: "center",
    //alignItems: 'center',
    marginTop: 10,
    marginBottom: 10,
  },
  buttonAlignment: {
    width: 210,
    height: 45,
    borderRadius: 10,
    backgroundColor: "#3d3cb3",
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 12,
      height: 26,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  buttonText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 15,
    fontWeight: "bold",
    fontStyle: "normal",
    letterSpacing: 0.5,
    // textAlign: "left",
    color: "#ffffff",
  },
  imageButton: {
    width: 26,
    height: 26,
    tintColor: "#fff",
    marginRight: 6,
  },
});

export default PrimaryButton;
