import React, { useRef, useEffect } from "react";

import {
  SafeAreaView,
  Image,
  Text,
  View,
  StyleSheet,
  Dimensions,
  Animated,
  StatusBar,
  TouchableOpacity,
} from "react-native";

import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";

const PrimaryButtonResize = (props) => {
  return (
    <TouchableOpacity
      onPress={props.onPress}
      style={[styles.btnStyle, props.btnCustomStyle]}
      disabled={props.disabled}
    >
      <Text style={[styles.btnTextStyle, props.btnTextStyle]}>
        {props.btnText}
      </Text>
    </TouchableOpacity>
  );
};

export const styles = StyleSheet.create({
  btnStyle: {
    height: 33,
    borderRadius: 58,
    backgroundColor: "#3d3cb3",
    borderStyle: "solid",
    borderWidth: 2,
    borderColor: "#3d3cb3",
    paddingLeft: 10,
    paddingRight: 10,
    justifyContent: "center",
    alignItems: "center",
    margin: 6,
  },
  btnTextStyle: {
    fontFamily: "Montserrat-Bold",
    fontSize: 13,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 14.2,
    letterSpacing: 0,
    color: "#ffffff",
  },
});

export default PrimaryButtonResize;
