import React, { useRef, useEffect } from 'react';


import {
    SafeAreaView,
    Image,
    Text,
    View,
    StyleSheet,
    Dimensions,
    Animated,
    StatusBar,
    TouchableOpacity
} from 'react-native';

import appColors from '../../utils/appColors';
import images from '../../utils/sharedImages';


const AppButton = (props) => {

    return (


        <TouchableOpacity onPress={props.onPress} style={[styles.buttonContainer, props.btnContainer]}>
            <View style={[styles.buttonAlignment, props.btnStyle]}>
                {props.showImage && props.showImage === true && (
                    <Image
                        source={images.googleIcon}
                        style={styles.imageButton}
                    />
                )}

                <Text style={[styles.buttonText, props.btnTextStyle]}>{props.btnText}</Text>
            </View>
        </TouchableOpacity>




    );
};

export const styles = StyleSheet.create({
    buttonContainer: {
        // flex: 1,
        justifyContent: 'center',
        height: 51,
        borderRadius: 12,
        borderStyle: "solid",
        borderWidth: 2,
        borderColor: "rgb(61, 60, 179)",
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10

    },
    buttonAlignment: {

        backgroundColor: "#ffffff",
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        // padding:10

    },
    buttonText: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 15,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 19.7,
        letterSpacing: 0,
        textAlign: "left",
        color: "rgb(61, 60, 179)"

    },
    imageButton: {
        width: 28.3,
        height: 29,
        borderRadius: 5,
        shadowColor: "rgba(0, 0, 0, 0.09)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 4,
        shadowOpacity: 1,
        marginRight: 15
    }

});

export default AppButton;