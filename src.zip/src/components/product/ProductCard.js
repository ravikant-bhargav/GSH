import React, { useRef, useEffect } from 'react';


import {
    SafeAreaView,
    Image,
    Text,
    View,
    StyleSheet,
    Dimensions,
    Animated,
    StatusBar,
    TouchableOpacity
} from 'react-native';

import appColors from '../../utils/appColors';
import images from '../../utils/sharedImages';
import HorizontalLine from '../HorizontalLine';


const ProductCard = (props) => {
    return (
        <TouchableOpacity style={styles.featuredProductDetail} onPress={props.onPress}>
            <View style={styles.imageView}>
                <Image source={{uri:props.image}} style={{ width: 100, height: 100, alignItems: 'center' }} />
            </View>
            <HorizontalLine />
            <View style={styles.productDetail}>
                <View style={styles.productfirstLineContainer}>
                    <Text style={styles.productNameStyle}>{props.name}</Text>
                    <Text style={styles.productQtyStyle}>{props.quantity}</Text>
                    <Text style={styles.productQtyStyle}>{props.amount}</Text>
                </View>
                <View style={styles.productAddButton}>
                    <Text style={styles.productAddText}>Add</Text>
                    <Image source={images.AddButton} style={{ width: 14, height: 14, resizeMode: 'cover' }} />
                </View>
            </View>
        </TouchableOpacity>




    );
};

export const styles = StyleSheet.create({
    featuredProductDetail: {
        flexBasis: '45%',
        width: 160.8,
        height: 180.8,
        borderRadius: 8,
        backgroundColor: "#ffffff",
        shadowColor: "rgba(90, 108, 234, 0.07)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 6,
        shadowOpacity: 1,
        margin: 8,


    },
    imageView: {
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
        height: "70%"
    },
    productDetail: {
        height: "30%",
        padding: 5,
        flexDirection: 'row',
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center'

    },
    productNameStyle: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 10,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 11.1,
        letterSpacing: 0,
        color: "#000000",
        margin: 1

    },
    productQtyStyle: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 8,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 8.6,
        letterSpacing: 0,
        color: "#000000",
        margin: 1
    },
    productAddButton: {
        width: 52.2,
        height: 23.9,
        borderRadius: 5,
        backgroundColor: "rgba(20, 182, 97, 0.65)",
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
    },
    productAddText: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 10,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 11.1,
        letterSpacing: 0,
        textAlign: "left",
        color: "#ffffff",
        marginRight: 3
    },
    productfirstLineContainer: {
        flex: 1,
        justifyContent: 'space-evenly'
    },

});

export default ProductCard;