import { View, Text } from "react-native";
import React, { useEffect, useState } from "react";
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete";
import MapView, { Marker, enableLatestRenderer } from "react-native-maps";
import { StyleSheet } from "react-native";
import { onChange } from "react-native-reanimated";

const MapComponent = (props) => {
  //   useEffect(() => {
  //     requestLocationPermission();
  //   }, []);

  //   const requestLocationPermission = async () => {
  //     try {
  //       const granted = await PermissionsAndroid.request(
  //         PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
  //         {
  //           title: "App Location Permission",
  //           message: "App need to access your location",
  //           buttonNeutral: "Ask me later",
  //           buttonPositive: "Ok",
  //           buttonNegative: "Cancel",
  //         }
  //       );
  //       console.log(">>>>>>>>>>>>>", granted);
  //       if (granted === PermissionsAndroid.RESULTS.GRANTED) {
  //         console.log("You can use the location");
  //         getCurrentPosition();
  //       } else {
  //         console.log("location permission denied");
  //       }
  //     } catch (err) {
  //       console.warn(err);
  //     }
  //   };

  //   const getCurrentPosition = () => {
  //     setIsLoading(true);
  //     Geolocation.getCurrentPosition(
  //       (pos) => {
  //         console.log("POS///////////", pos);
  //         setTimeout(() => {
  //           const latitude = pos.coords.latitude;
  //           const longitude = pos.coords.longitude;
  //           setLattitude(latitude);
  //           setLongitude(longitude);
  //           setIsLoading(false);
  //         }, 3000);
  //       },
  //       (error) => Alert.alert("GetCurrentPosition Error", JSON.stringify(error)),
  //       { enableHighAccuracy: true }
  //     );
  //   };

  const [lattitude_value, setLattitude] = useState(props.lattitude_value);
  const [longitude_value, setLongitude] = useState(props.longitude_value);
  console.log("djbhjfdbjdf", lattitude_value, longitude_value);
  return (
    <View style={{ flex: 1 }}>
      <View
        style={{
          height: 40,
          justifyContent: "center",
        }}
      >
        <GooglePlacesAutocomplete
          placeholder="Type a place"
          styles={{
            textInput: {
              height: 38,
              color: "#5d5d5d",
              fontSize: 16,
              backgroundColor: "transparent",
              borderRadius: 12,
              borderStyle: "solid",
              borderWidth: 2.5,
              borderColor: "#A8A8A8",
            },
          }}
          onPress={(data, details = null) => console.log(data, details)}
          query={{
            key: "AIzaSyAg7HTmUqhU5MWT8V2VOu8JBQC62LKPZy4",
          }}
          fetchDetails={true}
          onFail={(error) => console.log(error)}
          onNotFound={() => console.log("no results")}
          listEmptyComponent={() => (
            <View style={{ flex: 1 }}>
              <Text>No results were found</Text>
            </View>
          )}
        />
      </View>
      <View style={{ height: 400 }}>
        <MapView
          // provider={PROVIDER_GOOGLE} // remove if not using Google Maps
          style={styles.map}
          showsUserLocation={true}
          showsMyLocationButton={true}
          zoomEnabled={true}
          zoomControlEnabled={true}
          followsUserLocation={true}
          region={{
            latitude: lattitude_value,
            longitude: longitude_value,
            latitudeDelta: 0.015,
            longitudeDelta: 0.0121,
          }}
        >
          <Marker
            coordinate={{
              latitude: lattitude_value,
              longitude: longitude_value,
              latitudeDelta: 0.015,
              longitudeDelta: 0.0121,
            }}
            draggable
            onDragEnd={(e) => {
              console.log("e>>>>>>>>", e.nativeEvent);
              setLattitude(e.nativeEvent.coordinate.latitude);
              setLongitude(e.nativeEvent.coordinate.longitude);
              props.onChange(
                e.nativeEvent.coordinate.latitude,
                e.nativeEvent.coordinate.longitude
              );
            }}
          />
        </MapView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  map: {
    ...StyleSheet.absoluteFillObject,
  },
});
export default MapComponent;
