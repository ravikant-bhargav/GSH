import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
} from "react-native";

//import HorizontalLine from '../../components/HorizontalLine';
import images from "../utils/sharedImages";

const rupeyCode = "&#8377";
const WiseListCard = (props) => {
  console.log("wiselist", props);

  const closeModal = (Itemid) => {
    
    props.getIdDelete(Itemid);
  };

  return (
    <React.Fragment>
      {/* {props.iten &&
        props.iten.length > 0 &&
        props.iten.map((item, index) => {
          console.log("order>>", item.wishlist_product.name);
          let price = 0;
          if (item.wishlist_product.is_on_sale == true) {
            price = item.wishlist_product.special_sale_price;
          } else {
            price = item.wishlist_product.max_retail_price;
          }

          return ( */}
      <View style={styles.productContainer}>
        <View style={styles.productSubContainer}>
          <View style={[styles.productInnerContainer, { height: "100%" }]}>
            <View
              style={[styles.productDetailContainer, { flexDirection: "row" }]}
            >
              <View
                style={{
                  width: "20%",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Image
                  source={{
                    uri: props.nav.wishlist_product.product_images[0].url,
                  }}
                  style={{
                    resizeMode: "cover",
                    width: 72,
                    height: 57,
                  }}
                />
              </View>

              <View
                style={{
                  width: "55%",
                  justifyContent: "flex-start",
                  padding: 10,
                }}
              >
                <Text style={styles.productNameText}>
                  {props.nav.wishlist_product.name}
                </Text>
                {/* <Text style={[styles.productNameText, { marginTop: 8 }]}>
                  {props.nav.wishlist_product.description}
                </Text> */}
                {/* <Text style={[styles.productPlanTypeText, { marginTop: 8 }]}>
                                    Plan Type:<Text style={{ fontFamily: "Montserrat-Bold", opacity: 1, }}>{}</Text>
                                </Text> */}
              </View>
              <View style={styles.productAmountContainer}>
                <Text style={styles.productEditText}>Amount :</Text>
                <Text style={styles.productAmountText}>
                  {props.nav.wishlist_product.is_on_sale === true
                    ? props.nav.wishlist_product.special_sale_price
                    : props.nav.wishlist_product.max_retail_price}
                </Text>
                <TouchableOpacity
                  onPress={() => {
                    

                    let Itemid = props.nav.id;
                    console.log("Position CLick>>", Itemid);
                    closeModal(Itemid);
                  }}
                >
                  <Image
                    source={images.deleteIcon}
                    style={{
                      resizeMode: "cover",
                      width: 20,
                      height: 20,
                      justifyContent: "flex-end",
                      marginTop: 40,
                    }}
                  />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </View>
      {/* );
       })}  */}
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  productContainer: {
    flex: 1,
    width: "100%",
    minHeight: 93,
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    marginTop: 5,
    flexWrap: "wrap",
  },
  productSubContainer: {
    borderRadius: 13,
    shadowColor: "rgba(90, 108, 234, 0.07)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 50,
    shadowOpacity: 1,
    marginTop: 5,
    backgroundColor: "#fff",
    flexWrap: "wrap",
  },
  productInnerContainer: {
    flexDirection: "row",
    width: "100%",
    flexWrap: "wrap",
  },
  productDetailContainer: {
    width: "100%",
    height: "100%",
    // padding: 5,
    flexWrap: "wrap",
  },
  productAmountContainer: {
    width: "25%",
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  productEditText: {
    fontFamily: "Montserrat-SemiBold",
    opacity: 0.8,
    fontFamily: "Montserrat",
    fontSize: 9,
    fontWeight: "600",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#101010",
  },
  productNameText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 14,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 18.3,
    letterSpacing: 0,
    textAlign: "left",
    color: "#09051c",
  },
  productQtyText: {
    opacity: 0.3,
    fontFamily: "Montserrat-Medium",
    fontSize: 10,
    fontWeight: "500",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#3b3b3b",
  },
  productPlanTypeText: {
    fontFamily: "Montserrat-SemiBold",
    //opacity: 0.8,
    fontSize: 12,
    fontWeight: "600",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "left",
    color: "#101010",
  },
  productAmountText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 14,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 17,
    letterSpacing: 0,
    textAlign: "left",
    color: "#201f9b",
  },
  productAmountDateText: {
    opacity: 0.6,
    fontFamily: "Montserrat-Regular",
    fontSize: 9,
    fontWeight: "normal",
    fontStyle: "normal",
    letterSpacing: 0.5,
    textAlign: "center",
    color: "#3b3b3b",
  },
  productAmountDateText1: {
    //opacity: 0.6,
    fontFamily: "Montserrat-SemiBold",
    fontSize: 9,
    fontWeight: "normal",
    fontStyle: "normal",
    letterSpacing: 0.5,
    //textAlign: "center",
    color: "#3b3b3b",
  },
  productAmountButton: {
    width: 81,
    // height: 14,
    borderRadius: 4,
    backgroundColor: "#52b69a",
    justifyContent: "center",
    alignItems: "center",
    padding: 2,
  },
  productStatusText: {
    alignSelf: "center",
    fontFamily: "Montserrat-SemiBold",
    fontSize: 9,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 11.8,
    letterSpacing: 0,
    // textAlign: "left",
    color: "#ffffff",
  },
});

export default WiseListCard;
