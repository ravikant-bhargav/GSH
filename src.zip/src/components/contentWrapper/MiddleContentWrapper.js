import React, { useRef, useEffect, useState } from "react";
import { View, StyleSheet, ScrollView } from "react-native";
import TabBarNavigation from "../../navigation/TabBarNavigation";

const MiddleContentWrapper = (props) => {
  return (
    <React.Fragment>
      <View style={[styles.container, props && props.style]}>
        <ScrollView showsVerticalScrollIndicator={false}>
          {props.children}
        </ScrollView>
      </View>
      {/* <TabBarNavigation
                navigation={props.navigation}
                {...props}
            /> */}
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgb(246, 246, 246)",
  },
});

export default MiddleContentWrapper;
