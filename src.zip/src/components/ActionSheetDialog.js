import React, { useRef } from 'react';
import {
    SafeAreaView,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native';
import ActionSheet, { SheetManager } from 'react-native-actions-sheet';
import PrimaryButtonResize from './button/PrimaryButtonResize';
import HorizontalLine from './HorizontalLine';
import PaymentFooter from './PaymentFooter';

const Sheets = {
    testSheet: 'test_sheet_id',
};

const colors = ['#4a4e4d', '#0e9aa7', '#3da4ab', '#f6cd61', '#fe8a71'];
const ActionSheetDialog = ({ actionSheetRef, sheetId, children }) => {
    //const actionSheetRef = useRef(null);

    const openSheet = () => {
        SheetManager.show(Sheets.testSheet, { text: 'Hello World' });
    };
    const closeSheet = () => {
        SheetManager.hide(Sheets.testSheet, null);
    }

    return (
        <>
            <ActionSheet
                initialOffsetFromBottom={0.75}
                onBeforeShow={data => console.log(data)}
                id={sheetId}
                ref={actionSheetRef}
                statusBarTranslucent
                bounceOnOpen={true}
                drawUnderStatusBar={false}
                bounciness={4}
                gestureEnabled={true}
                defaultOverlayOpacity={0.3}>
                <View style={{ paddingHorizontal: 12, }}>


                    <ScrollView
                        showsVerticalScrollIndicator={false}
                        keyboardShouldPersistTaps={"always"}
                        nestedScrollEnabled
                        onMomentumScrollEnd={() => {
                            actionSheetRef.current?.handleChildScrollEnd();
                        }}
                        style={styles.scrollview}>

                        {children}

                        {/* <View>
                            {items.map(item => (
                                <TouchableOpacity
                                    key={item}
                                    onPress={() => {
                                        closeSheet()
                                    }}
                                    style={styles.listItem}>
                                    <View
                                        style={[
                                            styles.placeholder,
                                            {
                                                width: item,
                                            },
                                        ]}
                                    />

                                    <View style={styles.btnLeft} />
                                </TouchableOpacity>
                            ))}
                        </View> */}

                        {/*  Add a Small Footer at Bottom */}
                        <View style={styles.footer} />

                    </ScrollView>
                </View>
            </ActionSheet>

        </>
    );
};

export default ActionSheetDialog;

const items = [
    100,
    60,
    150,
    200,
    170,
    80,
    41,
    101,
    61,
    151,
    202,
    172,
    82,
    43,
    103,
    64,
    155,
    205,
    176,
    86,
    46,
    106,
    66,
    152,
    203,
    173,
    81,
    42,
];

const styles = StyleSheet.create({
    footer: {
        height: 200,
    },
  
    scrollview: {
        width: '100%',
        padding: 12,
    },
   

});