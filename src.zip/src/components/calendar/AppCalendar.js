/* eslint-disable react-native/sort-styles */
/* eslint-disable import/order */
import React ,{useEffect, useState }from 'react';
import { Image, StyleSheet, Block, Button, Text, View, TouchableOpacity } from 'react-native';
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';

import moment from 'moment';
import { Value } from 'react-native-reanimated';
import {getAllDaysInMonth} from "../../utils/getNumberOfDays";

export default AppCalendar = (props) => {
    const [date, setDateTime] = useState('');

    var mode = props &&  props.setEnddateClick && props.setEnddateClick.deliveryMode;

    const [isFromDatePicked, setIsFromDatePicked] = useState(false);
    const [isToDatePicked, setIsToDatePicked] = useState(false);
    const [fromDate, setFromDate] = useState(new Date());
    const [markedDates, setMarkedDates] = useState({});

    // new

    const handelSubmit=()=>{
        props && props.onCurrentDate && setDateTime(props.onCurrentDate)
    }

    const SetEndDate=()=>{
        // var startdate = props &&  props.setEnddateClick && props.setEnddateClick.startdate && props.setEnddateClick.startdate;
        // var enddate = props &&  props.setEnddateClick && props.setEnddateClick.enddate && props.setEnddateClick.enddate;
        //
        let startdate = moment(new Date()).format('YYYY/MM/DD');

        let enddate

        let month = startdate.split('/')[1].replace('0', '');
        let year = startdate.split('/')[0];

        let numberofdays = getAllDaysInMonth(parseInt(month), parseInt(year));

        if(mode === 'daily'){
            enddate = moment(new Date()).add(numberofdays.length,'days').format('YYYY/MM/DD');
            setupInitialRange(startdate, enddate);
        } else {
            enddate = moment(new Date()).add(1,'days').format('YYYY/MM/DD');
            setupInitialRange(startdate, enddate);
        }

      
    }


    const closeModal = (startDate, endDate, mMarkedDates) => {

        let dateRange = {
            startDate: startDate,
            endDate: endDate
        }

        props.screenName === 'ProductDetails' && props.onClose(false);
        props.getDate(dateRange, mMarkedDates)
    }
    useEffect(() => {
        handelSubmit()
        SetEndDate()
        // 
    }, [])

    /*================================ date range logic start =======================================*/

    //{"dateString": "2022-08-26", "day": 26, "month": 8, "timestamp": 1661472000000, "year": 2022}

    const setupInitialRange = (startdate,enddate) => {
        // if (!this.props.initialRange) return;
        let [fromDate, toDate] = [startdate, enddate];
        let markedDates = {[fromDate]: {startingDay: true, customStyles: {
                    container: {
                        backgroundColor: '#3d3cb3'
                    },
                    text: {
                        color: '#ffffff',
                        fontWeight: 'bold'
                    }
                }}}
        let [mMarkedDates, range] = setupMarkedDates(fromDate, toDate, markedDates)
        //  this.setState({markedDates: mMarkedDates, fromDate: fromDate})
        setMarkedDates(mMarkedDates);
        setFromDate(fromDate);
    }

    const onDayPress = (day) => {
        if (!isFromDatePicked || (isFromDatePicked && isToDatePicked)) {
            setFromDate(day.dateString);
            setupStartMarker(day)
        } else if (!isToDatePicked) {
            let markedDates = {...markedDates}
            let [mMarkedDates, range] = setupMarkedDates(fromDate, day.dateString, markedDates)
            if (range >= 0) {
                setIsFromDatePicked(true);
                setIsToDatePicked(true);
                setMarkedDates(mMarkedDates);

                closeModal(fromDate, day.dateString, mMarkedDates)

            } else {
                setupStartMarker(day)
            }
        }
    }

    const onDayPressForSevenDays = (day) => {
        let markedDates = {[day.dateString]: {startingDay: true, customStyles: {
                    container: {
                        backgroundColor: '#3d3cb3',
                    },
                    text: {
                        color: '#ffffff',
                        fontWeight: 'bold'
                    }
                } }};

        let endDate = null;

        for (var i = 0; i <= 6; i++) {
            endDate = moment(day.dateString).add(i,'days').format('YYYY-MM-DD')
            markedDates[moment(day.dateString).add(i,'days').format('YYYY-MM-DD')] = {endingDay: true, customStyles: {
                    container: {
                        backgroundColor: '#3d3cb3'
                    },
                    text: {
                        color: '#ffffff',
                        fontWeight: 'bold'
                    }
                } }
        }
        setFromDate(day.dateString);
        setMarkedDates(markedDates)

        if (endDate !== null ) {
            closeModal(day.dateString, endDate, markedDates)
        }
    };

    const onDayPressForOneMonth = (day) => {
        let markedDates = {[day.dateString]: {startingDay: true, customStyles: {
                    container: {
                        backgroundColor: '#3d3cb3',
                    },
                    text: {
                        color: '#ffffff',
                        fontWeight: 'bold'
                    }
                } }};

        let endDate = null;

        console.log('onDayPressForOneMonth ==> ', day)
        let getAllDays = getAllDaysInMonth(day.month -1 , day.year);

        console.log('getAllDays ==> ', getAllDays.length)

        for (var i = 0; i <= (getAllDays.length - 1); i++) {
            endDate = moment(day.dateString).add(i,'days').format('YYYY-MM-DD')
            markedDates[moment(day.dateString).add(i,'days').format('YYYY-MM-DD')] = {endingDay: true, customStyles: {
                    container: {
                        backgroundColor: '#3d3cb3'
                    },
                    text: {
                        color: '#ffffff',
                        fontWeight: 'bold'
                    }
                } }
        }
        setFromDate(day.dateString);
        setMarkedDates(markedDates)

        if (endDate !== null ) {
            closeModal(day.dateString, endDate, markedDates)
        }
    };

    const setupStartMarker = (day) => {
        let markedDates = {[day.dateString]: {
                startingDay: true, customStyles: {
                    container: {
                        backgroundColor: '#3d3cb3',
                    },
                    text: {
                        color: '#ffffff',
                        fontWeight: 'bold'
                    }
                }
            }}
        setIsFromDatePicked(true);
        setIsToDatePicked(false);
        setFromDate(day.dateString);
        setMarkedDates(markedDates)
    }

    const setupMarkedDates = (fromDate, toDate, markedDates) => {

        let mFromDate = moment(fromDate)// .add(1,'days');
        let mToDate = moment(toDate)

        let range = mToDate.diff(mFromDate, 'days');
        if (range >= 0) {
            if (range == 0) {
                markedDates = {[toDate]: {customStyles: {
                            container: {
                                backgroundColor: '#3d3cb3'
                            },
                            text: {
                                color: '#ffffff',
                                fontWeight: 'bold'
                            }
                        }}}
            } else {
                for (var i = 0; i <= range; i++) {
                    if (i < range) {
                        markedDates[moment(mFromDate).add(i,'days').format('YYYY-MM-DD')] = {customStyles: {
                                container: {
                                    backgroundColor: '#3d3cb3'
                                },
                                text: {
                                    color: '#ffffff',
                                    fontWeight: 'bold'
                                }
                            }}
                    } else {
                        markedDates[toDate] = {
                            endingDay: true, customStyles: {
                                container: {
                                    backgroundColor: '#3d3cb3'
                                },
                                text: {
                                    color: '#ffffff',
                                    fontWeight: 'bold'
                                }
                            }
                        }
                    }
                }
            }
        }
        return [markedDates, range]
    }



    /*================================ date range logic ends =======================================*/



    return (
        <View style={styles.calendarModal}>
            <Calendar
                hideExtraDays={true}
                // Initially visible month. Default = now
                // current={props && props.onCurrentDate ? props.onCurrentDate : date}
                current={date}
                // Minimum date that can be selected, dates before minDate will be grayed out. Default = undefined
                // minDate={props.screenName === 'CreatePlanner' ? moment(new Date()).format('YYYY-MM-DD') : props.onCurrentDate}
                minDate={props.screenName === 'CreatePlanner' ? moment(new Date()).format('YYYY-MM-DD') : moment(new Date()).format('YYYY-MM-DD')}
                // Maximum date that can be selected, dates after maxDate will be grayed out. Default = undefined
                //maxDate={'2022-05-02'}
                theme={{


                    todayTextColor: '#000000',
                    todayDotColor: '#3d3cb3',
                    textDisabledColor: '#d9e1e8',

                    selectedDotColor: '#000000',
                    arrowColor: '#3d3cb3',
                    disabledArrowColor: '#d9e1e8',
                    monthTextColor: '#000000',
                    indicatorColor: '#000000',

                    // Week Name STyle
                    textDayHeaderFontFamily: 'Montserrat-Regular',
                    textDayFontWeight: 'normal',
                    textDayHeaderFontWeight: 'normal',
                    textDayHeaderFontSize: 10,


                    // Month Name Style
                    textMonthFontFamily: 'Montserrat-Bold',
                    textMonthFontSize: 17,
                    textMonthFontWeight: 'bold',

                    // Day Text STyle
                    dayTextColor: '#000000',
                    textDayFontFamily: 'Montserrat-Regular',
                    textDayFontSize: 14,
                }}
                onDayPress={day => props.screenName === 'CreatePlanner' ? onDayPressForSevenDays(day) : ( props.screenName === 'show30Days' ? onDayPressForOneMonth(day) : onDayPress(day) ) }
                markingType={'custom'}
                markedDates={markedDates}
                disableAllTouchEventsForDisabledDays={true}
                enableSwipeMonths={true}



            />
        </View>

    );
};

const styles = StyleSheet.create({
    calendarModal: {
        width: "100%",
        // height: "100%",
        // zIndex: 99999,

    },

});
