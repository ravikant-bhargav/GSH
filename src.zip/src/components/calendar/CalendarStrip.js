import React, { useRef, useEffect, useState } from 'react';
import {
    Image,
    Text,
    View,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    ScrollView,
    StatusBar,
    SafeAreaView,
    Platform,
} from 'react-native';

import appColors from '../../utils/appColors';
import images from '../../utils/sharedImages';
import CalendarStrip from 'react-native-calendar-strip';
import moment from 'moment';



const CalendarStripView = (props) => {
    console.log('CalendarStripView===>',props.datesRange)

    return (
        <React.Fragment>
            <View style={styles.calendarContainer}>
                <CalendarStrip
                    style={{ paddingLeft: 10, paddingRight: 10, height: 80 }}
                    //calendarColor={'#3343CE'}
                    calendarHeaderStyle={{ color: 'white' }}
                    dateNumberStyle={{ color: 'green' }}
                    dateNameStyle={{ color: 'green' }}
                    //iconContainer={{ flex: 0 }}
                    selectedDate={props && props.datesRange && props.datesRange.startDate}
                    startingDate={props && props.datesRange && props.datesRange.startDate}
                    minDate={props && props.datesRange && props.datesRange.startDate}
                    maxDate={props && props.datesRange && props.datesRange.endDate}
                   // scrollerPaging={false}
                    scrollable={false}
                    showMonth={false}
                    leftSelector={[]}
                    rightSelector={[]}
                    numDaysInWeek={7}
                    //dateNameStyle={{ backgroundColor: 'red' }}
                    upperCaseDays={true}
                    dayContainerStyle={{}}
                    dayComponentHeight={75}
                    dayComponent={(evt) => {
                        let seletedDate = evt.date.isSame(evt.selectedDate, "day");

                        console.log('JSON.stringify(evt) => ', JSON.stringify(evt))

                        return (

                            <TouchableOpacity
                                //onPress={onDateSelected.bind(this, date)}
                                // disabled={!enabled}
                                style={{
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    flex: 1,

                                }}
                            >



                                <Text
                                    style={{
                                        fontFamily: "Montserrat-SemiBold",
                                        fontSize: 12,
                                        fontWeight: "600",
                                        fontStyle: "normal",
                                        lineHeight: 13.1,
                                        letterSpacing: 0,
                                        textAlign: "left",
                                        color: "#000000"
                                    }}

                                >
                                    {evt.date.format("ddd").toUpperCase().charAt(0)}
                                </Text>


                                <View style={{
                                    width: 33,
                                    height: 33,
                                    backgroundColor: seletedDate === true ? "#3d3cb3" : "#ffffff",
                                    shadowColor: "rgba(0, 0, 0, 0.25)",
                                    shadowOffset: {
                                        width: 0,
                                        height: 0
                                    },
                                    shadowRadius: 4,
                                    shadowOpacity: 1,
                                    borderRadius: 20,
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    marginTop: 3,
                                    elevation: 20
                                }}>
                                    <Text
                                        style={{
                                            fontFamily: "Montserrat-Bold",
                                            fontSize: 12,
                                            fontWeight: "bold",
                                            fontStyle: "normal",
                                            lineHeight: 14,
                                            letterSpacing: 0,
                                            textAlign: "left",
                                            color: seletedDate === true ? "#fefeff" : "#3d3cb3"
                                        }}

                                    >
                                        {evt.date.date()}
                                    </Text>

                                </View>


                            </TouchableOpacity>

                        )
                    }}
                />
            </View>

        </React.Fragment>


    );
};

export const styles = StyleSheet.create({
    calendarContainer: {
        borderRadius: 8,


    },
    dateContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        padding: 0,
        alignItems: 'center',
        width: "96%"
    },

    leftArrow: {
        width: "2%",
        alignItems: 'center',
        alignSelf: 'center'

    },
    rightArrow: {
        width: "2%",
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
    },
    currentDateElement: {
        width: 38,
        height: 48,
        borderRadius: 10,
        backgroundColor: "#14b661",
        borderStyle: "solid",
        borderWidth: 1.5,
        borderColor: "#14b661",
        justifyContent: 'center',
        alignItems: 'center'
    },
    dateElement: {
        width: 38,
        height: 48,
        borderRadius: 10,
        backgroundColor: "#3332a0",
        borderStyle: "solid",
        borderWidth: 1.5,
        borderColor: "#3332a0",
        justifyContent: 'center',
        alignItems: 'center'
    },
    dateText: {
        fontFamily: "Montserrat-Bold",
        fontSize: 13,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 14.2,
        letterSpacing: 0,
        color: "#f6f6f6"
    },
    dayText: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 9,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 9.9,
        letterSpacing: 0,
        color: "#f6f6f6"
    },
    dateSeprator: {
        width: 22,
        height: 1,
        backgroundColor: "#ffffff",
        margin: 2
    },

    seprator: {
        height: 1,
        backgroundColor: "rgba(156, 210, 255, 0.42)",
        marginLeft: 10,
        marginRight: 10
    },
    currentMonthContainer: {
        flexDirection: 'row',
        marginLeft: 10,
        marginRight: 10,
        padding: 5,
        justifyContent: 'space-between'
    },
    currentMonthText: {
        fontFamily: "Montserrat-Bold",
        fontSize: 11,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 12,
        letterSpacing: 0,
        color: "#f6f6f6",
        alignSelf: 'flex-start'
    },
    currentMonthOrderText: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 9,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 9.9,
        letterSpacing: 0,
        color: "#f6f6f6",
        alignSelf: 'flex-end'
    },
    orderStatusContainer: {
        flexDirection: 'row',
        marginLeft: 10,
        marginRight: 10,
        justifyContent: 'center'
    },
    orderStatusElement: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 5
    },
    orderStatusText: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 11,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 12,
        letterSpacing: 0,
        color: "#f6f6f6",
        marginLeft: 6
    },
    orderStatusIndicatorGreen: {
        width: 23,
        height: 5,
        borderRadius: 22,
        backgroundColor: "#14b661"
    },
    orderStatusIndicatorRed: {
        width: 23,
        height: 5,
        borderRadius: 22,
        backgroundColor: "#ff7e70"
    }


});

export default CalendarStripView;