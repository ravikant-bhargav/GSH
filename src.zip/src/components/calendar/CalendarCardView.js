import React, { useRef, useEffect, useState } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  SafeAreaView,
  Platform,
} from "react-native";
import moment from "moment";
import appColors from "../../utils/appColors";
import images from "../../utils/sharedImages";
import CalendarStripView from "../../components/calendar/CalendarStrip";
// import CalendarStrip from 'react-native-calendar-strip';

const CalendarCardView = (props) => {
  const [date, setdate] = useState("");
  const [month, setmonth] = useState("");

  useEffect(() => {
    showDate();
  }, []);
  const showDate = () => {
    //Get Current Date
    var date = new Date().getDate();

    //Get Current Month
    var month = new Date().getMonth() + 1;

    //Get Current Year
    var year = new Date().getFullYear();

    //Get Current Time Hours
    var hours = new Date().getHours();

    //Get Current Time Minutes
    var min = new Date().getMinutes();

    //Get Current Time Seconds
    var sec = new Date().getSeconds();

    ///Get Next month
    var month2 = new Date().getMonth() + 2;

    var finalObject = year + "-" + month + "-" + date;

    //console.log('Current Date>>',finalObject)

    // setDateTime(finalObject);

    //setstartdate(finalObject)
    //setenddate(endObject)
    //moment().format('ddd');
    setdate(date);
    setmonth(new Date().getMonth());
  };

  return (
    <React.Fragment>
      <View style={styles.calendarContainer}>
        <View
          style={{
            width: "100%",
            flexDirection: "row",
            marginTop: 10,
            marginBottom: 10,
          }}
        >
          <View style={styles.leftArrow}>
            {/* <Image source={images.chevronLeft}
                            style={{
                                width: 13, height: 13, opacity: 0.69, resizeMode: 'cover',
                            }}
                            tintColor={"#f6f6f6"}
                        /> */}
          </View>
          <View style={styles.dateContainer}>
            <TouchableOpacity onPress={props.onPress}>
              <View style={styles.currentDateElement}>
                <Text style={styles.dateText}>{date}</Text>
                <View style={styles.dateSeprator} />
                <Text style={styles.dayText}>
                  {moment().format("ddd").replace("day", "")}
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={props.onPress}>
              <View style={styles.dateElement}>
                {/* <View style={styles.container}>
                                    <CalendarStrip
                                    scrollable
                                    style={{height:200, paddingTop: 20, paddingBottom: 10}}
                                    calendarColor={'#3343CE'}
                                    calendarHeaderStyle={{color: 'white'}}
                                    dateNumberStyle={{color: 'white'}}
                                    dateNameStyle={{color: 'white'}}
                                    iconContainer={{flex: 0.1}}
                                    />
                                </View> */}
                {/* <CalendarStripView datesRange={ datesRange={startDate:'2022-09-28',
                                                                endDate: moment().add(date+1,'days').format('YYYY-MM-DD')

                                                            }} />  */}

                <Text style={styles.dateText}>
                  {moment().add(1, "days").format("DD")}
                </Text>
                <View style={styles.dateSeprator} />
                <Text style={styles.dayText}>
                  {moment().add(1, "days").format("ddd").replace("day", "")}
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={props.onPress}>
              <View style={styles.dateElement}>
                {/* <CalendarStripView datesRange={ datesRange={startDate:'2022-09-30',
                                   endDate: moment().add(date+,'days').format('YYYY-MM-DD')

                            }} />  */}
                <Text style={styles.dateText}>
                  {moment().add(2, "days").format("DD")}
                </Text>
                <View style={styles.dateSeprator} />
                <Text style={styles.dayText}>
                  {moment().add(2, "days").format("ddd").replace("day", "")}
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={props.onPress}>
              <View style={styles.dateElement}>
                <Text style={styles.dateText}>
                  {moment().add(3, "days").format("DD")}
                </Text>
                <View style={styles.dateSeprator} />
                <Text style={styles.dayText}>
                  {moment().add(3, "days").format("ddd").replace("day", "")}
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={props.onPress}>
              <View style={styles.dateElement}>
                <Text style={styles.dateText}>
                  {moment().add(4, "days").format("DD")}
                </Text>
                <View style={styles.dateSeprator} />
                <Text style={styles.dayText}>
                  {moment().add(4, "days").format("ddd").replace("   day", "")}
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={props.onPress}>
              <View style={styles.dateElement}>
                <Text style={styles.dateText}>
                  {moment().add(5, "days").format("DD")}
                </Text>
                <View style={styles.dateSeprator} />
                <Text style={styles.dayText}>
                  {moment().add(5, "days").format("ddd").replace("day", "")}
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={props.onPress}>
              <View style={styles.dateElement}>
                <Text style={styles.dateText}>
                  {moment().add(6, "days").format("DD")}
                </Text>
                <View style={styles.dateSeprator} />
                <Text style={styles.dayText}>
                  {moment().add(6, "days").format("ddd").replace("day", "")}
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={styles.rightArrow}>
            {/* <Image source={images.chevronRight}
                            style={{
                                width: 13, height: 13, opacity: 0.69, resizeMode: 'cover',
                            }}
                            tintColor={"#f6f6f6"}
                        /> */}
          </View>
        </View>
        <View style={styles.seprator} />

        <View style={styles.currentMonthContainer}>
          <Text style={styles.currentMonthText}>{moment().format("MMMM")}</Text>
          <Text style={styles.currentMonthOrderText}>
            Last order Delivered: Today 23 Feb 10:36 am
          </Text>
        </View>

        {/* <View style={styles.orderStatusContainer}>
                    <View style={styles.orderStatusElement}>
                        <View style={styles.orderStatusIndicatorGreen} />
                        <Text style={styles.orderStatusText}>Order Delivered</Text>
                    </View>
                    <View style={styles.orderStatusElement}>
                        <View style={styles.orderStatusIndicatorRed} />
                        <Text style={styles.orderStatusText}>Order Cancelled</Text>
                    </View>

                </View> */}
      </View>
    </React.Fragment>
  );
};

export const styles = StyleSheet.create({
  container: { flex: 1 },
  calendarContainer: {
    height: 96,
    borderRadius: 8,
    backgroundColor: appColors.PRIMARY_COLOR,
  },
  dateContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 0,
    alignItems: "center",
    width: "96%",
  },

  leftArrow: {
    width: "2%",
    alignItems: "center",
    alignSelf: "center",
  },
  rightArrow: {
    width: "2%",
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  currentDateElement: {
    width: 38,
    height: 48,
    borderRadius: 10,
    backgroundColor: "#14b661",
    borderStyle: "solid",
    borderWidth: 1.5,
    borderColor: "#14b661",
    justifyContent: "center",
    alignItems: "center",
  },
  dateElement: {
    width: 38,
    height: 48,
    borderRadius: 10,
    backgroundColor: "#3332a0",
    borderStyle: "solid",
    borderWidth: 1.5,
    borderColor: "#3332a0",
    justifyContent: "center",
    alignItems: "center",
  },
  dateText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 13,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 14.2,
    letterSpacing: 0,
    color: "#f6f6f6",
  },
  dayText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 7,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 9.9,
    letterSpacing: 0,
    color: "#f6f6f6",
  },
  dateSeprator: {
    width: 22,
    height: 1,
    backgroundColor: "#ffffff",
    margin: 2,
  },

  seprator: {
    height: 1,
    backgroundColor: "rgba(156, 210, 255, 0.42)",
    marginLeft: 10,
    marginRight: 10,
  },
  currentMonthContainer: {
    flexDirection: "row",
    marginLeft: 10,
    marginRight: 10,
    padding: 5,
    justifyContent: "space-between",
  },
  currentMonthText: {
    fontFamily: "Montserrat-Bold",
    fontSize: 11,
    fontWeight: "bold",
    fontStyle: "normal",
    lineHeight: 12,
    letterSpacing: 0,
    color: "#f6f6f6",
    alignSelf: "flex-start",
  },
  currentMonthOrderText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 9,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 9.9,
    letterSpacing: 0,
    color: "#f6f6f6",
    alignSelf: "flex-end",
  },
  orderStatusContainer: {
    flexDirection: "row",
    marginLeft: 10,
    marginRight: 10,
    justifyContent: "center",
  },
  orderStatusElement: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 5,
  },
  orderStatusText: {
    fontFamily: "Montserrat-SemiBold",
    fontSize: 11,
    fontWeight: "600",
    fontStyle: "normal",
    lineHeight: 12,
    letterSpacing: 0,
    color: "#f6f6f6",
    marginLeft: 6,
  },
  orderStatusIndicatorGreen: {
    width: 23,
    height: 5,
    borderRadius: 22,
    backgroundColor: "#14b661",
  },
  orderStatusIndicatorRed: {
    width: 23,
    height: 5,
    borderRadius: 22,
    backgroundColor: "#ff7e70",
  },
});

export default CalendarCardView;
