import React, { useRef, useEffect } from 'react';


import {
    SafeAreaView,
    Image,
    Text,
    View,
    StyleSheet,
    Dimensions,
    Animated,
    StatusBar,
    TouchableOpacity
} from 'react-native';
import ZipcodeInputs from 'react-native-otp-inputs';


const Zipinput = ({ getzipVal }) => {

    return (

        <ZipcodeInputs
            style={{ width: '60%', flexDirection: 'row', selectionColor: 'yellow' }}
            handleChange={(code) => { getzipVal(code) }}
            numberOfInputs={6}
            inputStyles={{
                height: 40,
                borderRadius: 12,
                borderStyle: "solid",
                borderWidth: 2.5,
                borderColor: "rgb(61, 60, 179)",
                fontFamily: "Montserrat-Bold",
                fontSize: 18,
                fontWeight: "bold",
                fontStyle: "normal",
                lineHeight: 26.2,
                letterSpacing: 1,
                textAlign: "center",
                color: "#2c2c2d",
              
                    // width: "80%",
                    // borderRadius: 5,
                    // paddingVertical: 8,
                    // paddingHorizontal: 16,
                    // borderColor: "rgba(0, 0, 0, 0.2)",
                    // borderWidth: 1,
                    // marginBottom: 8,
              
            


            }}
            inputContainerStyles={{ padding: 3, width: '25%', marginTop: 13, }}
            keyboardType={'numeric'}
            selectionColor={'#2c2c2d'}
        />



    );
};

export const styles = StyleSheet.create({
    buttonContainer: {
        // flex: 1,
        justifyContent: 'center',
        height: 40,
        borderRadius: 12,
        borderStyle: "solid",
        borderWidth: 2,
        borderColor: "rgb(61, 60, 179)",
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10

    },
    buttonAlignment: {

        backgroundColor: "#ffffff",
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        // padding:10

    },
    buttonText: {
        fontFamily: "Montserrat-SemiBold",
        fontSize: 15,
        fontWeight: "600",
        fontStyle: "normal",
        lineHeight: 19.7,
        letterSpacing: 0,
        textAlign: "left",
        color: "rgb(61, 60, 179)"


    },
    imageButton: {
        width: 28.3,
        height: 29,
        borderRadius: 5,
        shadowColor: "rgba(0, 0, 0, 0.09)",
        shadowOffset: {
            width: 0,
            height: 0
        },
        shadowRadius: 4,
        shadowOpacity: 1,
        marginRight: 15
    }

});

export default Zipinput;