export const DATA = [
    {
        "id": 468,
        "delivery_date": "2022-10-28T00:00:00.000Z",
        "order_id": "GSH-1664-359859-3681",
        "order_type": "SUBSCRIPTION",
        "product_id": 29,
        "product_name": "Amul Spread Cheese"
    },

    {
        id: 40,
        date: '03/07/2022',
        subscriptionName1: 'Anik Cow Milk (Subscription)',
    },

    {
        id: 70,
        date: '05/07/2022',
        subscriptionName1: 'Anik Cow Milk (Subscription)',
        subscriptionName2: 'Anik Cow Milk (One Time)'
    },

    {
        id: 10,
        date: '08/07/2022',
        subscriptionName1: 'Anik Cow Milk (Subscription)',
    },
    {
        id: 1,
        date: '24/07/2022',
        subscriptionName1: 'Anik Cow Milk (Subscription)',
        subscriptionName2: 'Anik Cow Milk (One Time)'
    },
    {
        id: 2,
        date: '25/07/2022',
        subscriptionName1: 'Anik Cow Milk (Subscription)',
    },
    {
        id: 3,
        date: '27/07/2022',
        subscriptionName1: 'Anik Cow Milk (Subscription)',
    },
    {
        id: 4,
        date: '28/07/2022',
        subscriptionName1: 'Anik Cow Milk (Subscription)',
        subscriptionName2: 'Anik Cow Milk (One Time)'
    }
];